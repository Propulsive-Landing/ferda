/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'simulation/Plant/ World Setup/Solver Configuration'.
 */

const sm_core_compiler_ConvexPolyhedron *simulation_b048d748_1_geometry_0(const
  RuntimeDerivedValuesBundle *rtdv);
const sm_core_compiler_Cylinder *simulation_b048d748_1_geometry_1(const
  RuntimeDerivedValuesBundle *rtdv);
const sm_core_compiler_Cylinder *simulation_b048d748_1_geometry_2(const
  RuntimeDerivedValuesBundle *rtdv);
const sm_core_compiler_Brick *simulation_b048d748_1_geometry_3(const
  RuntimeDerivedValuesBundle *rtdv);
struct RuntimeDerivedValuesBundleTag;
void simulation_b048d748_1_initializeGeometries(const struct
  RuntimeDerivedValuesBundleTag *rtdv);
