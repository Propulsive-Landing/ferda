#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
#include "pm_std.h"
size_t mc_VgM3Lx3pYgtLW13T1_txvP(const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ)
;void mc_F4xMxEJX_DlUYXuaiDuSWS(const PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,
const PmRealVector*x,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08);void
mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmIntVector*
mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_V5jydIk5QzCRZTOycShqTL(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FvLmE29WKCKJfaZMHwg3g9(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const int32_T mc_kh0AzKGHcX8tfeDoNul_TU,
const int32_T mc__Oliq0seKPWShTNRpvAarb);void mc__pmVtsSuXZls_1NfvVprZ7(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH);void
mc_FR5FdJeEvDGGcyEVkxeE_x(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt);
void mc_FK6EqkTbVFGMZ5QwXcurHx(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*mc_k8AO2tT20x0_cyxVp0ak3P);void mc_FioOBDJiFMpkWaAcUdBb1E(
const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T mc_kg4CyRgbu6OdeewZOel7Qx)
;void mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,
const PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd);void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VqP4HesDIf47bDn5teE2H2(const PmRealVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmRealVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_Vv4EJYeJDW0yZXiH42yCA_(const PmIntVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmIntVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_k0zonBZJC2K6baT1NXX1Qo(PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);size_t
mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*mc__MqKyOds56_XeH9Iv3CTIL);void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE);size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);size_t mc__fQVSVSgEBG6fuximVFlkw(const
PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa);size_t mc_FyLahU0kjICfba8O7mWi8Z(const
PmBoolVector*mc_FawmFe5oOEC_cmkvZc1Kaa);boolean_T mc___gjB_jZtTxReaWZSEiFdh(
const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx);boolean_T mc_kk65_VI6zC0mWHqRziXpjX(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FzkrLuS4xMOvaTv5dUw3j7(const
PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ);void mc_ks_PW4I7dwWbhXAWhHTUCI
(const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V3CZVT50_V_xeia9SYYptc(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T a,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x
,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_FBDi_PCg670TjHgJTNPcHr);void mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x
,const real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
real_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VM9M6KxYTfKL_q4yuXmOnI(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt)
;void mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V2CDnBdRcOpuh1IyvRJzfi(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt);void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__aNO1s5qwzt6fXwft5YgCz(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc__Nb_EyyxYi4ddPcS0H7Bot(const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const
PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);
void mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VWloU5QD6gpaXeK8lmytFA(const
PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw);void mc_VQ1YWbKmkVC6YajZAyvmNH(const
PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);real_T mc_kMPF5fccZd_3jHFMhUSro6(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_kvxcenZbLm4dfenXL8jQAx(
const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_Vgo5SAIS_80_VXwmU7JogX
(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);void mc__25pQTf4VutiXiGTGQmvSU(
PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const PmIntVector*
mc_F6sy5cXK8JOKeiFBw6znSV);void mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*
mc_VWoEnwEgWFpobmwHA1Qln5,const PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const
PmSparsityPattern*mc__Df1hQFzAY4fiLCvP0PV12);void mc_VMRKMuNLnDxXjaBiy1RcMD(
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc_kM_Y9u9U2F_Cf9sWAtmMMu(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc__Xq_g76c6Y_K_PpYNKcquN(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const real_T*x);void mc_kXj99iXjC1CoZLWwPRH879(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*mc_FybTf2SinthyWqOxvPdJ5h,size_t mc_VVRAoFgW2Hphcy7H6H9Oh0)
;void mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat);void mc_kLGj2IdnGDG_YeEKAnMkUr(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FJN_drUOKh_igHJXVH7xls(
const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T mc_kcda_aHAM4WIXuM_xBDdLt);void
mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr,const
PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo);void mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*
mc_FrF2gTbWxox8geiSROFaFn,const PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE);void mc_VjzTgsx19j0KfHv6VXr4Mp(const
PmRealVector*a,const PmIntVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*
b);void mc_V_Fp06wJOBhXZyLbA5xU0r(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a);void mc_FuY0t5xEb5_QhDQFQ_TXtc(
const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x);void mc_kMo1w3ReRZGIdH5_MNwumc
(const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_VYxtXnMKT6hpb1FMldBDLs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void
mc_kl_UmQrKbdCajPyXz5nOIL(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void mc_k2E2oWXDqshMeuCQWrbaKT
(const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc_FBaB5196Xx0ohX_IWM5ypL(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T x);void
mc_F1CG0fHJYfd_ealLMx7Z7U(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void mc_krXbD205SBpghif1h1n_ei(
const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc__Qtfmi680EKpj1bOrIroGr(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void
mc__0IkRn0eQ9Wc_u8mCNbQDh(const PmIntVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void mc__pbFNjwg_bCPdPFSjC2Wdv(
const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx);void mc_VpjBXBa8TTCl_uBXYMLfxC(const PmBoolVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);
void mc__pFtu1g17h8ZaaZK4PpTkb(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,
const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void
mc_kMScbNM1RKOTaD4QwTME8Y(const PmBoolVector*mc__1Zf2IciMRCub1vvbEr1C4,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc_VlnhKi82gfCLgumIqeduOq);void mc_Fbsqat6MlL0bjPHlNxax8t(const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FSAdXYnRP9pkfmWBYlMkJJ(
const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC);void
mc__NertSre4cWh_mN2RJ5UPq(const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*
mc_VCVhWy_VaDhraHrlfFWxBa);PmRealVector mc_VPFwoVShg1G3XTwou1_jbC(const
PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,size_t mc_Fyss_XM3F_C4dm6IKoDw4G,size_t
mc_Vs6xonQX17Krc5vXv8T_zq);
#include "math.h"
#include "string.h"
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(
const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_int_vector_fields(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmIntVector*pm_create_int_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm__fSS_VMqhWlobeqe6mQF_x(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_int_vector(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm__jbisDMumXdocXANx5LhhY
(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);
#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
static real_T mc_kMZgqM70jlGC_m_qf1e0YZ(real_T a){real_T
mc_F3X3cyJFWvSxiL8bzofKAQ=pmf_get_real_max();return((a!=a)||(a>
mc_F3X3cyJFWvSxiL8bzofKAQ)||(a<-mc_F3X3cyJFWvSxiL8bzofKAQ))?
mc_F3X3cyJFWvSxiL8bzofKAQ:fabs(a);}void mc_F4xMxEJX_DlUYXuaiDuSWS(const
PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,const PmRealVector*x,const PmRealVector*
mc_FfDTppU8N_tOWuLK37x_08){size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0,
mc_kyp6uAyJE40UVuAQNEYzS1=0;real_T mc_kN69YSxH4HG_Y1SybdfuVp= -1.0;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_kyVj_uOQd__gg9_ljlZ_IY->mN;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_kyVj_uOQd__gg9_ljlZ_IY->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]= -1;}(void)0;;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<((
mc_kyVj_uOQd__gg9_ljlZ_IY->mN)<(x->mN)?(mc_kyVj_uOQd__gg9_ljlZ_IY->mN):(x->mN)
);mc_kwrB3ZoKf7OufTHWaHJV7a++){real_T mc_FBdAz7xW3ptCfPUD8CDkgz= -1.0;int32_T
mc__x0Cjt8TqJ8Zdy5bsEhSgj= -1;for(mc_kyp6uAyJE40UVuAQNEYzS1=0;
mc_kyp6uAyJE40UVuAQNEYzS1<x->mN;mc_kyp6uAyJE40UVuAQNEYzS1++){real_T
mc_kPKKHEzx9slcbTkiKgmTSq=mc_kMZgqM70jlGC_m_qf1e0YZ(x->mX[
mc_kyp6uAyJE40UVuAQNEYzS1]);if(mc_kPKKHEzx9slcbTkiKgmTSq==
mc_kN69YSxH4HG_Y1SybdfuVp){(void)0;;if(((int32_T)mc_kyp6uAyJE40UVuAQNEYzS1)>
mc_kyVj_uOQd__gg9_ljlZ_IY->mX[mc_kwrB3ZoKf7OufTHWaHJV7a-1]){
mc_FBdAz7xW3ptCfPUD8CDkgz=mc_kPKKHEzx9slcbTkiKgmTSq;mc__x0Cjt8TqJ8Zdy5bsEhSgj=
(int32_T)mc_kyp6uAyJE40UVuAQNEYzS1;break;}}if(mc_kPKKHEzx9slcbTkiKgmTSq>
mc_FBdAz7xW3ptCfPUD8CDkgz&&(mc_kwrB3ZoKf7OufTHWaHJV7a==0||
mc_kPKKHEzx9slcbTkiKgmTSq<mc_kN69YSxH4HG_Y1SybdfuVp)){
mc_FBdAz7xW3ptCfPUD8CDkgz=mc_kPKKHEzx9slcbTkiKgmTSq;mc__x0Cjt8TqJ8Zdy5bsEhSgj=
(int32_T)mc_kyp6uAyJE40UVuAQNEYzS1;}}(void)0;;(void)0;;(void)0;;
mc_kN69YSxH4HG_Y1SybdfuVp=mc_FBdAz7xW3ptCfPUD8CDkgz;if(
mc_kMZgqM70jlGC_m_qf1e0YZ(x->mX[mc__x0Cjt8TqJ8Zdy5bsEhSgj])>=
mc_FfDTppU8N_tOWuLK37x_08->mX[mc__x0Cjt8TqJ8Zdy5bsEhSgj]){
mc_kyVj_uOQd__gg9_ljlZ_IY->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]=
mc__x0Cjt8TqJ8Zdy5bsEhSgj;}else{break;}}}size_t mc_VgM3Lx3pYgtLW13T1_txvP(
const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ){size_t mc_kwrB3ZoKf7OufTHWaHJV7a
=0;for(mc_kwrB3ZoKf7OufTHWaHJV7a=mc_VgJW5ZqpwPpuY1inYtaofQ->mN;
mc_kwrB3ZoKf7OufTHWaHJV7a>0;mc_kwrB3ZoKf7OufTHWaHJV7a--){if(
mc_VgJW5ZqpwPpuY1inYtaofQ->mX[mc_kwrB3ZoKf7OufTHWaHJV7a-1]){return
mc_kwrB3ZoKf7OufTHWaHJV7a;}}(void)0;;return 0;}void mc_FK6EqkTbVFGMZ5QwXcurHx(
const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
mc_k8AO2tT20x0_cyxVp0ak3P){size_t mc_V5LBNJCbhICNbmMG_hLaZ6=
pm__hARyx1bZBxVj1boVQqdtV->mN;int32_T*x=pm__hARyx1bZBxVj1boVQqdtV->mX;size_t
mc_VnX55JO_G3lQeu9BIiStl0=mc_k8AO2tT20x0_cyxVp0ak3P->mN;int32_T*
mc_kYVhBJKlndKGi9KvU7lJMg=mc_k8AO2tT20x0_cyxVp0ak3P->mX;size_t
mc_kwrB3ZoKf7OufTHWaHJV7a=0;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_V5LBNJCbhICNbmMG_hLaZ6;mc_kwrB3ZoKf7OufTHWaHJV7a
++){x[mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_kYVhBJKlndKGi9KvU7lJMg[x[
mc_kwrB3ZoKf7OufTHWaHJV7a]];}}void mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector
*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g){size_t mc_V5LBNJCbhICNbmMG_hLaZ6=
pm__hARyx1bZBxVj1boVQqdtV->mN;size_t mc_VBS7W7jeELG_Zu4dt4HciP=
pm__YmIqNX3g5Sub1vKK1hZQF->mN;size_t mc___ECRgjqShlp_PytRplerL=
mc_F2Ry_cv60wK5bmHWC_sU4g->mN;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;int32_T*x=
pm__hARyx1bZBxVj1boVQqdtV->mX;int32_T*mc_FzyLWRgau0pMYq2XSI3ETL=
pm__YmIqNX3g5Sub1vKK1hZQF->mX;int32_T*mc_FBDi_PCg670TjHgJTNPcHr=
mc_F2Ry_cv60wK5bmHWC_sU4g->mX;(void)0;;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
0;mc_kwrB3ZoKf7OufTHWaHJV7a<mc_VBS7W7jeELG_Zu4dt4HciP;
mc_kwrB3ZoKf7OufTHWaHJV7a++){x[mc_FzyLWRgau0pMYq2XSI3ETL[
mc_kwrB3ZoKf7OufTHWaHJV7a]]=mc_FBDi_PCg670TjHgJTNPcHr[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g){size_t mc_V5LBNJCbhICNbmMG_hLaZ6=
pm__hARyx1bZBxVj1boVQqdtV->mN;size_t mc_VBS7W7jeELG_Zu4dt4HciP=
pm__YmIqNX3g5Sub1vKK1hZQF->mN;size_t mc___ECRgjqShlp_PytRplerL=
mc_F2Ry_cv60wK5bmHWC_sU4g->mN;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;int32_T*x=
pm__hARyx1bZBxVj1boVQqdtV->mX;int32_T*mc_FzyLWRgau0pMYq2XSI3ETL=
pm__YmIqNX3g5Sub1vKK1hZQF->mX;int32_T*mc_FBDi_PCg670TjHgJTNPcHr=
mc_F2Ry_cv60wK5bmHWC_sU4g->mX;(void)0;;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
0;mc_kwrB3ZoKf7OufTHWaHJV7a<mc_V5LBNJCbhICNbmMG_hLaZ6;
mc_kwrB3ZoKf7OufTHWaHJV7a++){x[mc_kwrB3ZoKf7OufTHWaHJV7a]=
mc_FzyLWRgau0pMYq2XSI3ETL[mc_FBDi_PCg670TjHgJTNPcHr[mc_kwrB3ZoKf7OufTHWaHJV7a]
];}}static void mc_F3PjEuxC7WW6WqXbm7hdXJ(int32_T*pm__hARyx1bZBxVj1boVQqdtV,
int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T mc_kyp6uAyJE40UVuAQNEYzS1){int32_T
mc__0Gxic3Bpu_HjDevqjQi0l;mc__0Gxic3Bpu_HjDevqjQi0l=pm__hARyx1bZBxVj1boVQqdtV[
mc_kwrB3ZoKf7OufTHWaHJV7a];pm__hARyx1bZBxVj1boVQqdtV[mc_kwrB3ZoKf7OufTHWaHJV7a
]=pm__hARyx1bZBxVj1boVQqdtV[mc_kyp6uAyJE40UVuAQNEYzS1];
pm__hARyx1bZBxVj1boVQqdtV[mc_kyp6uAyJE40UVuAQNEYzS1]=mc__0Gxic3Bpu_HjDevqjQi0l
;}static void mc__7pr9FCRo1CXfivy25fUsq(int32_T*pm__hARyx1bZBxVj1boVQqdtV,
int32_T mc_kh0AzKGHcX8tfeDoNul_TU,int32_T mc__Oliq0seKPWShTNRpvAarb){int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a,mc__s9c11FV6MCacH_iL7euSO;if(
mc_kh0AzKGHcX8tfeDoNul_TU>=mc__Oliq0seKPWShTNRpvAarb){return;}
mc_F3PjEuxC7WW6WqXbm7hdXJ(pm__hARyx1bZBxVj1boVQqdtV,mc_kh0AzKGHcX8tfeDoNul_TU,
(mc_kh0AzKGHcX8tfeDoNul_TU+mc__Oliq0seKPWShTNRpvAarb)/2);
mc__s9c11FV6MCacH_iL7euSO=mc_kh0AzKGHcX8tfeDoNul_TU;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=mc_kh0AzKGHcX8tfeDoNul_TU+1;
mc_kwrB3ZoKf7OufTHWaHJV7a<=mc__Oliq0seKPWShTNRpvAarb;mc_kwrB3ZoKf7OufTHWaHJV7a
++){if(pm__hARyx1bZBxVj1boVQqdtV[mc_kwrB3ZoKf7OufTHWaHJV7a]<
pm__hARyx1bZBxVj1boVQqdtV[mc_kh0AzKGHcX8tfeDoNul_TU]){
mc_F3PjEuxC7WW6WqXbm7hdXJ(pm__hARyx1bZBxVj1boVQqdtV,++
mc__s9c11FV6MCacH_iL7euSO,mc_kwrB3ZoKf7OufTHWaHJV7a);}}
mc_F3PjEuxC7WW6WqXbm7hdXJ(pm__hARyx1bZBxVj1boVQqdtV,mc_kh0AzKGHcX8tfeDoNul_TU,
mc__s9c11FV6MCacH_iL7euSO);mc__7pr9FCRo1CXfivy25fUsq(pm__hARyx1bZBxVj1boVQqdtV
,mc_kh0AzKGHcX8tfeDoNul_TU,mc__s9c11FV6MCacH_iL7euSO-1);
mc__7pr9FCRo1CXfivy25fUsq(pm__hARyx1bZBxVj1boVQqdtV,mc__s9c11FV6MCacH_iL7euSO+
1,mc__Oliq0seKPWShTNRpvAarb);}void mc_V5jydIk5QzCRZTOycShqTL(const PmIntVector
*pm__hARyx1bZBxVj1boVQqdtV){size_t mc_V5LBNJCbhICNbmMG_hLaZ6=
pm__hARyx1bZBxVj1boVQqdtV->mN;int32_T*x=pm__hARyx1bZBxVj1boVQqdtV->mX;
mc__7pr9FCRo1CXfivy25fUsq(x,0,(int32_T)(mc_V5LBNJCbhICNbmMG_hLaZ6-1));}void
mc_FvLmE29WKCKJfaZMHwg3g9(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
int32_T mc_kh0AzKGHcX8tfeDoNul_TU,const int32_T mc__Oliq0seKPWShTNRpvAarb){
size_t mc_V5LBNJCbhICNbmMG_hLaZ6=pm__hARyx1bZBxVj1boVQqdtV->mN;int32_T*x=
pm__hARyx1bZBxVj1boVQqdtV->mX;int32_T mc_Fyss_XM3F_C4dm6IKoDw4G=(
mc_kh0AzKGHcX8tfeDoNul_TU<0)?0:mc_kh0AzKGHcX8tfeDoNul_TU;int32_T
mc_Vs6xonQX17Krc5vXv8T_zq=(mc__Oliq0seKPWShTNRpvAarb>(int32_T)(
mc_V5LBNJCbhICNbmMG_hLaZ6-1))?(int32_T)(mc_V5LBNJCbhICNbmMG_hLaZ6-1):
mc__Oliq0seKPWShTNRpvAarb;mc__7pr9FCRo1CXfivy25fUsq(x,
mc_Fyss_XM3F_C4dm6IKoDw4G,mc_Vs6xonQX17Krc5vXv8T_zq);}void
mc__pmVtsSuXZls_1NfvVprZ7(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*
mc_kd_kJxzsgTx9W19pl4H_AH){size_t mc_V5LBNJCbhICNbmMG_hLaZ6=
pm__hARyx1bZBxVj1boVQqdtV->mN;size_t mc_VBS7W7jeELG_Zu4dt4HciP=
pm__YmIqNX3g5Sub1vKK1hZQF->mN;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0,
mc__BwCbGCDlrx2gDK5rof3H8=0;int32_T*x=pm__hARyx1bZBxVj1boVQqdtV->mX;int32_T*
mc_FzyLWRgau0pMYq2XSI3ETL=pm__YmIqNX3g5Sub1vKK1hZQF->mX;boolean_T*
mc__OpctBB9W1lxYmlFllQKCL=mc_kd_kJxzsgTx9W19pl4H_AH->mX;(void)0;;(void)0;;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=mc__BwCbGCDlrx2gDK5rof3H8=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_VBS7W7jeELG_Zu4dt4HciP;mc_kwrB3ZoKf7OufTHWaHJV7a
++){if(mc__OpctBB9W1lxYmlFllQKCL[mc_kwrB3ZoKf7OufTHWaHJV7a]==true){x[
mc__BwCbGCDlrx2gDK5rof3H8]=mc_FzyLWRgau0pMYq2XSI3ETL[mc_kwrB3ZoKf7OufTHWaHJV7a
];mc__BwCbGCDlrx2gDK5rof3H8++;}}}void mc_FR5FdJeEvDGGcyEVkxeE_x(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt){size_t n=
pm__YmIqNX3g5Sub1vKK1hZQF->mN;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;int32_T*
mc_FzyLWRgau0pMYq2XSI3ETL=pm__YmIqNX3g5Sub1vKK1hZQF->mX;int32_T*x=
pm__hARyx1bZBxVj1boVQqdtV->mX;int32_T mc_k6s4v_P0JhG2iH2f8ifSrS=0;(void)0;;for
(mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){if(mc_FL_3a__K44dYi9fe74WHqt){
mc_k6s4v_P0JhG2iH2f8ifSrS+=mc_FzyLWRgau0pMYq2XSI3ETL[mc_kwrB3ZoKf7OufTHWaHJV7a
];}x[mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_k6s4v_P0JhG2iH2f8ifSrS;if(!
mc_FL_3a__K44dYi9fe74WHqt){mc_k6s4v_P0JhG2iH2f8ifSrS+=
mc_FzyLWRgau0pMYq2XSI3ETL[mc_kwrB3ZoKf7OufTHWaHJV7a];}}}void
mc_FioOBDJiFMpkWaAcUdBb1E(const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx){size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0,n=
mc_F6RwpxHXSXp7gDlfFRloPz->mN;int32_T*x=mc_F6RwpxHXSXp7gDlfFRloPz->mX;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){x[mc_kwrB3ZoKf7OufTHWaHJV7a]+=
mc_kg4CyRgbu6OdeewZOel7Qx;}}void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0){size_t mc__cQx3tlWTC4Bf9AkNaYwft=
mc_VRbT1WwZjwW6f5YGBCFuaD->mN;size_t mc__D8XpaXC7gGqh1WK0wKJ7T=
mc__d7LC10lP38OY1VXN_tFqb->mN;(void)0;;(void)0;;if(mc__lO81KuDBk41W9Wd2wAkb0>0
){memcpy(mc_VRbT1WwZjwW6f5YGBCFuaD->mX+mc_FnrjFNs9eQp9V5vCxPaoKw,
mc__d7LC10lP38OY1VXN_tFqb->mX+mc_FRuIUemzxbdhfqkjXhoyK7,
mc__lO81KuDBk41W9Wd2wAkb0*sizeof(boolean_T));}}void mc_VqP4HesDIf47bDn5teE2H2(
const PmRealVector*mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,
const PmRealVector*mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,
size_t mc__lO81KuDBk41W9Wd2wAkb0){size_t mc__cQx3tlWTC4Bf9AkNaYwft=
mc_VRbT1WwZjwW6f5YGBCFuaD->mN;size_t mc__D8XpaXC7gGqh1WK0wKJ7T=
mc__d7LC10lP38OY1VXN_tFqb->mN;(void)0;;(void)0;;if(mc__lO81KuDBk41W9Wd2wAkb0>0
){memcpy(mc_VRbT1WwZjwW6f5YGBCFuaD->mX+mc_FnrjFNs9eQp9V5vCxPaoKw,
mc__d7LC10lP38OY1VXN_tFqb->mX+mc_FRuIUemzxbdhfqkjXhoyK7,
mc__lO81KuDBk41W9Wd2wAkb0*sizeof(real_T));}}void mc_Vv4EJYeJDW0yZXiH42yCA_(
const PmIntVector*mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,
const PmIntVector*mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,
size_t mc__lO81KuDBk41W9Wd2wAkb0){size_t mc__cQx3tlWTC4Bf9AkNaYwft=
mc_VRbT1WwZjwW6f5YGBCFuaD->mN;size_t mc__D8XpaXC7gGqh1WK0wKJ7T=
mc__d7LC10lP38OY1VXN_tFqb->mN;(void)0;;(void)0;;if(mc__lO81KuDBk41W9Wd2wAkb0>0
){memcpy(mc_VRbT1WwZjwW6f5YGBCFuaD->mX+mc_FnrjFNs9eQp9V5vCxPaoKw,
mc__d7LC10lP38OY1VXN_tFqb->mX+mc_FRuIUemzxbdhfqkjXhoyK7,
mc__lO81KuDBk41W9Wd2wAkb0*sizeof(int32_T));}}void mc_k0zonBZJC2K6baT1NXX1Qo(
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF){size_t n=pm__YmIqNX3g5Sub1vKK1hZQF->mN;(void)0;;if(
n>0){memcpy(pm__hARyx1bZBxVj1boVQqdtV->mX,pm__YmIqNX3g5Sub1vKK1hZQF->mX,n*
sizeof(real_T));}}size_t mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*
mc__MqKyOds56_XeH9Iv3CTIL){size_t mc_VZqFpq_ZqUlKXH2OQc0PHC=0,
mc_kwrB3ZoKf7OufTHWaHJV7a=0,n=mc__MqKyOds56_XeH9Iv3CTIL->mN;const boolean_T*
mc_FibiBMKFQu0fZu7OotNeuK=mc__MqKyOds56_XeH9Iv3CTIL->mX;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=mc_VZqFpq_ZqUlKXH2OQc0PHC=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
mc_FibiBMKFQu0fZu7OotNeuK[mc_kwrB3ZoKf7OufTHWaHJV7a]==true){
mc_VZqFpq_ZqUlKXH2OQc0PHC++;}}return mc_VZqFpq_ZqUlKXH2OQc0PHC;}void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE){int32_T*mc__VS9Y1bpgQtfX99yIDrTJ5=
mc__vpsWwfj3fx1YDJlP_lHTd->mX;size_t mc_knWv7ym3rvSJ_acobopnDl=
mc__vpsWwfj3fx1YDJlP_lHTd->mN;boolean_T*b=mc_VwOeyeOYCKdcVTySJQVoLE->mX;size_t
mc_kLMRRiSdJr4aaLEtYiWmgE=mc_VwOeyeOYCKdcVTySJQVoLE->mN;size_t
mc_kwrB3ZoKf7OufTHWaHJV7a=0,mc__BwCbGCDlrx2gDK5rof3H8=0;(void)0;;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=mc__BwCbGCDlrx2gDK5rof3H8=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_kLMRRiSdJr4aaLEtYiWmgE;mc_kwrB3ZoKf7OufTHWaHJV7a
++){if(b[mc_kwrB3ZoKf7OufTHWaHJV7a]==true){mc__VS9Y1bpgQtfX99yIDrTJ5[
mc__BwCbGCDlrx2gDK5rof3H8]=((int32_T)(mc_kwrB3ZoKf7OufTHWaHJV7a));
mc__BwCbGCDlrx2gDK5rof3H8++;}}(void)0;;}size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV){size_t mc_kNgcOktCtQxdYedrGvFn5i=0,
mc_kwrB3ZoKf7OufTHWaHJV7a=0,n=mc_F6sy5cXK8JOKeiFBw6znSV->mN;const int32_T*
mc_FkUOybTHjuWgciA6_Hl5eT=mc_F6sy5cXK8JOKeiFBw6znSV->mX;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=mc_kNgcOktCtQxdYedrGvFn5i=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
mc_FkUOybTHjuWgciA6_Hl5eT[mc_kwrB3ZoKf7OufTHWaHJV7a]!=0){
mc_kNgcOktCtQxdYedrGvFn5i++;}}return mc_kNgcOktCtQxdYedrGvFn5i;}size_t
mc__fQVSVSgEBG6fuximVFlkw(const PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa){size_t
mc_kNgcOktCtQxdYedrGvFn5i=0,mc_kwrB3ZoKf7OufTHWaHJV7a=0,n=
mc_FawmFe5oOEC_cmkvZc1Kaa->mN;const real_T*x=mc_FawmFe5oOEC_cmkvZc1Kaa->mX;for
(mc_kwrB3ZoKf7OufTHWaHJV7a=mc_kNgcOktCtQxdYedrGvFn5i=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(x[
mc_kwrB3ZoKf7OufTHWaHJV7a]!=0.0){mc_kNgcOktCtQxdYedrGvFn5i++;}}return
mc_kNgcOktCtQxdYedrGvFn5i;}size_t mc_FyLahU0kjICfba8O7mWi8Z(const PmBoolVector
*mc_FawmFe5oOEC_cmkvZc1Kaa){size_t mc_kNgcOktCtQxdYedrGvFn5i=0,
mc_kwrB3ZoKf7OufTHWaHJV7a=0,n=mc_FawmFe5oOEC_cmkvZc1Kaa->mN;const boolean_T*x=
mc_FawmFe5oOEC_cmkvZc1Kaa->mX;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_kNgcOktCtQxdYedrGvFn5i=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){if(x[mc_kwrB3ZoKf7OufTHWaHJV7a]){
mc_kNgcOktCtQxdYedrGvFn5i++;}}return mc_kNgcOktCtQxdYedrGvFn5i;}boolean_T
mc___gjB_jZtTxReaWZSEiFdh(const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV){size_t
mc_kwrB3ZoKf7OufTHWaHJV7a=0,n=mc_F6sy5cXK8JOKeiFBw6znSV->mN;const int32_T*
mc_FkUOybTHjuWgciA6_Hl5eT=mc_F6sy5cXK8JOKeiFBw6znSV->mX;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){if(mc_FkUOybTHjuWgciA6_Hl5eT[
mc_kwrB3ZoKf7OufTHWaHJV7a]!=0){return true;}}return false;}boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx){size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0,n=
pm__hARyx1bZBxVj1boVQqdtV->mN;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
pm__hARyx1bZBxVj1boVQqdtV->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]==
mc_kg4CyRgbu6OdeewZOel7Qx){return true;}}return false;}boolean_T
mc_kk65_VI6zC0mWHqRziXpjX(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T
mc_kg4CyRgbu6OdeewZOel7Qx){size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0,n=
pm__hARyx1bZBxVj1boVQqdtV->mN;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
pm__hARyx1bZBxVj1boVQqdtV->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]==
mc_kg4CyRgbu6OdeewZOel7Qx){return true;}}return false;}void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF){size_t mc_kwrB3ZoKf7OufTHWaHJV7a,n=
pm__hARyx1bZBxVj1boVQqdtV->mN;real_T*mc_VAGK8ob2sQKOcm1T9oo3qq=
pm__hARyx1bZBxVj1boVQqdtV->mX;const real_T*mc__zkkfff7mFdUiDXhH9M8VP=
pm__YmIqNX3g5Sub1vKK1hZQF->mX;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_VAGK8ob2sQKOcm1T9oo3qq[mc_kwrB3ZoKf7OufTHWaHJV7a]+=
mc__zkkfff7mFdUiDXhH9M8VP[mc_kwrB3ZoKf7OufTHWaHJV7a];}}void
mc_FzkrLuS4xMOvaTv5dUw3j7(const PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ
){size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<x->mN;++mc_kwrB3ZoKf7OufTHWaHJV7a){x->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]+=mc_VgJW5ZqpwPpuY1inYtaofQ;}}void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF){size_t mc_kwrB3ZoKf7OufTHWaHJV7a,n=
pm__hARyx1bZBxVj1boVQqdtV->mN;real_T*mc_VAGK8ob2sQKOcm1T9oo3qq=
pm__hARyx1bZBxVj1boVQqdtV->mX;const real_T*mc__zkkfff7mFdUiDXhH9M8VP=
pm__YmIqNX3g5Sub1vKK1hZQF->mX;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_VAGK8ob2sQKOcm1T9oo3qq[mc_kwrB3ZoKf7OufTHWaHJV7a]-=
mc__zkkfff7mFdUiDXhH9M8VP[mc_kwrB3ZoKf7OufTHWaHJV7a];}}void
mc_ks_PW4I7dwWbhXAWhHTUCI(const PmRealVector*x,const PmRealVector*
mc_FzyLWRgau0pMYq2XSI3ETL){size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0,n=x->mN;real_T*
mc_FqH0EVYQMAShYmkhGO4SMO=x->mX;const real_T*mc_V7FB0efIGnCneTA4UZcn9d=
mc_FzyLWRgau0pMYq2XSI3ETL->mX;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_FqH0EVYQMAShYmkhGO4SMO[mc_kwrB3ZoKf7OufTHWaHJV7a]=fabs(
mc_V7FB0efIGnCneTA4UZcn9d[mc_kwrB3ZoKf7OufTHWaHJV7a]);}}void
mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x,const PmRealVector*
mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr){size_t
mc_kwrB3ZoKf7OufTHWaHJV7a=0;size_t n=x->mN;real_T*mc_FqH0EVYQMAShYmkhGO4SMO=x
->mX;const real_T*mc_V7FB0efIGnCneTA4UZcn9d=mc_FzyLWRgau0pMYq2XSI3ETL->mX;
const real_T*mc__sfJ_i_EyFKhVHPkbicbLx=mc_FBDi_PCg670TjHgJTNPcHr->mX;(void)0;;
(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){mc_FqH0EVYQMAShYmkhGO4SMO[
mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_V7FB0efIGnCneTA4UZcn9d[mc_kwrB3ZoKf7OufTHWaHJV7a
]-mc__sfJ_i_EyFKhVHPkbicbLx[mc_kwrB3ZoKf7OufTHWaHJV7a];}}void
mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x,const real_T a,const
PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL){size_t mc_kwrB3ZoKf7OufTHWaHJV7a,n=x->
mN;real_T*mc_FqH0EVYQMAShYmkhGO4SMO=x->mX;const real_T*
mc_V7FB0efIGnCneTA4UZcn9d=mc_FzyLWRgau0pMYq2XSI3ETL->mX;(void)0;;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){mc_FqH0EVYQMAShYmkhGO4SMO[
mc_kwrB3ZoKf7OufTHWaHJV7a]=a*mc_V7FB0efIGnCneTA4UZcn9d[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}void mc_V3CZVT50_V_xeia9SYYptc(const PmRealVector
*x,real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL){size_t
mc_kwrB3ZoKf7OufTHWaHJV7a,n=x->mN;real_T*mc_FqH0EVYQMAShYmkhGO4SMO=x->mX;const
real_T*mc_V7FB0efIGnCneTA4UZcn9d=mc_FzyLWRgau0pMYq2XSI3ETL->mX;(void)0;;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){mc_FqH0EVYQMAShYmkhGO4SMO[
mc_kwrB3ZoKf7OufTHWaHJV7a]+=(a*mc_V7FB0efIGnCneTA4UZcn9d[
mc_kwrB3ZoKf7OufTHWaHJV7a]);}}void mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector
*x,const real_T mc_kcda_aHAM4WIXuM_xBDdLt){size_t mc_kwrB3ZoKf7OufTHWaHJV7a,n=
x->mN;real_T*mc_FqH0EVYQMAShYmkhGO4SMO=x->mX;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_FqH0EVYQMAShYmkhGO4SMO[mc_kwrB3ZoKf7OufTHWaHJV7a]*=
mc_kcda_aHAM4WIXuM_xBDdLt;}}void mc_VM9M6KxYTfKL_q4yuXmOnI(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt){size_t
mc_kwrB3ZoKf7OufTHWaHJV7a,n=pm__hARyx1bZBxVj1boVQqdtV->mN;real_T*
mc_VAGK8ob2sQKOcm1T9oo3qq=pm__hARyx1bZBxVj1boVQqdtV->mX;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){mc_VAGK8ob2sQKOcm1T9oo3qq[
mc_kwrB3ZoKf7OufTHWaHJV7a]/=mc_kcda_aHAM4WIXuM_xBDdLt;}}void
mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF){size_t mc_kwrB3ZoKf7OufTHWaHJV7a,n=
pm__hARyx1bZBxVj1boVQqdtV->mN;int32_T*mc_FwGbexLpUX_EhmbZ9hbeuk=
pm__hARyx1bZBxVj1boVQqdtV->mX;int32_T*mc_FrKHEQPORb8Ifya73HEHas=
pm__YmIqNX3g5Sub1vKK1hZQF->mX;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_FwGbexLpUX_EhmbZ9hbeuk[mc_kwrB3ZoKf7OufTHWaHJV7a]*=
mc_FrKHEQPORb8Ifya73HEHas[mc_kwrB3ZoKf7OufTHWaHJV7a];}}void
mc_V2CDnBdRcOpuh1IyvRJzfi(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF){size_t mc_kwrB3ZoKf7OufTHWaHJV7a,n=
pm__hARyx1bZBxVj1boVQqdtV->mN;real_T*mc_FwGbexLpUX_EhmbZ9hbeuk=
pm__hARyx1bZBxVj1boVQqdtV->mX;real_T*mc_FrKHEQPORb8Ifya73HEHas=
pm__YmIqNX3g5Sub1vKK1hZQF->mX;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_FwGbexLpUX_EhmbZ9hbeuk[mc_kwrB3ZoKf7OufTHWaHJV7a]*=
mc_FrKHEQPORb8Ifya73HEHas[mc_kwrB3ZoKf7OufTHWaHJV7a];}}void
mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF){size_t mc_kwrB3ZoKf7OufTHWaHJV7a,n=
pm__hARyx1bZBxVj1boVQqdtV->mN;real_T*mc_FwGbexLpUX_EhmbZ9hbeuk=
pm__hARyx1bZBxVj1boVQqdtV->mX;real_T*mc_FrKHEQPORb8Ifya73HEHas=
pm__YmIqNX3g5Sub1vKK1hZQF->mX;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){(void)0;;
mc_FwGbexLpUX_EhmbZ9hbeuk[mc_kwrB3ZoKf7OufTHWaHJV7a]/=
mc_FrKHEQPORb8Ifya73HEHas[mc_kwrB3ZoKf7OufTHWaHJV7a];}}void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt){real_T*x=mc_VcZASgthsTt6dul8DlRWaw->mX;size_t n=
mc_VcZASgthsTt6dul8DlRWaw->mN;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){x[mc_kwrB3ZoKf7OufTHWaHJV7a]=
mc_kcda_aHAM4WIXuM_xBDdLt;}}void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw){boolean_T*x=mc_VcZASgthsTt6dul8DlRWaw->mX;size_t n=
mc_VcZASgthsTt6dul8DlRWaw->mN;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){x[mc_kwrB3ZoKf7OufTHWaHJV7a]=(x[
mc_kwrB3ZoKf7OufTHWaHJV7a]==false)?true:false;}}void mc__aNO1s5qwzt6fXwft5YgCz
(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw){real_T*x=
mc_VcZASgthsTt6dul8DlRWaw->mX;size_t n=mc_VcZASgthsTt6dul8DlRWaw->mN;if(n>0){
memset(x,0,n*sizeof(real_T));}}void mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector
*pm__hARyx1bZBxVj1boVQqdtV){int32_T*x=pm__hARyx1bZBxVj1boVQqdtV->mX;size_t n=
pm__hARyx1bZBxVj1boVQqdtV->mN;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){x[mc_kwrB3ZoKf7OufTHWaHJV7a]=(int32_T)
mc_kwrB3ZoKf7OufTHWaHJV7a;}}void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx){int32_T*x=
mc_VcZASgthsTt6dul8DlRWaw->mX;size_t n=mc_VcZASgthsTt6dul8DlRWaw->mN;size_t
mc_kwrB3ZoKf7OufTHWaHJV7a=0;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){x[
mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_kg4CyRgbu6OdeewZOel7Qx;}}void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw){int32_T
*x=mc_VcZASgthsTt6dul8DlRWaw->mX;size_t n=mc_VcZASgthsTt6dul8DlRWaw->mN;if(n>0
){memset(x,0,n*sizeof(int32_T));}}void mc__Nb_EyyxYi4ddPcS0H7Bot(const
PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt){size_t
mc_kwrB3ZoKf7OufTHWaHJV7a=0;size_t mc_VfhTCNHkGmlfXaqtwDLas5=
mc__vpsWwfj3fx1YDJlP_lHTd->mN;size_t mc__qvhWt5kuF8fiqLUoz8V1c=
mc_kd_kJxzsgTx9W19pl4H_AH->mN;int32_T*mc_V5yzS5gzFIGWj14jmdK6dv=
mc__vpsWwfj3fx1YDJlP_lHTd->mX;boolean_T*mc_F_jWmRPlHg8_i5UMupAJPf=
mc_kd_kJxzsgTx9W19pl4H_AH->mX;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_VfhTCNHkGmlfXaqtwDLas5;mc_kwrB3ZoKf7OufTHWaHJV7a
++){(void)0;;mc_F_jWmRPlHg8_i5UMupAJPf[mc_V5yzS5gzFIGWj14jmdK6dv[
mc_kwrB3ZoKf7OufTHWaHJV7a]]=mc_kcda_aHAM4WIXuM_xBDdLt;}}void
mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd){size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;size_t
mc_VfhTCNHkGmlfXaqtwDLas5=mc__vpsWwfj3fx1YDJlP_lHTd->mN;const int32_T*
mc_V5yzS5gzFIGWj14jmdK6dv=mc__vpsWwfj3fx1YDJlP_lHTd->mX;boolean_T*
mc_V7rS_i_HqL0QbqhHOCqTGM=mc_FrF2gTbWxox8geiSROFaFn->mX;const boolean_T*
mc_FkXPOsDyktKOYDtXnwTXgE=mc_VwOeyeOYCKdcVTySJQVoLE->mX;(void)0;;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_VfhTCNHkGmlfXaqtwDLas5;mc_kwrB3ZoKf7OufTHWaHJV7a++){(void)0;;
mc_V7rS_i_HqL0QbqhHOCqTGM[mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_FkXPOsDyktKOYDtXnwTXgE
[mc_V5yzS5gzFIGWj14jmdK6dv[mc_kwrB3ZoKf7OufTHWaHJV7a]];}}void
mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt){boolean_T*x=mc_VcZASgthsTt6dul8DlRWaw->mX
;size_t n=mc_VcZASgthsTt6dul8DlRWaw->mN;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;for
(mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){x[mc_kwrB3ZoKf7OufTHWaHJV7a]=
mc_kcda_aHAM4WIXuM_xBDdLt;}}void mc_VWloU5QD6gpaXeK8lmytFA(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw){boolean_T*x=mc_VcZASgthsTt6dul8DlRWaw->mX;size_t n=
mc_VcZASgthsTt6dul8DlRWaw->mN;if(n>0){memset(x,0,n*sizeof(boolean_T));}}void
mc_VQ1YWbKmkVC6YajZAyvmNH(const PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a
,size_t mc__lO81KuDBk41W9Wd2wAkb0){(void)0;;if(mc__lO81KuDBk41W9Wd2wAkb0>0){
memset(x->mX+mc_kwrB3ZoKf7OufTHWaHJV7a,0,mc__lO81KuDBk41W9Wd2wAkb0*sizeof(
boolean_T));}}void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF){size_t
n=pm__hARyx1bZBxVj1boVQqdtV->mN;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;boolean_T*
mc__riq6ALv8RCwiiKYVvfeQJ=pm__hARyx1bZBxVj1boVQqdtV->mX;boolean_T*
mc_F8VrXMVRQbh6dT2VAEm8u5=pm__YmIqNX3g5Sub1vKK1hZQF->mX;(void)0;;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){mc__riq6ALv8RCwiiKYVvfeQJ[
mc_kwrB3ZoKf7OufTHWaHJV7a]|=mc_F8VrXMVRQbh6dT2VAEm8u5[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}void mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector
*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF){
size_t n=pm__hARyx1bZBxVj1boVQqdtV->mN;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;
boolean_T*mc__riq6ALv8RCwiiKYVvfeQJ=pm__hARyx1bZBxVj1boVQqdtV->mX;boolean_T*
mc_F8VrXMVRQbh6dT2VAEm8u5=pm__YmIqNX3g5Sub1vKK1hZQF->mX;(void)0;;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){mc__riq6ALv8RCwiiKYVvfeQJ[
mc_kwrB3ZoKf7OufTHWaHJV7a]&=mc_F8VrXMVRQbh6dT2VAEm8u5[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV){size_t mc_kwrB3ZoKf7OufTHWaHJV7a,n=
pm__hARyx1bZBxVj1boVQqdtV->mN;real_T*mc_VAGK8ob2sQKOcm1T9oo3qq=
pm__hARyx1bZBxVj1boVQqdtV->mX;real_T mc__01SK3u3lG0GaLCTTSoVGO,
mc_kPKKHEzx9slcbTkiKgmTSq=0.0;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc__01SK3u3lG0GaLCTTSoVGO=mc_VAGK8ob2sQKOcm1T9oo3qq[mc_kwrB3ZoKf7OufTHWaHJV7a]
;mc_kPKKHEzx9slcbTkiKgmTSq+=mc__01SK3u3lG0GaLCTTSoVGO*
mc__01SK3u3lG0GaLCTTSoVGO;}mc_kPKKHEzx9slcbTkiKgmTSq=sqrt(
mc_kPKKHEzx9slcbTkiKgmTSq);return mc_kPKKHEzx9slcbTkiKgmTSq;}real_T
mc_kMPF5fccZd_3jHFMhUSro6(const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC){size_t
mc_kwrB3ZoKf7OufTHWaHJV7a=0;size_t n=pm_FiALy5LWvv87e9O_pJGWPC->mN;real_T*
mc_kffJCPlAaaGZe97NgvNUCQ=pm_FiALy5LWvv87e9O_pJGWPC->mX;real_T
mc_FJDSx_4IX_K4d5kCbuTIxX=0.0;(void)0;;mc_FJDSx_4IX_K4d5kCbuTIxX=
mc_kffJCPlAaaGZe97NgvNUCQ[0];for(mc_kwrB3ZoKf7OufTHWaHJV7a=1;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
mc_kffJCPlAaaGZe97NgvNUCQ[mc_kwrB3ZoKf7OufTHWaHJV7a]>mc_FJDSx_4IX_K4d5kCbuTIxX
){mc_FJDSx_4IX_K4d5kCbuTIxX=mc_kffJCPlAaaGZe97NgvNUCQ[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}return mc_FJDSx_4IX_K4d5kCbuTIxX;}int32_T
mc_kvxcenZbLm4dfenXL8jQAx(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC){size_t
mc_kwrB3ZoKf7OufTHWaHJV7a=0,mc_Vzz7fHz6oElvjujXUEM3YM=0;size_t n=
pm_FiALy5LWvv87e9O_pJGWPC->mN;int32_T*mc_kffJCPlAaaGZe97NgvNUCQ=
pm_FiALy5LWvv87e9O_pJGWPC->mX;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_Vzz7fHz6oElvjujXUEM3YM=0;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){mc_Vzz7fHz6oElvjujXUEM3YM+=
mc_kffJCPlAaaGZe97NgvNUCQ[mc_kwrB3ZoKf7OufTHWaHJV7a];}return((int32_T)(
mc_Vzz7fHz6oElvjujXUEM3YM));}int32_T mc_Vgo5SAIS_80_VXwmU7JogX(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC){size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;
size_t n=pm_FiALy5LWvv87e9O_pJGWPC->mN;int32_T*x=pm_FiALy5LWvv87e9O_pJGWPC->mX
;int32_T mc_VSaRLaxZ1oCKaTBPXCg5gd=0;(void)0;;mc_VSaRLaxZ1oCKaTBPXCg5gd=x[0];
for(mc_kwrB3ZoKf7OufTHWaHJV7a=1;mc_kwrB3ZoKf7OufTHWaHJV7a<n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){if(x[mc_kwrB3ZoKf7OufTHWaHJV7a]>
mc_VSaRLaxZ1oCKaTBPXCg5gd){mc_VSaRLaxZ1oCKaTBPXCg5gd=x[
mc_kwrB3ZoKf7OufTHWaHJV7a];}}return mc_VSaRLaxZ1oCKaTBPXCg5gd;}void
mc__25pQTf4VutiXiGTGQmvSU(PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV){size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0,
mc__BwCbGCDlrx2gDK5rof3H8=0,mc_F5Oo_hjCgMdPWDNQjpW_uN=
mc_F6sy5cXK8JOKeiFBw6znSV->mN,mc_kzHXcE8PFKG9jL1htgrpQ4=
mc__nP_wNlJUxWHWLytmZ4pL0->mN;int32_T*mc__8DS0jLoIACOd5_RUk_oV_=
mc__nP_wNlJUxWHWLytmZ4pL0->mX,*mc__jNIo7y8sA4SfuPsG6NE6y=
mc_F6sy5cXK8JOKeiFBw6znSV->mX;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc__BwCbGCDlrx2gDK5rof3H8=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_F5Oo_hjCgMdPWDNQjpW_uN;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
mc__jNIo7y8sA4SfuPsG6NE6y[mc_kwrB3ZoKf7OufTHWaHJV7a]!=0){(void)0;;
mc__8DS0jLoIACOd5_RUk_oV_[mc__BwCbGCDlrx2gDK5rof3H8]=((int32_T)(
mc_kwrB3ZoKf7OufTHWaHJV7a));mc__BwCbGCDlrx2gDK5rof3H8++;}}
mc__nP_wNlJUxWHWLytmZ4pL0->mN=mc__BwCbGCDlrx2gDK5rof3H8;}void
mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*mc_VWoEnwEgWFpobmwHA1Qln5,const
PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const PmSparsityPattern*
mc__Df1hQFzAY4fiLCvP0PV12){int32_T*mc_kXeDcvuOSpSqamcA4a5jc_=
mc__Df1hQFzAY4fiLCvP0PV12->mJc;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0,
mc__jwySfHyx1SXgXJeVWoIzb=mc__Df1hQFzAY4fiLCvP0PV12->mNumCol;int32_T
mc_kyp6uAyJE40UVuAQNEYzS1=0;real_T mc_kOHf_kT93gKWb1VNyhtyit=0.0,
mc_kBRAKLK5I1G1e5S60wYieF;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc__jwySfHyx1SXgXJeVWoIzb;mc_kwrB3ZoKf7OufTHWaHJV7a
++){mc_kOHf_kT93gKWb1VNyhtyit=0.0;for(mc_kyp6uAyJE40UVuAQNEYzS1=
mc_kXeDcvuOSpSqamcA4a5jc_[mc_kwrB3ZoKf7OufTHWaHJV7a];mc_kyp6uAyJE40UVuAQNEYzS1
<mc_kXeDcvuOSpSqamcA4a5jc_[mc_kwrB3ZoKf7OufTHWaHJV7a+1];
mc_kyp6uAyJE40UVuAQNEYzS1++){mc_kBRAKLK5I1G1e5S60wYieF=fabs(
mc_V_rxJBbuhqtwViRHFKhdGC->mX[mc_kyp6uAyJE40UVuAQNEYzS1]);if(
mc_kBRAKLK5I1G1e5S60wYieF>mc_kOHf_kT93gKWb1VNyhtyit){mc_kOHf_kT93gKWb1VNyhtyit
=mc_kBRAKLK5I1G1e5S60wYieF;}}mc_VWoEnwEgWFpobmwHA1Qln5->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_kOHf_kT93gKWb1VNyhtyit;}}void
mc_VMRKMuNLnDxXjaBiy1RcMD(const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const
PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV){size_t mc_kyp6uAyJE40UVuAQNEYzS1=0;size_t
mc__TknivEJQPO9bmE57Qv18s=mc_VknkCg_msB8Ga9ymQtGggf->mNumCol;int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a=0;int32_T*mc_kXeDcvuOSpSqamcA4a5jc_=
mc_VknkCg_msB8Ga9ymQtGggf->mJc;int32_T*mc_VEXzFHKjFN87iiOtLrddNz=
mc_VknkCg_msB8Ga9ymQtGggf->mIr;real_T*mc_VlnhKi82gfCLgumIqeduOq=
mc_FCZxG6Iux_GKX1lkqasXdQ->mX;real_T*mc_VzNSToCyqbluaiWifCbhIw=
pm__hARyx1bZBxVj1boVQqdtV->mX;(void)0;;(void)0;;for(mc_kyp6uAyJE40UVuAQNEYzS1=
0;mc_kyp6uAyJE40UVuAQNEYzS1<mc__TknivEJQPO9bmE57Qv18s;
mc_kyp6uAyJE40UVuAQNEYzS1++){for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1];mc_kwrB3ZoKf7OufTHWaHJV7a
<mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1+1];
mc_kwrB3ZoKf7OufTHWaHJV7a++){mc_VlnhKi82gfCLgumIqeduOq[
mc_kwrB3ZoKf7OufTHWaHJV7a]*=mc_VzNSToCyqbluaiWifCbhIw[
mc_VEXzFHKjFN87iiOtLrddNz[mc_kwrB3ZoKf7OufTHWaHJV7a]];}}}void
mc_kM_Y9u9U2F_Cf9sWAtmMMu(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV){size_t
mc__jwySfHyx1SXgXJeVWoIzb=mc_VknkCg_msB8Ga9ymQtGggf->mNumCol;size_t
mc_FdNKyaRLqeWhg5tGqF_VYT=mc_VknkCg_msB8Ga9ymQtGggf->mNumRow;size_t
mc_kyp6uAyJE40UVuAQNEYzS1=0;int32_T*mc_kXeDcvuOSpSqamcA4a5jc_=
mc_VknkCg_msB8Ga9ymQtGggf->mJc;int32_T*mc_VEXzFHKjFN87iiOtLrddNz=
mc_VknkCg_msB8Ga9ymQtGggf->mIr;int32_T mc_kjn0E4w0eVx6eL0BQDhSHC=0;real_T
mc_ViKHq7CnFBKVdi6Gb6ljiV=0.0;real_T*x=pm__hARyx1bZBxVj1boVQqdtV->mX;real_T*
mc_FzyLWRgau0pMYq2XSI3ETL=pm__YmIqNX3g5Sub1vKK1hZQF->mX;real_T*A=
mc_FCZxG6Iux_GKX1lkqasXdQ->mX;(void)0;;(void)0;;(void)0;;for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc__jwySfHyx1SXgXJeVWoIzb;mc_kyp6uAyJE40UVuAQNEYzS1++){
mc_ViKHq7CnFBKVdi6Gb6ljiV=x[mc_kyp6uAyJE40UVuAQNEYzS1];for(
mc_kjn0E4w0eVx6eL0BQDhSHC=mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1]
;mc_kjn0E4w0eVx6eL0BQDhSHC<mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1
+1];mc_kjn0E4w0eVx6eL0BQDhSHC++){mc_FzyLWRgau0pMYq2XSI3ETL[
mc_VEXzFHKjFN87iiOtLrddNz[mc_kjn0E4w0eVx6eL0BQDhSHC]]+=
mc_ViKHq7CnFBKVdi6Gb6ljiV*A[mc_kjn0E4w0eVx6eL0BQDhSHC];}}}void
mc__Xq_g76c6Y_K_PpYNKcquN(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const real_T*x){size_t mc__jwySfHyx1SXgXJeVWoIzb=
mc_VknkCg_msB8Ga9ymQtGggf->mNumCol;size_t mc_FdNKyaRLqeWhg5tGqF_VYT=
mc_VknkCg_msB8Ga9ymQtGggf->mNumRow;size_t mc_kyp6uAyJE40UVuAQNEYzS1=0;int32_T*
mc_kXeDcvuOSpSqamcA4a5jc_=mc_VknkCg_msB8Ga9ymQtGggf->mJc;int32_T*
mc_VEXzFHKjFN87iiOtLrddNz=mc_VknkCg_msB8Ga9ymQtGggf->mIr;int32_T
mc_kjn0E4w0eVx6eL0BQDhSHC=0;real_T mc_ViKHq7CnFBKVdi6Gb6ljiV=0.0;real_T*
mc_FzyLWRgau0pMYq2XSI3ETL=pm__YmIqNX3g5Sub1vKK1hZQF->mX;real_T*A=
mc_FCZxG6Iux_GKX1lkqasXdQ->mX;(void)0;;(void)0;;for(mc_kyp6uAyJE40UVuAQNEYzS1=
0;mc_kyp6uAyJE40UVuAQNEYzS1<mc__jwySfHyx1SXgXJeVWoIzb;
mc_kyp6uAyJE40UVuAQNEYzS1++){mc_ViKHq7CnFBKVdi6Gb6ljiV=x[
mc_kyp6uAyJE40UVuAQNEYzS1];for(mc_kjn0E4w0eVx6eL0BQDhSHC=
mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1];mc_kjn0E4w0eVx6eL0BQDhSHC
<mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1+1];
mc_kjn0E4w0eVx6eL0BQDhSHC++){mc_FzyLWRgau0pMYq2XSI3ETL[
mc_VEXzFHKjFN87iiOtLrddNz[mc_kjn0E4w0eVx6eL0BQDhSHC]]+=
mc_ViKHq7CnFBKVdi6Gb6ljiV*A[mc_kjn0E4w0eVx6eL0BQDhSHC];}}}void
mc_kXj99iXjC1CoZLWwPRH879(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*mc_FybTf2SinthyWqOxvPdJ5h,size_t
mc_VVRAoFgW2Hphcy7H6H9Oh0){size_t mc__jwySfHyx1SXgXJeVWoIzb=
mc_VknkCg_msB8Ga9ymQtGggf->mNumCol;size_t mc_FdNKyaRLqeWhg5tGqF_VYT=
mc_VknkCg_msB8Ga9ymQtGggf->mNumRow;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0,
mc_kyp6uAyJE40UVuAQNEYzS1=0,mc_V2__YrimeI4E_yWnhKofpy=0,
mc__FqfX335mhKWi1ejj7ZZeN=0;real_T*mc__fnWFVFIaNh0j1DpN2ygH1=NULL;int32_T*
mc_kXeDcvuOSpSqamcA4a5jc_=mc_VknkCg_msB8Ga9ymQtGggf->mJc;int32_T*
mc_VEXzFHKjFN87iiOtLrddNz=mc_VknkCg_msB8Ga9ymQtGggf->mIr;int32_T
mc_kjn0E4w0eVx6eL0BQDhSHC=0;real_T mc_ViKHq7CnFBKVdi6Gb6ljiV=0.0;real_T*
mc_FzyLWRgau0pMYq2XSI3ETL=pm__YmIqNX3g5Sub1vKK1hZQF->mX;real_T*A=
mc_FCZxG6Iux_GKX1lkqasXdQ->mX;(void)0;;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_VVRAoFgW2Hphcy7H6H9Oh0;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc__fnWFVFIaNh0j1DpN2ygH1=mc_FybTf2SinthyWqOxvPdJ5h[mc_kwrB3ZoKf7OufTHWaHJV7a]
.mX;mc__FqfX335mhKWi1ejj7ZZeN=mc_FybTf2SinthyWqOxvPdJ5h[
mc_kwrB3ZoKf7OufTHWaHJV7a].mN;for(mc_V2__YrimeI4E_yWnhKofpy=0;
mc_V2__YrimeI4E_yWnhKofpy<mc__FqfX335mhKWi1ejj7ZZeN;mc_V2__YrimeI4E_yWnhKofpy
++,mc_kyp6uAyJE40UVuAQNEYzS1++){mc_ViKHq7CnFBKVdi6Gb6ljiV=
mc__fnWFVFIaNh0j1DpN2ygH1[mc_V2__YrimeI4E_yWnhKofpy];for(
mc_kjn0E4w0eVx6eL0BQDhSHC=mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1]
;mc_kjn0E4w0eVx6eL0BQDhSHC<mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1
+1];mc_kjn0E4w0eVx6eL0BQDhSHC++){mc_FzyLWRgau0pMYq2XSI3ETL[
mc_VEXzFHKjFN87iiOtLrddNz[mc_kjn0E4w0eVx6eL0BQDhSHC]]+=
mc_ViKHq7CnFBKVdi6Gb6ljiV*A[mc_kjn0E4w0eVx6eL0BQDhSHC];}}}(void)0;;}void
mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat){size_t mc__jwySfHyx1SXgXJeVWoIzb=
mc_VknkCg_msB8Ga9ymQtGggf->mNumCol,mc_FdNKyaRLqeWhg5tGqF_VYT=
mc_VknkCg_msB8Ga9ymQtGggf->mNumRow,mc_kyp6uAyJE40UVuAQNEYzS1=0;int32_T*
mc_kXeDcvuOSpSqamcA4a5jc_=mc_VknkCg_msB8Ga9ymQtGggf->mJc;int32_T*
mc_VEXzFHKjFN87iiOtLrddNz=mc_VknkCg_msB8Ga9ymQtGggf->mIr;int32_T
mc_kjn0E4w0eVx6eL0BQDhSHC=0;real_T mc_ViKHq7CnFBKVdi6Gb6ljiV=0.0;real_T*x=
pm__hARyx1bZBxVj1boVQqdtV->mX;real_T*mc_FzyLWRgau0pMYq2XSI3ETL=
pm__YmIqNX3g5Sub1vKK1hZQF->mX;real_T*A=mc_FCZxG6Iux_GKX1lkqasXdQ->mX;real_T*
mc_VRZCD_UL_ESThy75dC9J8D=mc_VxvrZHk3QVKlWycYYdZEat->mX;(void)0;;(void)0;;(
void)0;;(void)0;;mc__aNO1s5qwzt6fXwft5YgCz(mc_VxvrZHk3QVKlWycYYdZEat);for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc__jwySfHyx1SXgXJeVWoIzb;mc_kyp6uAyJE40UVuAQNEYzS1++){
mc_ViKHq7CnFBKVdi6Gb6ljiV=x[mc_kyp6uAyJE40UVuAQNEYzS1];for(
mc_kjn0E4w0eVx6eL0BQDhSHC=mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1]
;mc_kjn0E4w0eVx6eL0BQDhSHC<mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1
+1];mc_kjn0E4w0eVx6eL0BQDhSHC++){mc_VRZCD_UL_ESThy75dC9J8D[
mc_VEXzFHKjFN87iiOtLrddNz[mc_kjn0E4w0eVx6eL0BQDhSHC]]+=
mc_ViKHq7CnFBKVdi6Gb6ljiV*A[mc_kjn0E4w0eVx6eL0BQDhSHC];}}for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc_FdNKyaRLqeWhg5tGqF_VYT;mc_kyp6uAyJE40UVuAQNEYzS1++){
mc_FzyLWRgau0pMYq2XSI3ETL[mc_kyp6uAyJE40UVuAQNEYzS1]+=
mc_VRZCD_UL_ESThy75dC9J8D[mc_kyp6uAyJE40UVuAQNEYzS1];}
mc__aNO1s5qwzt6fXwft5YgCz(mc_VxvrZHk3QVKlWycYYdZEat);}void
mc_kLGj2IdnGDG_YeEKAnMkUr(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV){size_t
mc__jwySfHyx1SXgXJeVWoIzb=mc_VknkCg_msB8Ga9ymQtGggf->mNumCol;size_t
mc_FdNKyaRLqeWhg5tGqF_VYT=mc_VknkCg_msB8Ga9ymQtGggf->mNumRow;size_t
mc_kyp6uAyJE40UVuAQNEYzS1=0;int32_T*mc_kXeDcvuOSpSqamcA4a5jc_=
mc_VknkCg_msB8Ga9ymQtGggf->mJc;int32_T*mc_VEXzFHKjFN87iiOtLrddNz=
mc_VknkCg_msB8Ga9ymQtGggf->mIr;int32_T mc_kjn0E4w0eVx6eL0BQDhSHC=0;real_T
mc_ViKHq7CnFBKVdi6Gb6ljiV=0.0;real_T*x=pm__hARyx1bZBxVj1boVQqdtV->mX;real_T*
mc_FzyLWRgau0pMYq2XSI3ETL=pm__YmIqNX3g5Sub1vKK1hZQF->mX;real_T*A=
mc_FCZxG6Iux_GKX1lkqasXdQ->mX;(void)0;;(void)0;;(void)0;;for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc__jwySfHyx1SXgXJeVWoIzb;mc_kyp6uAyJE40UVuAQNEYzS1++){
mc_ViKHq7CnFBKVdi6Gb6ljiV=x[mc_kyp6uAyJE40UVuAQNEYzS1];for(
mc_kjn0E4w0eVx6eL0BQDhSHC=mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1]
;mc_kjn0E4w0eVx6eL0BQDhSHC<mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1
+1];mc_kjn0E4w0eVx6eL0BQDhSHC++){mc_FzyLWRgau0pMYq2XSI3ETL[
mc_VEXzFHKjFN87iiOtLrddNz[mc_kjn0E4w0eVx6eL0BQDhSHC]]+=
mc_ViKHq7CnFBKVdi6Gb6ljiV*fabs(A[mc_kjn0E4w0eVx6eL0BQDhSHC]);}}}void
mc_FJN_drUOKh_igHJXVH7xls(const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const
PmRealVector*mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*
mc_V_ku0ZO8TOxhc9438tlsBI,size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T
mc_kcda_aHAM4WIXuM_xBDdLt){int32_T*mc__eEPwny6zCSWWeq441_0uF=
mc_V_ku0ZO8TOxhc9438tlsBI->mIr;int32_T*mc___9tQNFfF1C_WaC9dTIz3Q=
mc_V_ku0ZO8TOxhc9438tlsBI->mJc;real_T*mc_VcTmhTCl9S_Kh5Tzjj6QyV=
mc_V8ujEMKrDU8Q_mvu4yja1b->mX;real_T*mc_k2mR0INwQSCheHKCBKnq6o=
mc_FzyLWRgau0pMYq2XSI3ETL->mX;int32_T mc_kh3C5f6ZAPlGWXfJykpWPn=0;(void)0;;(
void)0;;(void)0;;for(mc_kh3C5f6ZAPlGWXfJykpWPn=mc___9tQNFfF1C_WaC9dTIz3Q[
mc_kyp6uAyJE40UVuAQNEYzS1];mc_kh3C5f6ZAPlGWXfJykpWPn<mc___9tQNFfF1C_WaC9dTIz3Q
[mc_kyp6uAyJE40UVuAQNEYzS1+1];mc_kh3C5f6ZAPlGWXfJykpWPn++){int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a=mc__eEPwny6zCSWWeq441_0uF[mc_kh3C5f6ZAPlGWXfJykpWPn]
;mc_k2mR0INwQSCheHKCBKnq6o[mc_kwrB3ZoKf7OufTHWaHJV7a]+=
mc_kcda_aHAM4WIXuM_xBDdLt*mc_VcTmhTCl9S_Kh5Tzjj6QyV[mc_kh3C5f6ZAPlGWXfJykpWPn]
;}}void mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr
,const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL){real_T*
mc_FBuROKTP_gCWgT_XDEoCzK=mc_FBDi_PCg670TjHgJTNPcHr->mX;real_T*
mc_VnIU3pm_im4PdeIcvHeFon=x->mX;real_T*mc_k2mR0INwQSCheHKCBKnq6o=
mc_FzyLWRgau0pMYq2XSI3ETL->mX;size_t mc_kh3C5f6ZAPlGWXfJykpWPn=0;size_t
mc_V5LBNJCbhICNbmMG_hLaZ6=x->mN;size_t mc_VBS7W7jeELG_Zu4dt4HciP=
mc_FzyLWRgau0pMYq2XSI3ETL->mN;(void)0;;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;
mc_kh3C5f6ZAPlGWXfJykpWPn<mc_V5LBNJCbhICNbmMG_hLaZ6;mc_kh3C5f6ZAPlGWXfJykpWPn
++){*(mc_FBuROKTP_gCWgT_XDEoCzK++)+= *(mc_VnIU3pm_im4PdeIcvHeFon++);}for(
mc_kh3C5f6ZAPlGWXfJykpWPn=0;mc_kh3C5f6ZAPlGWXfJykpWPn<
mc_VBS7W7jeELG_Zu4dt4HciP;mc_kh3C5f6ZAPlGWXfJykpWPn++){*(
mc_FBuROKTP_gCWgT_XDEoCzK++)+= *(mc_k2mR0INwQSCheHKCBKnq6o++);}}void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo){real_T*mc_V7rS_i_HqL0QbqhHOCqTGM=
mc_FrF2gTbWxox8geiSROFaFn->mX;size_t mc_k7G_R2S7iIOLditRzSZy_A=
mc_FrF2gTbWxox8geiSROFaFn->mN;size_t mc_kLMRRiSdJr4aaLEtYiWmgE=
mc_VwOeyeOYCKdcVTySJQVoLE->mN;int32_T*mc_kBUCnEe8bHleguUSrC1m30=
mc__sdtG1OgJQtqcikFA20Doo->mX;real_T*mc_FkXPOsDyktKOYDtXnwTXgE=
mc_VwOeyeOYCKdcVTySJQVoLE->mX;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;(void)0;;(
void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_k7G_R2S7iIOLditRzSZy_A;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_V7rS_i_HqL0QbqhHOCqTGM[mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_FkXPOsDyktKOYDtXnwTXgE
[mc_kBUCnEe8bHleguUSrC1m30[mc_kwrB3ZoKf7OufTHWaHJV7a]];}}void
mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const PmRealVector*
mc_VwOeyeOYCKdcVTySJQVoLE){real_T*mc_V7rS_i_HqL0QbqhHOCqTGM=
mc_FrF2gTbWxox8geiSROFaFn->mX;size_t mc_k7G_R2S7iIOLditRzSZy_A=
mc_FrF2gTbWxox8geiSROFaFn->mN;size_t mc_kLMRRiSdJr4aaLEtYiWmgE=
mc_VwOeyeOYCKdcVTySJQVoLE->mN;int32_T*mc_kBUCnEe8bHleguUSrC1m30=
mc__sdtG1OgJQtqcikFA20Doo->mX;real_T*mc_FkXPOsDyktKOYDtXnwTXgE=
mc_VwOeyeOYCKdcVTySJQVoLE->mX;size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;(void)0;;(
void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_kLMRRiSdJr4aaLEtYiWmgE;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_V7rS_i_HqL0QbqhHOCqTGM[mc_kBUCnEe8bHleguUSrC1m30[mc_kwrB3ZoKf7OufTHWaHJV7a]
]=mc_FkXPOsDyktKOYDtXnwTXgE[mc_kwrB3ZoKf7OufTHWaHJV7a];}}void
mc_VjzTgsx19j0KfHv6VXr4Mp(const PmRealVector*a,const PmIntVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b){real_T*A=a->mX;int_T*
mc_V3EARHOeJplfYqns0fCgtY=mc_kwrB3ZoKf7OufTHWaHJV7a->mX;real_T*
mc_Vqiy96WqvuhCaXm5e_vvT0=b->mX;size_t mc_kh3C5f6ZAPlGWXfJykpWPn=0,
mc__BwCbGCDlrx2gDK5rof3H8=0;size_t mc_k7G_R2S7iIOLditRzSZy_A=a->mN;size_t
mc__k0fc452T4WmfLlKvOB9N0=mc_kwrB3ZoKf7OufTHWaHJV7a->mN;(void)0;;(void)0;;
mc__BwCbGCDlrx2gDK5rof3H8=0;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;
mc_kh3C5f6ZAPlGWXfJykpWPn<mc__k0fc452T4WmfLlKvOB9N0;mc_kh3C5f6ZAPlGWXfJykpWPn
++){if(mc_V3EARHOeJplfYqns0fCgtY[mc_kh3C5f6ZAPlGWXfJykpWPn]!=0){(void)0;;A[
mc_kh3C5f6ZAPlGWXfJykpWPn]+=mc_Vqiy96WqvuhCaXm5e_vvT0[
mc__BwCbGCDlrx2gDK5rof3H8++];}}(void)0;;}void mc_V_Fp06wJOBhXZyLbA5xU0r(const
PmRealVector*a,const PmRealVector*b,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a){real_T*A=a->mX;real_T*mc_Vqiy96WqvuhCaXm5e_vvT0=b->
mX;boolean_T*mc_V3EARHOeJplfYqns0fCgtY=mc_kwrB3ZoKf7OufTHWaHJV7a->mX;size_t
mc_kh3C5f6ZAPlGWXfJykpWPn=0,mc__BwCbGCDlrx2gDK5rof3H8=0;(void)0;;(void)0;;
mc__BwCbGCDlrx2gDK5rof3H8=0;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;
mc_kh3C5f6ZAPlGWXfJykpWPn<mc_kwrB3ZoKf7OufTHWaHJV7a->mN;
mc_kh3C5f6ZAPlGWXfJykpWPn++){if(mc_V3EARHOeJplfYqns0fCgtY[
mc_kh3C5f6ZAPlGWXfJykpWPn]){A[mc__BwCbGCDlrx2gDK5rof3H8++]+=
mc_Vqiy96WqvuhCaXm5e_vvT0[mc_kh3C5f6ZAPlGWXfJykpWPn];}}(void)0;;}void
mc_FuY0t5xEb5_QhDQFQ_TXtc(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b){real_T*A=a->mX;real_T*
mc_Vqiy96WqvuhCaXm5e_vvT0=b->mX;boolean_T*mc_V3EARHOeJplfYqns0fCgtY=
mc_kwrB3ZoKf7OufTHWaHJV7a->mX;size_t mc_kh3C5f6ZAPlGWXfJykpWPn=0,
mc__BwCbGCDlrx2gDK5rof3H8=0;(void)0;;(void)0;;mc__BwCbGCDlrx2gDK5rof3H8=0;for(
mc_kh3C5f6ZAPlGWXfJykpWPn=0;mc_kh3C5f6ZAPlGWXfJykpWPn<a->mN;
mc_kh3C5f6ZAPlGWXfJykpWPn++){if(mc_V3EARHOeJplfYqns0fCgtY[
mc_kh3C5f6ZAPlGWXfJykpWPn]){A[mc_kh3C5f6ZAPlGWXfJykpWPn]+=
mc_Vqiy96WqvuhCaXm5e_vvT0[mc__BwCbGCDlrx2gDK5rof3H8++];}}(void)0;;}void
mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x){real_T*A=a->mX;boolean_T*
mc_V3EARHOeJplfYqns0fCgtY=mc_kwrB3ZoKf7OufTHWaHJV7a->mX;size_t
mc_kh3C5f6ZAPlGWXfJykpWPn=0;(void)0;;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;
mc_kh3C5f6ZAPlGWXfJykpWPn<a->mN;mc_kh3C5f6ZAPlGWXfJykpWPn++){if(
mc_V3EARHOeJplfYqns0fCgtY[mc_kh3C5f6ZAPlGWXfJykpWPn]){A[
mc_kh3C5f6ZAPlGWXfJykpWPn]=x;}}}void mc_kMo1w3ReRZGIdH5_MNwumc(const
PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector
*b){real_T*A=a->mX;real_T*mc_Vqiy96WqvuhCaXm5e_vvT0=b->mX;boolean_T*
mc_V3EARHOeJplfYqns0fCgtY=mc_kwrB3ZoKf7OufTHWaHJV7a->mX;size_t
mc_kh3C5f6ZAPlGWXfJykpWPn=0,mc__BwCbGCDlrx2gDK5rof3H8=0;(void)0;;(void)0;;
mc__BwCbGCDlrx2gDK5rof3H8=0;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;
mc_kh3C5f6ZAPlGWXfJykpWPn<a->mN;mc_kh3C5f6ZAPlGWXfJykpWPn++){if(
mc_V3EARHOeJplfYqns0fCgtY[mc_kh3C5f6ZAPlGWXfJykpWPn]){A[
mc_kh3C5f6ZAPlGWXfJykpWPn]=mc_Vqiy96WqvuhCaXm5e_vvT0[mc__BwCbGCDlrx2gDK5rof3H8
++];}}(void)0;;}void mc_VYxtXnMKT6hpb1FMldBDLs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b){real_T*A=a->mX;
real_T*mc_Vqiy96WqvuhCaXm5e_vvT0=b->mX;boolean_T*mc_V3EARHOeJplfYqns0fCgtY=
mc_kwrB3ZoKf7OufTHWaHJV7a->mX;size_t mc_kh3C5f6ZAPlGWXfJykpWPn=0;(void)0;;(
void)0;;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;mc_kh3C5f6ZAPlGWXfJykpWPn<a->mN;
mc_kh3C5f6ZAPlGWXfJykpWPn++){if(mc_V3EARHOeJplfYqns0fCgtY[
mc_kh3C5f6ZAPlGWXfJykpWPn]){A[mc_kh3C5f6ZAPlGWXfJykpWPn]=
mc_Vqiy96WqvuhCaXm5e_vvT0[mc_kh3C5f6ZAPlGWXfJykpWPn];}}}void
mc_kl_UmQrKbdCajPyXz5nOIL(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b){real_T*A=a->mX;real_T*
mc_Vqiy96WqvuhCaXm5e_vvT0=b->mX;boolean_T*mc_V3EARHOeJplfYqns0fCgtY=
mc_kwrB3ZoKf7OufTHWaHJV7a->mX;size_t mc_kh3C5f6ZAPlGWXfJykpWPn=0;(void)0;;(
void)0;;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;mc_kh3C5f6ZAPlGWXfJykpWPn<a->mN;
mc_kh3C5f6ZAPlGWXfJykpWPn++){if(!mc_V3EARHOeJplfYqns0fCgtY[
mc_kh3C5f6ZAPlGWXfJykpWPn]){A[mc_kh3C5f6ZAPlGWXfJykpWPn]=
mc_Vqiy96WqvuhCaXm5e_vvT0[mc_kh3C5f6ZAPlGWXfJykpWPn];}}}void
mc_k2E2oWXDqshMeuCQWrbaKT(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b){int32_T*A=a->mX;int32_T*
mc_Vqiy96WqvuhCaXm5e_vvT0=b->mX;boolean_T*mc_V3EARHOeJplfYqns0fCgtY=
mc_kwrB3ZoKf7OufTHWaHJV7a->mX;size_t mc_kh3C5f6ZAPlGWXfJykpWPn=0,
mc__BwCbGCDlrx2gDK5rof3H8=0;(void)0;;(void)0;;mc__BwCbGCDlrx2gDK5rof3H8=0;for(
mc_kh3C5f6ZAPlGWXfJykpWPn=0;mc_kh3C5f6ZAPlGWXfJykpWPn<a->mN;
mc_kh3C5f6ZAPlGWXfJykpWPn++){if(mc_V3EARHOeJplfYqns0fCgtY[
mc_kh3C5f6ZAPlGWXfJykpWPn]){A[mc_kh3C5f6ZAPlGWXfJykpWPn]+=
mc_Vqiy96WqvuhCaXm5e_vvT0[mc__BwCbGCDlrx2gDK5rof3H8++];}}(void)0;;}void
mc_FBaB5196Xx0ohX_IWM5ypL(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T x){int32_T*A=a->mX;boolean_T*
mc_V3EARHOeJplfYqns0fCgtY=mc_kwrB3ZoKf7OufTHWaHJV7a->mX;size_t
mc_kh3C5f6ZAPlGWXfJykpWPn=0;(void)0;;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;
mc_kh3C5f6ZAPlGWXfJykpWPn<a->mN;mc_kh3C5f6ZAPlGWXfJykpWPn++){if(
mc_V3EARHOeJplfYqns0fCgtY[mc_kh3C5f6ZAPlGWXfJykpWPn]){A[
mc_kh3C5f6ZAPlGWXfJykpWPn]=x;}}}void mc_F1CG0fHJYfd_ealLMx7Z7U(const
PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b
){int32_T*A=a->mX;int32_T*mc_Vqiy96WqvuhCaXm5e_vvT0=b->mX;boolean_T*
mc_V3EARHOeJplfYqns0fCgtY=mc_kwrB3ZoKf7OufTHWaHJV7a->mX;size_t
mc_kh3C5f6ZAPlGWXfJykpWPn=0,mc__BwCbGCDlrx2gDK5rof3H8=0;(void)0;;(void)0;;
mc__BwCbGCDlrx2gDK5rof3H8=0;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;
mc_kh3C5f6ZAPlGWXfJykpWPn<a->mN;mc_kh3C5f6ZAPlGWXfJykpWPn++){if(
mc_V3EARHOeJplfYqns0fCgtY[mc_kh3C5f6ZAPlGWXfJykpWPn]){A[
mc_kh3C5f6ZAPlGWXfJykpWPn]=mc_Vqiy96WqvuhCaXm5e_vvT0[mc__BwCbGCDlrx2gDK5rof3H8
++];}}(void)0;;}void mc_krXbD205SBpghif1h1n_ei(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b){int32_T*A=a->mX;
int32_T*mc_Vqiy96WqvuhCaXm5e_vvT0=b->mX;boolean_T*mc_V3EARHOeJplfYqns0fCgtY=
mc_kwrB3ZoKf7OufTHWaHJV7a->mX;size_t mc_kh3C5f6ZAPlGWXfJykpWPn=0;(void)0;;(
void)0;;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;mc_kh3C5f6ZAPlGWXfJykpWPn<a->mN;
mc_kh3C5f6ZAPlGWXfJykpWPn++){if(mc_V3EARHOeJplfYqns0fCgtY[
mc_kh3C5f6ZAPlGWXfJykpWPn]){A[mc_kh3C5f6ZAPlGWXfJykpWPn]=
mc_Vqiy96WqvuhCaXm5e_vvT0[mc_kh3C5f6ZAPlGWXfJykpWPn];}}}void
mc__Qtfmi680EKpj1bOrIroGr(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b){int32_T*A=a->mX;int32_T*
mc_Vqiy96WqvuhCaXm5e_vvT0=b->mX;boolean_T*mc_V3EARHOeJplfYqns0fCgtY=
mc_kwrB3ZoKf7OufTHWaHJV7a->mX;size_t mc_kh3C5f6ZAPlGWXfJykpWPn=0;(void)0;;(
void)0;;for(mc_kh3C5f6ZAPlGWXfJykpWPn=0;mc_kh3C5f6ZAPlGWXfJykpWPn<a->mN;
mc_kh3C5f6ZAPlGWXfJykpWPn++){if(!mc_V3EARHOeJplfYqns0fCgtY[
mc_kh3C5f6ZAPlGWXfJykpWPn]){A[mc_kh3C5f6ZAPlGWXfJykpWPn]=
mc_Vqiy96WqvuhCaXm5e_vvT0[mc_kh3C5f6ZAPlGWXfJykpWPn];}}}void
mc__0IkRn0eQ9Wc_u8mCNbQDh(const PmIntVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx){size_t mc_kyp6uAyJE40UVuAQNEYzS1=
0;int32_T*mc_VgJW5ZqpwPpuY1inYtaofQ=mc_VUELvXWGXPlKf1brR9MRC3->mX;int32_T*
mc_kXeDcvuOSpSqamcA4a5jc_=mc_FBOWjCOBM8SyhqFe64oqrx->mJc;(void)0;;
mc_k9wkPuvMCi4DY1yebDQPHf(mc_VUELvXWGXPlKf1brR9MRC3);for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc_FBOWjCOBM8SyhqFe64oqrx->mNumCol;mc_kyp6uAyJE40UVuAQNEYzS1++){(void)0;;if(
mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1]<mc_kXeDcvuOSpSqamcA4a5jc_
[mc_kyp6uAyJE40UVuAQNEYzS1+1]){mc_VgJW5ZqpwPpuY1inYtaofQ[
mc_kyp6uAyJE40UVuAQNEYzS1]=1;}}}void mc_VpjBXBa8TTCl_uBXYMLfxC(const
PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx){size_t mc_kyp6uAyJE40UVuAQNEYzS1=0;boolean_T*
mc_VgJW5ZqpwPpuY1inYtaofQ=mc_VUELvXWGXPlKf1brR9MRC3->mX;int32_T*
mc_kXeDcvuOSpSqamcA4a5jc_=mc_FBOWjCOBM8SyhqFe64oqrx->mJc;(void)0;;for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc_FBOWjCOBM8SyhqFe64oqrx->mNumCol;mc_kyp6uAyJE40UVuAQNEYzS1++){(void)0;;if(
mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1]<mc_kXeDcvuOSpSqamcA4a5jc_
[mc_kyp6uAyJE40UVuAQNEYzS1+1]){mc_VgJW5ZqpwPpuY1inYtaofQ[
mc_kyp6uAyJE40UVuAQNEYzS1]=true;}}}void mc__pbFNjwg_bCPdPFSjC2Wdv(const
PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx){mc_VWloU5QD6gpaXeK8lmytFA(mc_VUELvXWGXPlKf1brR9MRC3
);mc_VpjBXBa8TTCl_uBXYMLfxC(mc_VUELvXWGXPlKf1brR9MRC3,
mc_FBOWjCOBM8SyhqFe64oqrx);}void mc__pFtu1g17h8ZaaZK4PpTkb(const PmBoolVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx){
int32_T*mc__eEPwny6zCSWWeq441_0uF=mc_FBOWjCOBM8SyhqFe64oqrx->mIr;int32_T*
mc___9tQNFfF1C_WaC9dTIz3Q=mc_FBOWjCOBM8SyhqFe64oqrx->mJc;boolean_T*
mc_VgJW5ZqpwPpuY1inYtaofQ=mc_VUELvXWGXPlKf1brR9MRC3->mX;size_t
mc_kyp6uAyJE40UVuAQNEYzS1=0;int32_T mc_kh3C5f6ZAPlGWXfJykpWPn=0;(void)0;;
mc_VWloU5QD6gpaXeK8lmytFA(mc_VUELvXWGXPlKf1brR9MRC3);for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc_FBOWjCOBM8SyhqFe64oqrx->mNumCol;mc_kyp6uAyJE40UVuAQNEYzS1++){for(
mc_kh3C5f6ZAPlGWXfJykpWPn=mc___9tQNFfF1C_WaC9dTIz3Q[mc_kyp6uAyJE40UVuAQNEYzS1]
;mc_kh3C5f6ZAPlGWXfJykpWPn<mc___9tQNFfF1C_WaC9dTIz3Q[mc_kyp6uAyJE40UVuAQNEYzS1
+1];mc_kh3C5f6ZAPlGWXfJykpWPn++){mc_VgJW5ZqpwPpuY1inYtaofQ[
mc__eEPwny6zCSWWeq441_0uF[mc_kh3C5f6ZAPlGWXfJykpWPn]]=true;}}}void
mc_kMScbNM1RKOTaD4QwTME8Y(const PmBoolVector*mc__1Zf2IciMRCub1vvbEr1C4,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc__LA_p_vKNdOf_an832S3i6){int32_T*mc_VEXzFHKjFN87iiOtLrddNz=
mc__srK5LmyWw42ZyPnbOWDWJ->mIr;int32_T*mc_kXeDcvuOSpSqamcA4a5jc_=
mc__srK5LmyWw42ZyPnbOWDWJ->mJc;real_T*mc_VlnhKi82gfCLgumIqeduOq=
mc__LA_p_vKNdOf_an832S3i6->mX;boolean_T*mc_Fbnx9FOLhnW0X1Wd233Ai7=
mc__1Zf2IciMRCub1vvbEr1C4->mX;size_t mc_kyp6uAyJE40UVuAQNEYzS1=0;int32_T
mc_kh3C5f6ZAPlGWXfJykpWPn=0;(void)0;;mc_VWloU5QD6gpaXeK8lmytFA(
mc__1Zf2IciMRCub1vvbEr1C4);for(mc_kyp6uAyJE40UVuAQNEYzS1=0;
mc_kyp6uAyJE40UVuAQNEYzS1<mc__srK5LmyWw42ZyPnbOWDWJ->mNumCol;
mc_kyp6uAyJE40UVuAQNEYzS1++){for(mc_kh3C5f6ZAPlGWXfJykpWPn=
mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1];mc_kh3C5f6ZAPlGWXfJykpWPn
<mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1+1];
mc_kh3C5f6ZAPlGWXfJykpWPn++){mc_Fbnx9FOLhnW0X1Wd233Ai7[
mc_VEXzFHKjFN87iiOtLrddNz[mc_kh3C5f6ZAPlGWXfJykpWPn]]=
mc_Fbnx9FOLhnW0X1Wd233Ai7[mc_VEXzFHKjFN87iiOtLrddNz[mc_kh3C5f6ZAPlGWXfJykpWPn]
]||(mc_VlnhKi82gfCLgumIqeduOq[mc_kh3C5f6ZAPlGWXfJykpWPn]!=0.0);}}}void
mc_Fbsqat6MlL0bjPHlNxax8t(const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV){size_t mc__jwySfHyx1SXgXJeVWoIzb=
mc_VknkCg_msB8Ga9ymQtGggf->mNumCol;size_t mc_FdNKyaRLqeWhg5tGqF_VYT=
mc_VknkCg_msB8Ga9ymQtGggf->mNumRow;size_t mc_kyp6uAyJE40UVuAQNEYzS1=0;int32_T*
mc_kXeDcvuOSpSqamcA4a5jc_=mc_VknkCg_msB8Ga9ymQtGggf->mJc;int32_T*
mc_VEXzFHKjFN87iiOtLrddNz=mc_VknkCg_msB8Ga9ymQtGggf->mIr;int32_T
mc_kjn0E4w0eVx6eL0BQDhSHC=0;boolean_T*x=pm__hARyx1bZBxVj1boVQqdtV->mX;
boolean_T*mc_FzyLWRgau0pMYq2XSI3ETL=pm__YmIqNX3g5Sub1vKK1hZQF->mX;(void)0;;(
void)0;;for(mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc__jwySfHyx1SXgXJeVWoIzb;mc_kyp6uAyJE40UVuAQNEYzS1++){if(x[
mc_kyp6uAyJE40UVuAQNEYzS1]){for(mc_kjn0E4w0eVx6eL0BQDhSHC=
mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1];mc_kjn0E4w0eVx6eL0BQDhSHC
<mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1+1];
mc_kjn0E4w0eVx6eL0BQDhSHC++){mc_FzyLWRgau0pMYq2XSI3ETL[
mc_VEXzFHKjFN87iiOtLrddNz[mc_kjn0E4w0eVx6eL0BQDhSHC]]=true;}}}}void
mc_FSAdXYnRP9pkfmWBYlMkJJ(const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*
mc_F8fT7naL9bOcimTADCVzTC){size_t pm_kplAJmOlA30feiNcOzi7oj=0;size_t
mc_kwrB3ZoKf7OufTHWaHJV7a=0;(void)0;;(void)0;;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<((size_t)(mc__srK5LmyWw42ZyPnbOWDWJ)->mJc[(
mc__srK5LmyWw42ZyPnbOWDWJ)->mNumCol]);mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
mc_F8fT7naL9bOcimTADCVzTC->mX[mc__srK5LmyWw42ZyPnbOWDWJ->mIr[
mc_kwrB3ZoKf7OufTHWaHJV7a]]){mc_kVkvrfpzuVduaPTr5FLF8K->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]=0.0;}}}void mc__NertSre4cWh_mN2RJ5UPq(const
PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*mc_VCVhWy_VaDhraHrlfFWxBa){size_t
pm_Fr_bHKkQKFWbfi50VWd5Pw=0;size_t mc_kyp6uAyJE40UVuAQNEYzS1=0;(void)0;;(void)
0;;for(mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc__srK5LmyWw42ZyPnbOWDWJ->mNumCol;++mc_kyp6uAyJE40UVuAQNEYzS1){if(
mc_VCVhWy_VaDhraHrlfFWxBa->mX[mc_kyp6uAyJE40UVuAQNEYzS1]){int32_T*
mc_kXeDcvuOSpSqamcA4a5jc_=mc__srK5LmyWw42ZyPnbOWDWJ->mJc;int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a=0;for(mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1];mc_kwrB3ZoKf7OufTHWaHJV7a
<mc_kXeDcvuOSpSqamcA4a5jc_[mc_kyp6uAyJE40UVuAQNEYzS1+1];++
mc_kwrB3ZoKf7OufTHWaHJV7a){mc_kVkvrfpzuVduaPTr5FLF8K->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]=0.0;}}}}PmRealVector mc_VPFwoVShg1G3XTwou1_jbC(
const PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,size_t mc_Fyss_XM3F_C4dm6IKoDw4G,
size_t mc_Vs6xonQX17Krc5vXv8T_zq){PmRealVector mc_V2mBNcV1EqCifyH9UdCbkF;(void
)0;;(void)0;;(void)0;;mc_V2mBNcV1EqCifyH9UdCbkF.mN=mc_Vs6xonQX17Krc5vXv8T_zq-
mc_Fyss_XM3F_C4dm6IKoDw4G;mc_V2mBNcV1EqCifyH9UdCbkF.mX=
mc_VgJW5ZqpwPpuY1inYtaofQ->mX+mc_Fyss_XM3F_C4dm6IKoDw4G;return
mc_V2mBNcV1EqCifyH9UdCbkF;}
