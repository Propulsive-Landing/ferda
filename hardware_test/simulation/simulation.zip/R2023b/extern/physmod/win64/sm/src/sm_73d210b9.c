#include "pm_std.h"
struct sm__86ZcO1AmuChiX5wQ615hE;struct sm_kehBh_Z8yi4ocL9z8E2Sl5{size_t
sm__VyGPUhHOUGr_9l0UciNgg;size_t sm__ZBqXvglQt_BhaAcrCFP7W;size_t*
sm_VELrIEUHeudCamAhgAMD2P;};typedef struct sm_kehBh_Z8yi4ocL9z8E2Sl5
sm_k7K6KZXM_08mdmRyOXTrui;void sm_core_SmSizeTVector_create(
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw,size_t n,size_t
pm_kpzAtHMD4_WnheH0UiioSE);void sm_core_SmSizeTVector_copy(
sm_k7K6KZXM_08mdmRyOXTrui*sm_kyVvGx32uvlKVTEMWrNekp,const
sm_k7K6KZXM_08mdmRyOXTrui*orig);void sm_core_SmSizeTVector_destroy(
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw);int
sm_core_SmSizeTVector_isEmpty(const sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw);size_t sm_core_SmSizeTVector_size(const
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw);size_t
sm_core_SmSizeTVector_capacity(const sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw);size_t sm_core_SmSizeTVector_value(const
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw,size_t
sm__wN5g_p_uwdVVLfRtx9szc);void sm_core_SmSizeTVector_setValue(
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw,size_t
sm__wN5g_p_uwdVVLfRtx9szc,size_t sm_kg4CyRgbu6OdeewZOel7Qx);const size_t*
sm_core_SmSizeTVector_values(const sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw);size_t*sm_core_SmSizeTVector_nonConstValues(
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw);void
sm_core_SmSizeTVector_reserve(sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw,size_t n);void sm_core_SmSizeTVector_clear(
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw);void
sm_core_SmSizeTVector_pushBack(sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw,size_t pm_kpzAtHMD4_WnheH0UiioSE);void
sm_core_SmSizeTVector_popBack(sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw);void sm_core_SmSizeTVector_assignFromBoundedSet(
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw,const struct
sm__86ZcO1AmuChiX5wQ615hE*sm_Fnt04uhLkDWuYXj9o_cpB6);struct
sm__86ZcO1AmuChiX5wQ615hE{size_t sm_VobqE_as4__3W9a6zbgq0x;unsigned char*
sm_FgUP9l3DqHWwgy6WveH3ZJ;};typedef struct sm__86ZcO1AmuChiX5wQ615hE
sm_koCjJG_z1QWpXeGI5fHIzh;void sm_core_SmBoundedSet_create(
sm_koCjJG_z1QWpXeGI5fHIzh*sm_Fnt04uhLkDWuYXj9o_cpB6,size_t
sm_VUsSkoTm1_CqXeiwqxIZO4);void sm_core_SmBoundedSet_copy(
sm_koCjJG_z1QWpXeGI5fHIzh*sm_kyVvGx32uvlKVTEMWrNekp,const
sm_koCjJG_z1QWpXeGI5fHIzh*orig);void sm_core_SmBoundedSet_assign(
sm_koCjJG_z1QWpXeGI5fHIzh*dst,const sm_koCjJG_z1QWpXeGI5fHIzh*src);void
sm_core_SmBoundedSet_destroy(sm_koCjJG_z1QWpXeGI5fHIzh*
sm_Fnt04uhLkDWuYXj9o_cpB6);size_t sm_core_SmBoundedSet_bound(const
sm_koCjJG_z1QWpXeGI5fHIzh*sm_Fnt04uhLkDWuYXj9o_cpB6);size_t
sm_core_SmBoundedSet_size(const sm_koCjJG_z1QWpXeGI5fHIzh*
sm_Fnt04uhLkDWuYXj9o_cpB6);boolean_T sm_core_SmBoundedSet_isMember(const
sm_koCjJG_z1QWpXeGI5fHIzh*sm_Fnt04uhLkDWuYXj9o_cpB6,size_t
sm_FL1llpmubk_sXeD10Sbe3f);void sm_core_SmBoundedSet_clear(
sm_koCjJG_z1QWpXeGI5fHIzh*sm_Fnt04uhLkDWuYXj9o_cpB6);void
sm_core_SmBoundedSet_insert(sm_koCjJG_z1QWpXeGI5fHIzh*
sm_Fnt04uhLkDWuYXj9o_cpB6,size_t sm_FL1llpmubk_sXeD10Sbe3f);void
sm_core_SmBoundedSet_remove(sm_koCjJG_z1QWpXeGI5fHIzh*
sm_Fnt04uhLkDWuYXj9o_cpB6,size_t sm_FL1llpmubk_sXeD10Sbe3f);void
sm_core_SmBoundedSet_complement(const sm_koCjJG_z1QWpXeGI5fHIzh*
sm_Fnt04uhLkDWuYXj9o_cpB6,sm_koCjJG_z1QWpXeGI5fHIzh*sm_FWjmyhJaz5WOf5x4yKSbtc)
;void sm_core_SmBoundedSet_intersection(const sm_koCjJG_z1QWpXeGI5fHIzh*a,
const sm_koCjJG_z1QWpXeGI5fHIzh*b,sm_koCjJG_z1QWpXeGI5fHIzh*
sm_FFZbGh27ya8eem_J_hUtAZ);void sm_core_SmBoundedSet_union(const
sm_koCjJG_z1QWpXeGI5fHIzh*a,const sm_koCjJG_z1QWpXeGI5fHIzh*b,
sm_koCjJG_z1QWpXeGI5fHIzh*sm_FFZbGh27ya8eem_J_hUtAZ);void
sm_core_SmBoundedSet_difference(const sm_koCjJG_z1QWpXeGI5fHIzh*a,const
sm_koCjJG_z1QWpXeGI5fHIzh*b,sm_koCjJG_z1QWpXeGI5fHIzh*
sm_FFZbGh27ya8eem_J_hUtAZ);
#include "string.h"
#include "pm_std.h"
#include "pm_std.h"
void sm_core_SmSizeTVector_create(sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw,size_t n,size_t pm_kpzAtHMD4_WnheH0UiioSE){size_t
sm_kwrB3ZoKf7OufTHWaHJV7a;sm_VcZASgthsTt6dul8DlRWaw->sm__VyGPUhHOUGr_9l0UciNgg
=n;sm_VcZASgthsTt6dul8DlRWaw->sm__ZBqXvglQt_BhaAcrCFP7W=n;
sm_VcZASgthsTt6dul8DlRWaw->sm_VELrIEUHeudCamAhgAMD2P=pmf_malloc(n*sizeof(
size_t));(void)0;;for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;sm_kwrB3ZoKf7OufTHWaHJV7a<n;
++sm_kwrB3ZoKf7OufTHWaHJV7a)sm_VcZASgthsTt6dul8DlRWaw->
sm_VELrIEUHeudCamAhgAMD2P[sm_kwrB3ZoKf7OufTHWaHJV7a]=pm_kpzAtHMD4_WnheH0UiioSE
;}void sm_core_SmSizeTVector_copy(sm_k7K6KZXM_08mdmRyOXTrui*
sm_kyVvGx32uvlKVTEMWrNekp,const sm_k7K6KZXM_08mdmRyOXTrui*orig){const size_t n
=orig->sm__VyGPUhHOUGr_9l0UciNgg;sm_kyVvGx32uvlKVTEMWrNekp->
sm__VyGPUhHOUGr_9l0UciNgg=n;sm_kyVvGx32uvlKVTEMWrNekp->
sm__ZBqXvglQt_BhaAcrCFP7W=n;sm_kyVvGx32uvlKVTEMWrNekp->
sm_VELrIEUHeudCamAhgAMD2P=pmf_malloc(n*sizeof(size_t));(void)0;;memcpy(
sm_kyVvGx32uvlKVTEMWrNekp->sm_VELrIEUHeudCamAhgAMD2P,orig->
sm_VELrIEUHeudCamAhgAMD2P,n*sizeof(size_t));}void sm_core_SmSizeTVector_destroy
(sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw){
sm_VcZASgthsTt6dul8DlRWaw->sm__VyGPUhHOUGr_9l0UciNgg=0;
sm_VcZASgthsTt6dul8DlRWaw->sm__ZBqXvglQt_BhaAcrCFP7W=0;pmf_free(
sm_VcZASgthsTt6dul8DlRWaw->sm_VELrIEUHeudCamAhgAMD2P);}int
sm_core_SmSizeTVector_isEmpty(const sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw){return sm_VcZASgthsTt6dul8DlRWaw->
sm__VyGPUhHOUGr_9l0UciNgg==0;}size_t sm_core_SmSizeTVector_size(const
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw){return
sm_VcZASgthsTt6dul8DlRWaw->sm__VyGPUhHOUGr_9l0UciNgg;}size_t
sm_core_SmSizeTVector_capacity(const sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw){return sm_VcZASgthsTt6dul8DlRWaw->
sm__ZBqXvglQt_BhaAcrCFP7W;}size_t sm_core_SmSizeTVector_value(const
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw,size_t
sm__wN5g_p_uwdVVLfRtx9szc){return sm_VcZASgthsTt6dul8DlRWaw->
sm_VELrIEUHeudCamAhgAMD2P[sm__wN5g_p_uwdVVLfRtx9szc];}void
sm_core_SmSizeTVector_setValue(sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw,size_t sm__wN5g_p_uwdVVLfRtx9szc,size_t
sm_kg4CyRgbu6OdeewZOel7Qx){sm_VcZASgthsTt6dul8DlRWaw->
sm_VELrIEUHeudCamAhgAMD2P[sm__wN5g_p_uwdVVLfRtx9szc]=sm_kg4CyRgbu6OdeewZOel7Qx
;}const size_t*sm_core_SmSizeTVector_values(const sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw){return sm_VcZASgthsTt6dul8DlRWaw->
sm_VELrIEUHeudCamAhgAMD2P;}size_t*sm_core_SmSizeTVector_nonConstValues(
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw){return
sm_VcZASgthsTt6dul8DlRWaw->sm_VELrIEUHeudCamAhgAMD2P;}void
sm_core_SmSizeTVector_reserve(sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw,size_t n){if(sm_VcZASgthsTt6dul8DlRWaw->
sm__ZBqXvglQt_BhaAcrCFP7W<n){size_t*sm_V0NIpiHDZuOreH8HYF0R1c=pmf_malloc(n*
sizeof(size_t));(void)0;;memcpy(sm_V0NIpiHDZuOreH8HYF0R1c,
sm_VcZASgthsTt6dul8DlRWaw->sm_VELrIEUHeudCamAhgAMD2P,sm_VcZASgthsTt6dul8DlRWaw
->sm__VyGPUhHOUGr_9l0UciNgg*sizeof(size_t));pmf_free(sm_VcZASgthsTt6dul8DlRWaw
->sm_VELrIEUHeudCamAhgAMD2P);sm_VcZASgthsTt6dul8DlRWaw->
sm_VELrIEUHeudCamAhgAMD2P=sm_V0NIpiHDZuOreH8HYF0R1c;sm_VcZASgthsTt6dul8DlRWaw
->sm__ZBqXvglQt_BhaAcrCFP7W=n;}}void sm_core_SmSizeTVector_clear(
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw){sm_VcZASgthsTt6dul8DlRWaw
->sm__VyGPUhHOUGr_9l0UciNgg=0;}void sm_core_SmSizeTVector_pushBack(
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw,size_t
pm_kpzAtHMD4_WnheH0UiioSE){const size_t sm_FF4ljM6P4J09VTBr_9j0_n=
sm_VcZASgthsTt6dul8DlRWaw->sm__VyGPUhHOUGr_9l0UciNgg+1;if(
sm_FF4ljM6P4J09VTBr_9j0_n>sm_VcZASgthsTt6dul8DlRWaw->sm__ZBqXvglQt_BhaAcrCFP7W
){size_t*sm_V0NIpiHDZuOreH8HYF0R1c=NULL;size_t sm_kWBy9c3tvf0AfLsF3yPjEJ=1;
while((sm_kWBy9c3tvf0AfLsF3yPjEJ<sm_FF4ljM6P4J09VTBr_9j0_n)&&
sm_kWBy9c3tvf0AfLsF3yPjEJ)sm_kWBy9c3tvf0AfLsF3yPjEJ<<=1;(void)0;;
sm_V0NIpiHDZuOreH8HYF0R1c=pmf_malloc(sm_kWBy9c3tvf0AfLsF3yPjEJ*sizeof(size_t))
;(void)0;;memcpy(sm_V0NIpiHDZuOreH8HYF0R1c,sm_VcZASgthsTt6dul8DlRWaw->
sm_VELrIEUHeudCamAhgAMD2P,sm_VcZASgthsTt6dul8DlRWaw->sm__VyGPUhHOUGr_9l0UciNgg
*sizeof(size_t));pmf_free(sm_VcZASgthsTt6dul8DlRWaw->sm_VELrIEUHeudCamAhgAMD2P
);sm_VcZASgthsTt6dul8DlRWaw->sm_VELrIEUHeudCamAhgAMD2P=
sm_V0NIpiHDZuOreH8HYF0R1c;sm_VcZASgthsTt6dul8DlRWaw->sm__ZBqXvglQt_BhaAcrCFP7W
=sm_kWBy9c3tvf0AfLsF3yPjEJ;}sm_VcZASgthsTt6dul8DlRWaw->
sm_VELrIEUHeudCamAhgAMD2P[sm_VcZASgthsTt6dul8DlRWaw->sm__VyGPUhHOUGr_9l0UciNgg
]=pm_kpzAtHMD4_WnheH0UiioSE;++sm_VcZASgthsTt6dul8DlRWaw->
sm__VyGPUhHOUGr_9l0UciNgg;}void sm_core_SmSizeTVector_popBack(
sm_k7K6KZXM_08mdmRyOXTrui*sm_VcZASgthsTt6dul8DlRWaw){(void)0;;--
sm_VcZASgthsTt6dul8DlRWaw->sm__VyGPUhHOUGr_9l0UciNgg;}
#include "pm_std.h"
void sm_core_SmSizeTVector_assignFromBoundedSet(sm_k7K6KZXM_08mdmRyOXTrui*
sm_VcZASgthsTt6dul8DlRWaw,const sm_koCjJG_z1QWpXeGI5fHIzh*
sm_Fnt04uhLkDWuYXj9o_cpB6){const size_t sm_VUsSkoTm1_CqXeiwqxIZO4=
sm_core_SmBoundedSet_bound(sm_Fnt04uhLkDWuYXj9o_cpB6);const size_t n=
sm_core_SmBoundedSet_size(sm_Fnt04uhLkDWuYXj9o_cpB6);size_t*dst=
sm_VcZASgthsTt6dul8DlRWaw->sm_VELrIEUHeudCamAhgAMD2P;const size_t*
sm_Vs6xonQX17Krc5vXv8T_zq=sm_VcZASgthsTt6dul8DlRWaw->sm_VELrIEUHeudCamAhgAMD2P
+sm_VcZASgthsTt6dul8DlRWaw->sm__ZBqXvglQt_BhaAcrCFP7W;size_t
sm_kwrB3ZoKf7OufTHWaHJV7a;(void)0;;sm_VcZASgthsTt6dul8DlRWaw->
sm__VyGPUhHOUGr_9l0UciNgg=n;for(sm_kwrB3ZoKf7OufTHWaHJV7a=0;
sm_kwrB3ZoKf7OufTHWaHJV7a<sm_VUsSkoTm1_CqXeiwqxIZO4;++
sm_kwrB3ZoKf7OufTHWaHJV7a)if(sm_Fnt04uhLkDWuYXj9o_cpB6->
sm_FgUP9l3DqHWwgy6WveH3ZJ[sm_kwrB3ZoKf7OufTHWaHJV7a]!=0)*dst++=
sm_kwrB3ZoKf7OufTHWaHJV7a;(void)0;;while(dst<sm_Vs6xonQX17Krc5vXv8T_zq)*dst++=
0;}
