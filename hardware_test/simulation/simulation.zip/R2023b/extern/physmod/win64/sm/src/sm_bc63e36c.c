#include "pm_std.h"
#include "string.h"
#include "pm_std.h"
struct sm__gHKhnXjHqG_bmE4n_n7oj{unsigned int sm_kJgaJXMxmcWNji87yLe1qY;size_t
sm__bvXGsccASpPZq04dpvj2R;size_t sm__tIBZwGBHMt9i5WzLo_cJK;boolean_T
sm_VWJnZZhWbSW9WH_dg4R_Vo;int sm_FMziTw7JbQ0TiuguIfiueB;unsigned int
sm_FD_YTInyTSOFjHZmWWksYZ;char*sm_FTr_v3G_fcKDXyWVZ2Zd8Z;boolean_T
sm_Faok9Kyd8h0aV9H8z7cF7n;boolean_T sm__scPLHtW13KfVe4bctbn3w;real_T
sm_FEmgG6ukukWyWylA5gOE0K;boolean_T sm_k5uQCZ4MtK8ZiqcwkkJPdn;size_t
sm_FQRNaOaqWIKkaqijq_WFce;real_T sm_FQfFLTtYnStTbLV0vWkI1_[4];real_T
sm_kgRrjhEJupdGbPVBjU2z7p[1];};typedef struct sm__gHKhnXjHqG_bmE4n_n7oj
sm_Vi26HDD_kqSAV9B_gzlA6X;void sm_compiler_CTarget_create(
sm_Vi26HDD_kqSAV9B_gzlA6X*sm_kmw0A5bIHVxaWDlVPn2iKt);void
sm_compiler_CTarget_copy(const sm_Vi26HDD_kqSAV9B_gzlA6X*orig,
sm_Vi26HDD_kqSAV9B_gzlA6X*sm_kyVvGx32uvlKVTEMWrNekp);void
sm_compiler_CTarget_destroy(sm_Vi26HDD_kqSAV9B_gzlA6X*
sm_kmw0A5bIHVxaWDlVPn2iKt);void sm_compiler_CTarget_setSpecifiedUnit(const char
*sm_Vs88JjgQKG8lgHWl_qA7cf,sm_Vi26HDD_kqSAV9B_gzlA6X*sm_kmw0A5bIHVxaWDlVPn2iKt
);void sm_compiler_CTarget_create(sm_Vi26HDD_kqSAV9B_gzlA6X*
sm_kmw0A5bIHVxaWDlVPn2iKt){int sm_kwrB3ZoKf7OufTHWaHJV7a;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_kJgaJXMxmcWNji87yLe1qY=(unsigned int)-1;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm__bvXGsccASpPZq04dpvj2R=(size_t)-1;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm__tIBZwGBHMt9i5WzLo_cJK=(size_t)-1;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_VWJnZZhWbSW9WH_dg4R_Vo=false;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_FMziTw7JbQ0TiuguIfiueB=0;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_FD_YTInyTSOFjHZmWWksYZ=(unsigned int)-1;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_FTr_v3G_fcKDXyWVZ2Zd8Z=NULL;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_Faok9Kyd8h0aV9H8z7cF7n=false;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm__scPLHtW13KfVe4bctbn3w=false;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_FEmgG6ukukWyWylA5gOE0K=1.0;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_k5uQCZ4MtK8ZiqcwkkJPdn=false;
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_FQRNaOaqWIKkaqijq_WFce=0;for(
sm_kwrB3ZoKf7OufTHWaHJV7a=0;sm_kwrB3ZoKf7OufTHWaHJV7a<4;++
sm_kwrB3ZoKf7OufTHWaHJV7a)sm_kmw0A5bIHVxaWDlVPn2iKt->sm_FQfFLTtYnStTbLV0vWkI1_
[sm_kwrB3ZoKf7OufTHWaHJV7a]=0.0;sm_kmw0A5bIHVxaWDlVPn2iKt->
sm_kgRrjhEJupdGbPVBjU2z7p[0]=0.0;}static void sm_VplRnKJZg8lmciqYVanrAN(char**
dst,const char*src){pmf_free(*dst);if(src==NULL)*dst=NULL;else{const size_t
sm_kv8hpzERdFG7Yi_oqF7D2u=(strlen(src)+1)*sizeof(char);*dst=pmf_malloc(
sm_kv8hpzERdFG7Yi_oqF7D2u);memcpy(*dst,src,sm_kv8hpzERdFG7Yi_oqF7D2u);}}void
sm_compiler_CTarget_copy(const sm_Vi26HDD_kqSAV9B_gzlA6X*orig,
sm_Vi26HDD_kqSAV9B_gzlA6X*sm_kyVvGx32uvlKVTEMWrNekp){sm_kyVvGx32uvlKVTEMWrNekp
->sm_kJgaJXMxmcWNji87yLe1qY=orig->sm_kJgaJXMxmcWNji87yLe1qY;
sm_kyVvGx32uvlKVTEMWrNekp->sm__bvXGsccASpPZq04dpvj2R=orig->
sm__bvXGsccASpPZq04dpvj2R;sm_kyVvGx32uvlKVTEMWrNekp->sm__tIBZwGBHMt9i5WzLo_cJK
=orig->sm__tIBZwGBHMt9i5WzLo_cJK;sm_kyVvGx32uvlKVTEMWrNekp->
sm_VWJnZZhWbSW9WH_dg4R_Vo=orig->sm_VWJnZZhWbSW9WH_dg4R_Vo;
sm_kyVvGx32uvlKVTEMWrNekp->sm_FMziTw7JbQ0TiuguIfiueB=orig->
sm_FMziTw7JbQ0TiuguIfiueB;sm_kyVvGx32uvlKVTEMWrNekp->sm_FD_YTInyTSOFjHZmWWksYZ
=orig->sm_FD_YTInyTSOFjHZmWWksYZ;sm_kyVvGx32uvlKVTEMWrNekp->
sm_FTr_v3G_fcKDXyWVZ2Zd8Z=NULL;sm_VplRnKJZg8lmciqYVanrAN(&
sm_kyVvGx32uvlKVTEMWrNekp->sm_FTr_v3G_fcKDXyWVZ2Zd8Z,orig->
sm_FTr_v3G_fcKDXyWVZ2Zd8Z);sm_kyVvGx32uvlKVTEMWrNekp->
sm_Faok9Kyd8h0aV9H8z7cF7n=orig->sm_Faok9Kyd8h0aV9H8z7cF7n;
sm_kyVvGx32uvlKVTEMWrNekp->sm__scPLHtW13KfVe4bctbn3w=orig->
sm__scPLHtW13KfVe4bctbn3w;sm_kyVvGx32uvlKVTEMWrNekp->sm_FEmgG6ukukWyWylA5gOE0K
=orig->sm_FEmgG6ukukWyWylA5gOE0K;sm_kyVvGx32uvlKVTEMWrNekp->
sm_k5uQCZ4MtK8ZiqcwkkJPdn=orig->sm_k5uQCZ4MtK8ZiqcwkkJPdn;
sm_kyVvGx32uvlKVTEMWrNekp->sm_FQRNaOaqWIKkaqijq_WFce=orig->
sm_FQRNaOaqWIKkaqijq_WFce;memcpy(sm_kyVvGx32uvlKVTEMWrNekp->
sm_FQfFLTtYnStTbLV0vWkI1_,orig->sm_FQfFLTtYnStTbLV0vWkI1_,4*sizeof(double));
memcpy(sm_kyVvGx32uvlKVTEMWrNekp->sm_kgRrjhEJupdGbPVBjU2z7p,orig->
sm_kgRrjhEJupdGbPVBjU2z7p,1*sizeof(double));}void sm_compiler_CTarget_destroy(
sm_Vi26HDD_kqSAV9B_gzlA6X*sm_kmw0A5bIHVxaWDlVPn2iKt){pmf_free(
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_FTr_v3G_fcKDXyWVZ2Zd8Z);}void
sm_compiler_CTarget_setSpecifiedUnit(const char*sm_Vs88JjgQKG8lgHWl_qA7cf,
sm_Vi26HDD_kqSAV9B_gzlA6X*sm_kmw0A5bIHVxaWDlVPn2iKt){pmf_free(
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_FTr_v3G_fcKDXyWVZ2Zd8Z);if(
sm_Vs88JjgQKG8lgHWl_qA7cf==NULL)sm_kmw0A5bIHVxaWDlVPn2iKt->
sm_FTr_v3G_fcKDXyWVZ2Zd8Z=NULL;else{const size_t sm_kv8hpzERdFG7Yi_oqF7D2u=(
strlen(sm_Vs88JjgQKG8lgHWl_qA7cf)+1)*sizeof(char);sm_kmw0A5bIHVxaWDlVPn2iKt->
sm_FTr_v3G_fcKDXyWVZ2Zd8Z=pmf_malloc(sm_kv8hpzERdFG7Yi_oqF7D2u);memcpy(
sm_kmw0A5bIHVxaWDlVPn2iKt->sm_FTr_v3G_fcKDXyWVZ2Zd8Z,sm_Vs88JjgQKG8lgHWl_qA7cf
,sm_kv8hpzERdFG7Yi_oqF7D2u);}}
