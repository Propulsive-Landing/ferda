#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(
const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_int_vector_fields(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmIntVector*pm_create_int_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm__fSS_VMqhWlobeqe6mQF_x(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_int_vector(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm__jbisDMumXdocXANx5LhhY
(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);typedef enum{mc_FfS9gFGHqKt_fDwFfcldkw= -1,
mc_FFaaXY_gkbSTcyLBvtfrzS,mc_VUd8H_Dz0yp8cmQqTd7DxF,mc_kmVKy2ciwP4fcTEzXFmnvU,
mc_VW_0L0rb93GgXq8_OmdwHv,mc_kHoWGgwi3OdzaXvPvG1YY7,mc___D_4trEmdK8jyKCH6E_ac,
mc_Fei8BCRUgBdwhDvvD5FrSo}mc_kQtOKCqS08dIbumyDnHNDL;
#include "mc_std.h"
#include "ne_std.h"
#include "ne_std.h"
typedef enum{ssc_sli_kiIb5xamJm8uXPyOkLeM64= -1,ssc_sli_k_B87lbOsKOQaXOKLnD94H
,ssc_sli_kF6qlCJbg8KgV918dNyoLi,ssc_sli_FSfE1cJoJZC7ambyjUmTeX,
ssc_sli_kVuAggT174CiiusdSN860S,ssc_sli_FRC3ujZIQjdba9ZBxy4ztV}
ssc_sli_VnBw0hOC0JSHb5Pg67DfPJ;typedef enum{ssc_sli_kzlDtqeoEaW9XDcHaJXfPs= -1
,ssc_sli__7uv5IHqClGnV1nte_YE7w,ssc_sli__Lj5AlWpTDd3XDxlk_5qV0,
ssc_sli_FisftJ3gDQ0K_iBfRhL7F8,ssc_sli__ir0UGMhlx03jamM4TJM9W}
ssc_sli_V8Vq7Q__mO4Zb9Nz9VivSL;typedef struct ssc_sli_FPRo6JSR37tuYiF4t8uLpj
ssc_sli_kvTzD5SR_xGkhaM2fDuLNe;struct ssc_sli_FPRo6JSR37tuYiF4t8uLpj{const void
*mc_VFNhKLCqbHpDYXjdjCOMmT;size_t ssc_sli_F4UivWZhUu0I_HBRPupIr0;const
PmSparsityPattern*mc_VbQ99XU_TKpEgX06wWPmmb;void(*
ssc_core_Fmt0c_MGPStDjmILzXk95F)(const ssc_sli_kvTzD5SR_xGkhaM2fDuLNe*
ssc_sli_kqL3cKYSOoOsamezxPCk_r,const NeDynamicSystemInput*
mc__XfQXtB6cfd9fyc_v3eEup,PmIntVector*ssc_core_FBNduJ2xtv0UjTuX5_iN4m);void(*
ssc_sli__knCEQ5GPkG_aaGxwsRkSp)(const ssc_sli_kvTzD5SR_xGkhaM2fDuLNe*
ssc_sli_kqL3cKYSOoOsamezxPCk_r,NeDynamicSystemInput*mc__XfQXtB6cfd9fyc_v3eEup,
const PmIntVector*ssc_core_FBNduJ2xtv0UjTuX5_iN4m);void(*
ssc_sli_FdoA3x9akW_fY5qYTXJp8b)(const ssc_sli_kvTzD5SR_xGkhaM2fDuLNe*
ssc_sli_kqL3cKYSOoOsamezxPCk_r,const NeDynamicSystemInput*
mc__XfQXtB6cfd9fyc_v3eEup,PmRealVector*mc_V2mBNcV1EqCifyH9UdCbkF);void(*
mc_VYGWBho6N1K_eyHOMGjDiW)(ssc_sli_kvTzD5SR_xGkhaM2fDuLNe*
ssc_sli_kqL3cKYSOoOsamezxPCk_r);};typedef struct ssc_sli_kGL8Ux4baUGSjmOk0AwbYW
ssc_sli_VORRu18UeHhu_9WSlLv_u_;typedef struct ssc_sli__hXa_e7wfeGyXubR66ZxF3
ssc_sli_k2y7ETR_vItXW5cOCi5JkX;struct ssc_sli__hXa_e7wfeGyXubR66ZxF3{
ssc_sli_VORRu18UeHhu_9WSlLv_u_*mc_VFNhKLCqbHpDYXjdjCOMmT;
mc_kQtOKCqS08dIbumyDnHNDL(*mSolve)(ssc_sli_k2y7ETR_vItXW5cOCi5JkX*
ssc_sli_kq4BQXEe_G03XLdEeJQoq4,const NeDynamicSystemInput*
mc__XfQXtB6cfd9fyc_v3eEup,PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const
PmRealVector*mc_Fe6copTTRcKEayCm87ABO_);mc_kQtOKCqS08dIbumyDnHNDL(*
ssc_sli__Drs_fQgLpOnjyd8ESSgoC)(ssc_sli_k2y7ETR_vItXW5cOCi5JkX*
ssc_sli_kq4BQXEe_G03XLdEeJQoq4,const NeDynamicSystemInput*
mc__XfQXtB6cfd9fyc_v3eEup,size_t*ssc_sli_V_vSNcVk2WO7di04XVC3sL);void(*
mc_VYGWBho6N1K_eyHOMGjDiW)(ssc_sli_k2y7ETR_vItXW5cOCi5JkX*
ssc_sli_kq4BQXEe_G03XLdEeJQoq4);};boolean_T ssc_sli_V0cIDKvg5K_veeXyyQriPj(
ssc_sli_k2y7ETR_vItXW5cOCi5JkX**mc__1Zf2IciMRCub1vvbEr1C4,
ssc_sli_kvTzD5SR_xGkhaM2fDuLNe*ssc_sli_kqL3cKYSOoOsamezxPCk_r,const
McLinearAlgebraFactory*la,const NeDynamicSystemInput*mc__XfQXtB6cfd9fyc_v3eEup
,ssc_sli_V8Vq7Q__mO4Zb9Nz9VivSL ssc_sli_FBb9Ia9kQahhZuofBWVXdZ,boolean_T
ssc_sli_kqvLV4Tt3CdSbTfDDsWiAY,size_t*ssc_sli_kl8yCNeh9mlQXmcd9S8cIJ);
#include "limits.h"
#include "pm_std.h"
#include "pm_std.h"
PmAllocator*pm_default_allocator(void);
#include "pm_std.h"
int_T pm_kkW9oQAVI7Wt_9Rzuat5bx(PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t pm_keOJjiAyBTtFhyWf033kni,size_t pm_kJxontPsxndNYXwDXdE1iy,size_t
pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
PmSparsityPattern*pm_create_sparsity_pattern(size_t pm_keOJjiAyBTtFhyWf033kni,
size_t pm_kJxontPsxndNYXwDXdE1iy,size_t pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kTFq3qlgTulWiT6pafkmmT(PmSparsityPattern*
pm__56dBn4vKXWjZ1nclFRYZB,const PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);
boolean_T pm__ZRI70SuGwhmamUtcsoyxS(const PmSparsityPattern*
pm__56dBn4vKXWjZ1nclFRYZB,const PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);
PmSparsityPattern*pm_FQMLyYzCQ5CtgHjze1nNJP(const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FvcKvutPfxG9Xe1kjs7gg0(PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);void pm_VYooJBURCwKrVu6RXzQZ_5(
PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm__YwdRBXissh3bPWPl30Fpe(size_t
pm_FW8nEXbTFjdJhTIKepsgFT,size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm_FFniD_kRQg_JWTYc5cmjGs(size_t
pm_FW8nEXbTFjdJhTIKepsgFT,size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm_FhqtSrxlPotrcypQHJ9Dcq(size_t
pm__lqjegyKuwStj56WZLiC_e,size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*pm__TNI3M36rThlaTetY4tWiB(size_t n,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);
#include "pm_std.h"
#include "pm_std.h"
size_t mc_VgM3Lx3pYgtLW13T1_txvP(const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ)
;void mc_F4xMxEJX_DlUYXuaiDuSWS(const PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,
const PmRealVector*x,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08);void
mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmIntVector*
mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_V5jydIk5QzCRZTOycShqTL(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FvLmE29WKCKJfaZMHwg3g9(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const int32_T mc_kh0AzKGHcX8tfeDoNul_TU,
const int32_T mc__Oliq0seKPWShTNRpvAarb);void mc__pmVtsSuXZls_1NfvVprZ7(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH);void
mc_FR5FdJeEvDGGcyEVkxeE_x(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt);
void mc_FK6EqkTbVFGMZ5QwXcurHx(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*mc_k8AO2tT20x0_cyxVp0ak3P);void mc_FioOBDJiFMpkWaAcUdBb1E(
const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T mc_kg4CyRgbu6OdeewZOel7Qx)
;void mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,
const PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd);void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VqP4HesDIf47bDn5teE2H2(const PmRealVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmRealVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_Vv4EJYeJDW0yZXiH42yCA_(const PmIntVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmIntVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_k0zonBZJC2K6baT1NXX1Qo(PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);size_t
mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*mc__MqKyOds56_XeH9Iv3CTIL);void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE);size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);size_t mc__fQVSVSgEBG6fuximVFlkw(const
PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa);size_t mc_FyLahU0kjICfba8O7mWi8Z(const
PmBoolVector*mc_FawmFe5oOEC_cmkvZc1Kaa);boolean_T mc___gjB_jZtTxReaWZSEiFdh(
const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx);boolean_T mc_kk65_VI6zC0mWHqRziXpjX(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FzkrLuS4xMOvaTv5dUw3j7(const
PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ);void mc_ks_PW4I7dwWbhXAWhHTUCI
(const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V3CZVT50_V_xeia9SYYptc(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T a,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x
,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_FBDi_PCg670TjHgJTNPcHr);void mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x
,const real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
real_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VM9M6KxYTfKL_q4yuXmOnI(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt)
;void mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V2CDnBdRcOpuh1IyvRJzfi(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt);void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__aNO1s5qwzt6fXwft5YgCz(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc__Nb_EyyxYi4ddPcS0H7Bot(const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const
PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);
void mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VWloU5QD6gpaXeK8lmytFA(const
PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw);void mc_VQ1YWbKmkVC6YajZAyvmNH(const
PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);real_T mc_kMPF5fccZd_3jHFMhUSro6(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_kvxcenZbLm4dfenXL8jQAx(
const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_Vgo5SAIS_80_VXwmU7JogX
(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);void mc__25pQTf4VutiXiGTGQmvSU(
PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const PmIntVector*
mc_F6sy5cXK8JOKeiFBw6znSV);void mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*
mc_VWoEnwEgWFpobmwHA1Qln5,const PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const
PmSparsityPattern*mc__Df1hQFzAY4fiLCvP0PV12);void mc_VMRKMuNLnDxXjaBiy1RcMD(
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc_kM_Y9u9U2F_Cf9sWAtmMMu(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc__Xq_g76c6Y_K_PpYNKcquN(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const real_T*x);void mc_kXj99iXjC1CoZLWwPRH879(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*mc_FybTf2SinthyWqOxvPdJ5h,size_t mc_VVRAoFgW2Hphcy7H6H9Oh0)
;void mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat);void mc_kLGj2IdnGDG_YeEKAnMkUr(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FJN_drUOKh_igHJXVH7xls(
const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T mc_kcda_aHAM4WIXuM_xBDdLt);void
mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr,const
PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo);void mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*
mc_FrF2gTbWxox8geiSROFaFn,const PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE);void mc_VjzTgsx19j0KfHv6VXr4Mp(const
PmRealVector*a,const PmIntVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*
b);void mc_V_Fp06wJOBhXZyLbA5xU0r(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a);void mc_FuY0t5xEb5_QhDQFQ_TXtc(
const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x);void mc_kMo1w3ReRZGIdH5_MNwumc
(const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_VYxtXnMKT6hpb1FMldBDLs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void
mc_kl_UmQrKbdCajPyXz5nOIL(const PmRealVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void mc_k2E2oWXDqshMeuCQWrbaKT
(const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc_FBaB5196Xx0ohX_IWM5ypL(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T x);void
mc_F1CG0fHJYfd_ealLMx7Z7U(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void mc_krXbD205SBpghif1h1n_ei(
const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc__Qtfmi680EKpj1bOrIroGr(const PmIntVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void
mc__0IkRn0eQ9Wc_u8mCNbQDh(const PmIntVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void mc__pbFNjwg_bCPdPFSjC2Wdv(
const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx);void mc_VpjBXBa8TTCl_uBXYMLfxC(const PmBoolVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);
void mc__pFtu1g17h8ZaaZK4PpTkb(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,
const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void
mc_kMScbNM1RKOTaD4QwTME8Y(const PmBoolVector*mc__1Zf2IciMRCub1vvbEr1C4,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmRealVector*
mc_VlnhKi82gfCLgumIqeduOq);void mc_Fbsqat6MlL0bjPHlNxax8t(const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FSAdXYnRP9pkfmWBYlMkJJ(
const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*
mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*mc_F8fT7naL9bOcimTADCVzTC);void
mc__NertSre4cWh_mN2RJ5UPq(const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*
mc_VCVhWy_VaDhraHrlfFWxBa);PmRealVector mc_VPFwoVShg1G3XTwou1_jbC(const
PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,size_t mc_Fyss_XM3F_C4dm6IKoDw4G,size_t
mc_Vs6xonQX17Krc5vXv8T_zq);
#include "mc_std.h"
#include "pm_std.h"
typedef struct ssc_sli__28p6olsru4xiqIfaE_RiC ssc_sli_FOrb4PPFSoK_hi2nVy3VBL;
typedef struct ssc_sli_kmFrp4sb0N0jaHdZVa1oKg ssc_sli__1xlryuXE3GZ_qfD65s3e5;
typedef struct ssc_sli_koZC_AD7LZ_IbiNyUwDqKf ssc_sli__4Qrk7zTCKGH_uT5yMtxFb;
typedef struct ssc_sli_Vp_by_y9ZNCLj5UqUuMeN1 ssc_sli__WiVbFarDU8XjH5EZWvHjo;
typedef struct ssc_sli__fCGVkCiKp_dc1cd5JD9bX{ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*
ssc_sli_kIL_KFfePoCnfDe2C0CMSf;ssc_sli__1xlryuXE3GZ_qfD65s3e5*
ssc_sli_FQfFLTtYnStTbLV0vWkI1_;}ssc_sli_VNPPRKAwuP_2XLe3P7oDCX;typedef
ssc_sli_VNPPRKAwuP_2XLe3P7oDCX*(*ssc_sli__pfarM7qn_8vjP34PNJkPd)(const
ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*ssc_sli_kvBdBwVdJztaXPLz5_6q7C,const
ssc_sli__1xlryuXE3GZ_qfD65s3e5*mc_kg4CyRgbu6OdeewZOel7Qx);typedef void(*
ssc_sli__2vkuizNtrKEjXQ_YgrN9I)(ssc_sli_VNPPRKAwuP_2XLe3P7oDCX*
ssc_sli_Ffuwa74dpf8ojLAepxw4J_);typedef boolean_T(*
ssc_sli_FPpqCGo7dG_CWPMYgpfMOT)(const ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*
ssc_sli_FfCY8UvszqllbmuW9guHFu,const ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*
ssc_sli__TqmG8jjnJKebDk2jZqjpu);typedef size_t(*ssc_sli_V20Dbnt95u_9VyLdMIxACc
)(const ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*ssc_sli_kvBdBwVdJztaXPLz5_6q7C);struct
ssc_sli_Vp_by_y9ZNCLj5UqUuMeN1{ssc_sli__4Qrk7zTCKGH_uT5yMtxFb*
mc_VFNhKLCqbHpDYXjdjCOMmT;ssc_sli__pfarM7qn_8vjP34PNJkPd
ssc_sli__Qbg7_Jc06dChP6H_SqxN_;ssc_sli__2vkuizNtrKEjXQ_YgrN9I
ssc_sli_kDLakVdSbzCXdafXCC2h_j;ssc_sli_FPpqCGo7dG_CWPMYgpfMOT
ssc_sli_FQXGokx20f_4e1k_4jm6ws;ssc_sli_V20Dbnt95u_9VyLdMIxACc
ssc_sli_Fu4SrSNqTRGCiP8nz8RVGG;boolean_T(*ssc_sli__boAB0ih3e_1_1DklwbvAq)(
ssc_sli__WiVbFarDU8XjH5EZWvHjo*ssc_sli_Vw6n82vFxcCU_q7gFoxaEB,const
ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*ssc_sli_kvBdBwVdJztaXPLz5_6q7C,const
ssc_sli__1xlryuXE3GZ_qfD65s3e5*pm_kpzAtHMD4_WnheH0UiioSE);
ssc_sli__1xlryuXE3GZ_qfD65s3e5*(*ssc_sli_VXZ69cXJ5kC5c5S6UWjHzW)(const
ssc_sli__WiVbFarDU8XjH5EZWvHjo*ssc_sli_Vw6n82vFxcCU_q7gFoxaEB,const
ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*ssc_sli_kvBdBwVdJztaXPLz5_6q7C);void(*
ssc_core_VpMG2_8Z4c4aa9vd7AfjAl)(const ssc_sli__WiVbFarDU8XjH5EZWvHjo*
ssc_sli_Vw6n82vFxcCU_q7gFoxaEB);void(*mc_VYGWBho6N1K_eyHOMGjDiW)(
ssc_sli__WiVbFarDU8XjH5EZWvHjo*ssc_sli_Vw6n82vFxcCU_q7gFoxaEB);};
ssc_sli__WiVbFarDU8XjH5EZWvHjo*ssc_sli_VOXvLJcAVzdJjXMSM21cTM(size_t
ssc_sli_VEAd_yTYI2CecPuelr4g1q,size_t ssc_sli_FmSLM8NZxEGvcuj32Mvuj9,
ssc_sli__pfarM7qn_8vjP34PNJkPd ssc_sli_Fdywd4Ip2AK1b1kX9wRU6U,
ssc_sli__2vkuizNtrKEjXQ_YgrN9I ssc_sli_V7j0EcPDlHxSfXY9qu4eLP,
ssc_sli_FPpqCGo7dG_CWPMYgpfMOT ssc_sli__YKS6NEYIuh3eu5bFM1pdK,
ssc_sli_V20Dbnt95u_9VyLdMIxACc ssc_sli_VfV5vpftf8tYYDFWaGmw1A);
#include "mc_std.h"
const McLinearAlgebraFactory*ssc_sli_Vo6yP2kZL8_UYHq0yxrj9D(size_t
ssc_sli__jwySfHyx1SXgXJeVWoIzb);struct ssc_sli__28p6olsru4xiqIfaE_RiC{
PmIntVector*mM;};struct ssc_sli_kmFrp4sb0N0jaHdZVa1oKg{McLinearAlgebra*
ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR;};struct ssc_sli_kGL8Ux4baUGSjmOk0AwbYW{
ssc_sli__WiVbFarDU8XjH5EZWvHjo*ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h;
ssc_sli_kvTzD5SR_xGkhaM2fDuLNe*ssc_sli_Vu8wy9IGEVWgiDu5nL3zwQ;const
McLinearAlgebraFactory*ssc_sli_k9OLqCUxLdd8V5jf99gpI0;PmRealVector*
ssc_sli_kTHuEsERBu4jY9vcwRBlcu;PmIntVector*ssc_sli_VEaVFomK_ZSqbm85CCLWGg;};
static ssc_sli_VNPPRKAwuP_2XLe3P7oDCX*ssc_sli_FMG1_NHm_5doeX4HDFCFw0(const
ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*ssc_sli_kvBdBwVdJztaXPLz5_6q7C,const
ssc_sli__1xlryuXE3GZ_qfD65s3e5*mc_kg4CyRgbu6OdeewZOel7Qx){PmAllocator*a=
pm_default_allocator();ssc_sli_VNPPRKAwuP_2XLe3P7oDCX*
ssc_sli_Ffuwa74dpf8ojLAepxw4J_=(ssc_sli_VNPPRKAwuP_2XLe3P7oDCX*)((a)->
mCallocFcn((a),(sizeof(ssc_sli_VNPPRKAwuP_2XLe3P7oDCX)),(1)));
ssc_sli_Ffuwa74dpf8ojLAepxw4J_->ssc_sli_kIL_KFfePoCnfDe2C0CMSf=(
ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*)((a)->mCallocFcn((a),(sizeof(
ssc_sli_FOrb4PPFSoK_hi2nVy3VBL)),(1)));ssc_sli_Ffuwa74dpf8ojLAepxw4J_->
ssc_sli_FQfFLTtYnStTbLV0vWkI1_=(ssc_sli__1xlryuXE3GZ_qfD65s3e5*)((a)->
mCallocFcn((a),(sizeof(ssc_sli__1xlryuXE3GZ_qfD65s3e5)),(1)));
ssc_sli_Ffuwa74dpf8ojLAepxw4J_->ssc_sli_kIL_KFfePoCnfDe2C0CMSf->mM=
pm__fSS_VMqhWlobeqe6mQF_x(ssc_sli_kvBdBwVdJztaXPLz5_6q7C->mM,a);
ssc_sli_Ffuwa74dpf8ojLAepxw4J_->ssc_sli_FQfFLTtYnStTbLV0vWkI1_->
ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR=mc_kg4CyRgbu6OdeewZOel7Qx->
ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR;return ssc_sli_Ffuwa74dpf8ojLAepxw4J_;}static
void ssc_sli_VabdVI6TN3Cliir5HeTjYZ(ssc_sli_VNPPRKAwuP_2XLe3P7oDCX*
ssc_sli_Ffuwa74dpf8ojLAepxw4J_){PmAllocator*a=pm_default_allocator();
pm_destroy_int_vector(ssc_sli_Ffuwa74dpf8ojLAepxw4J_->
ssc_sli_kIL_KFfePoCnfDe2C0CMSf->mM,a);ssc_sli_Ffuwa74dpf8ojLAepxw4J_->
ssc_sli_FQfFLTtYnStTbLV0vWkI1_->ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR->mDestructor(
ssc_sli_Ffuwa74dpf8ojLAepxw4J_->ssc_sli_FQfFLTtYnStTbLV0vWkI1_->
ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR);{void*ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(
ssc_sli_Ffuwa74dpf8ojLAepxw4J_->ssc_sli_kIL_KFfePoCnfDe2C0CMSf);if(
ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->mFreeFcn(a,
ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};{void*ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(
ssc_sli_Ffuwa74dpf8ojLAepxw4J_->ssc_sli_FQfFLTtYnStTbLV0vWkI1_);if(
ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->mFreeFcn(a,
ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};{void*ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(
ssc_sli_Ffuwa74dpf8ojLAepxw4J_);if(ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->
mFreeFcn(a,ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};}static boolean_T
ssc_sli_Fwe_iv6T_I8NXL4P2ogPek(const ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*
ssc_sli_FfCY8UvszqllbmuW9guHFu,const ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*
ssc_sli__TqmG8jjnJKebDk2jZqjpu){size_t mc_kwrB3ZoKf7OufTHWaHJV7a;(void)0;;for(
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<
ssc_sli_FfCY8UvszqllbmuW9guHFu->mM->mN;mc_kwrB3ZoKf7OufTHWaHJV7a++){if(
ssc_sli_FfCY8UvszqllbmuW9guHFu->mM->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]!=
ssc_sli__TqmG8jjnJKebDk2jZqjpu->mM->mX[mc_kwrB3ZoKf7OufTHWaHJV7a]){return false
;}}return true;}static size_t ssc_sli_kJRZxpSa9FKrWHA4pzcC5t(const
ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*ssc_sli_kvBdBwVdJztaXPLz5_6q7C){PmIntVector*
mc_VLHhnPUiNQpve5VIL9P3O9=ssc_sli_kvBdBwVdJztaXPLz5_6q7C->mM;size_t
mc_kTckK8teUpOlhm8Ippu8XP=1,mc__1Zf2IciMRCub1vvbEr1C4=0;size_t
mc_kwrB3ZoKf7OufTHWaHJV7a;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_VLHhnPUiNQpve5VIL9P3O9->mN;
mc_kwrB3ZoKf7OufTHWaHJV7a++){mc__1Zf2IciMRCub1vvbEr1C4+=
mc_kTckK8teUpOlhm8Ippu8XP*(size_t)(mc_VLHhnPUiNQpve5VIL9P3O9->mX[
mc_kwrB3ZoKf7OufTHWaHJV7a]);mc_kTckK8teUpOlhm8Ippu8XP*=2;}return
mc__1Zf2IciMRCub1vvbEr1C4;}static mc_kQtOKCqS08dIbumyDnHNDL
ssc_sli_FYUQlIXN2a_6hy2wYf1_sE(ssc_sli_k2y7ETR_vItXW5cOCi5JkX*
ssc_sli_FK4g_EWd4wd0XHtmab_hbg,const NeDynamicSystemInput*
mc__XfQXtB6cfd9fyc_v3eEup,const ssc_sli_FOrb4PPFSoK_hi2nVy3VBL*
ssc_sli_kvBdBwVdJztaXPLz5_6q7C,size_t*ssc_sli_V_vSNcVk2WO7di04XVC3sL){
PmAllocator*a=pm_default_allocator();ssc_sli_VORRu18UeHhu_9WSlLv_u_*d=
ssc_sli_FK4g_EWd4wd0XHtmab_hbg->mc_VFNhKLCqbHpDYXjdjCOMmT;
ssc_sli__1xlryuXE3GZ_qfD65s3e5 mc_kg4CyRgbu6OdeewZOel7Qx;McLinearAlgebraStatus
mc__1Zf2IciMRCub1vvbEr1C4;boolean_T ssc_sli_k4M7bSEmThKJbirXUDQgS6;(d->
ssc_sli_Vu8wy9IGEVWgiDu5nL3zwQ)->ssc_sli_FdoA3x9akW_fY5qYTXJp8b((d->
ssc_sli_Vu8wy9IGEVWgiDu5nL3zwQ),(mc__XfQXtB6cfd9fyc_v3eEup),(d->
ssc_sli_kTHuEsERBu4jY9vcwRBlcu));mc__1Zf2IciMRCub1vvbEr1C4=d->
ssc_sli_k9OLqCUxLdd8V5jf99gpI0->mCreateLinearAlgebra(d->
ssc_sli_k9OLqCUxLdd8V5jf99gpI0,&(mc_kg4CyRgbu6OdeewZOel7Qx.
ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR),d->ssc_sli_Vu8wy9IGEVWgiDu5nL3zwQ->
mc_VbQ99XU_TKpEgX06wWPmmb);(void)0;;mc__1Zf2IciMRCub1vvbEr1C4=
mc_kg4CyRgbu6OdeewZOel7Qx.ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR->mFactor(
mc_kg4CyRgbu6OdeewZOel7Qx.ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR,d->
ssc_sli_kTHuEsERBu4jY9vcwRBlcu->mX);if(mc__1Zf2IciMRCub1vvbEr1C4!=MC_LA_OK){*
ssc_sli_V_vSNcVk2WO7di04XVC3sL=0;mc_kg4CyRgbu6OdeewZOel7Qx.
ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR->mDestructor(mc_kg4CyRgbu6OdeewZOel7Qx.
ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR);return mc_VUd8H_Dz0yp8cmQqTd7DxF;}*
ssc_sli_V_vSNcVk2WO7di04XVC3sL=(mc_kg4CyRgbu6OdeewZOel7Qx.
ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR)->mMemusage((mc_kg4CyRgbu6OdeewZOel7Qx.
ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR));ssc_sli_k4M7bSEmThKJbirXUDQgS6=(d->
ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h)->ssc_sli__boAB0ih3e_1_1DklwbvAq((d->
ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h),(ssc_sli_kvBdBwVdJztaXPLz5_6q7C),(&
mc_kg4CyRgbu6OdeewZOel7Qx));return mc_FFaaXY_gkbSTcyLBvtfrzS;}static
mc_kQtOKCqS08dIbumyDnHNDL ssc_sli__BMXse71tkxlba1wrMzfB6(
ssc_sli_k2y7ETR_vItXW5cOCi5JkX*ssc_sli_FK4g_EWd4wd0XHtmab_hbg,const
NeDynamicSystemInput*mc__XfQXtB6cfd9fyc_v3eEup,size_t*
ssc_sli_V_vSNcVk2WO7di04XVC3sL){ssc_sli_VORRu18UeHhu_9WSlLv_u_*d=
ssc_sli_FK4g_EWd4wd0XHtmab_hbg->mc_VFNhKLCqbHpDYXjdjCOMmT;
ssc_sli_FOrb4PPFSoK_hi2nVy3VBL ssc_sli_kvBdBwVdJztaXPLz5_6q7C;
mc_kQtOKCqS08dIbumyDnHNDL ssc_sli_k4M7bSEmThKJbirXUDQgS6;(d->
ssc_sli_Vu8wy9IGEVWgiDu5nL3zwQ)->ssc_core_Fmt0c_MGPStDjmILzXk95F((d->
ssc_sli_Vu8wy9IGEVWgiDu5nL3zwQ),(mc__XfQXtB6cfd9fyc_v3eEup),(d->
ssc_sli_VEaVFomK_ZSqbm85CCLWGg));ssc_sli_kvBdBwVdJztaXPLz5_6q7C.mM=d->
ssc_sli_VEaVFomK_ZSqbm85CCLWGg;ssc_sli_k4M7bSEmThKJbirXUDQgS6=
ssc_sli_FYUQlIXN2a_6hy2wYf1_sE(ssc_sli_FK4g_EWd4wd0XHtmab_hbg,
mc__XfQXtB6cfd9fyc_v3eEup,&ssc_sli_kvBdBwVdJztaXPLz5_6q7C,
ssc_sli_V_vSNcVk2WO7di04XVC3sL);return ssc_sli_k4M7bSEmThKJbirXUDQgS6;}static
mc_kQtOKCqS08dIbumyDnHNDL ssc_sli__aG8sSGfBB45aqgh8Jv3On(
ssc_sli_k2y7ETR_vItXW5cOCi5JkX*ssc_sli_FK4g_EWd4wd0XHtmab_hbg,const
NeDynamicSystemInput*mc__XfQXtB6cfd9fyc_v3eEup,PmRealVector*
mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*mc_Fe6copTTRcKEayCm87ABO_){
ssc_sli_VORRu18UeHhu_9WSlLv_u_*d=ssc_sli_FK4g_EWd4wd0XHtmab_hbg->
mc_VFNhKLCqbHpDYXjdjCOMmT;ssc_sli_FOrb4PPFSoK_hi2nVy3VBL
ssc_sli_kvBdBwVdJztaXPLz5_6q7C;ssc_sli__1xlryuXE3GZ_qfD65s3e5*
pm_kpzAtHMD4_WnheH0UiioSE;McLinearAlgebraStatus mc__1Zf2IciMRCub1vvbEr1C4;if(d
->ssc_sli_VEaVFomK_ZSqbm85CCLWGg->mN>0){(d->ssc_sli_Vu8wy9IGEVWgiDu5nL3zwQ)->
ssc_core_Fmt0c_MGPStDjmILzXk95F((d->ssc_sli_Vu8wy9IGEVWgiDu5nL3zwQ),(
mc__XfQXtB6cfd9fyc_v3eEup),(d->ssc_sli_VEaVFomK_ZSqbm85CCLWGg));}
ssc_sli_kvBdBwVdJztaXPLz5_6q7C.mM=d->ssc_sli_VEaVFomK_ZSqbm85CCLWGg;
pm_kpzAtHMD4_WnheH0UiioSE=(d->ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h)->
ssc_sli_VXZ69cXJ5kC5c5S6UWjHzW((d->ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h),(&
ssc_sli_kvBdBwVdJztaXPLz5_6q7C));if(pm_kpzAtHMD4_WnheH0UiioSE==NULL){
mc_kQtOKCqS08dIbumyDnHNDL ssc_sli_k4M7bSEmThKJbirXUDQgS6;size_t
ssc_sli_khb7_lwiK_OgiHVjRTvCxx;ssc_sli_k4M7bSEmThKJbirXUDQgS6=
ssc_sli_FYUQlIXN2a_6hy2wYf1_sE(ssc_sli_FK4g_EWd4wd0XHtmab_hbg,
mc__XfQXtB6cfd9fyc_v3eEup,&ssc_sli_kvBdBwVdJztaXPLz5_6q7C,&
ssc_sli_khb7_lwiK_OgiHVjRTvCxx);if(ssc_sli_k4M7bSEmThKJbirXUDQgS6!=
mc_FFaaXY_gkbSTcyLBvtfrzS){return ssc_sli_k4M7bSEmThKJbirXUDQgS6;}
pm_kpzAtHMD4_WnheH0UiioSE=(d->ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h)->
ssc_sli_VXZ69cXJ5kC5c5S6UWjHzW((d->ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h),(&
ssc_sli_kvBdBwVdJztaXPLz5_6q7C));(void)0;;}mc__1Zf2IciMRCub1vvbEr1C4=
pm_kpzAtHMD4_WnheH0UiioSE->ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR->mSolve(
pm_kpzAtHMD4_WnheH0UiioSE->ssc_sli_F1Ud8y7l9TCb_qe6IEGSUR,NULL,
mc_FzyLWRgau0pMYq2XSI3ETL->mX,mc_Fe6copTTRcKEayCm87ABO_->mX);if(
mc__1Zf2IciMRCub1vvbEr1C4!=MC_LA_OK){return mc_VUd8H_Dz0yp8cmQqTd7DxF;}return
mc_FFaaXY_gkbSTcyLBvtfrzS;}static void ssc_sli_Vv_ydid43Xxxj5wzzC42yi(
ssc_sli_k2y7ETR_vItXW5cOCi5JkX*ssc_sli_FK4g_EWd4wd0XHtmab_hbg){PmAllocator*a=
pm_default_allocator();ssc_sli_VORRu18UeHhu_9WSlLv_u_*d=
ssc_sli_FK4g_EWd4wd0XHtmab_hbg->mc_VFNhKLCqbHpDYXjdjCOMmT;(d->
ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h)->mc_VYGWBho6N1K_eyHOMGjDiW((d->
ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h));(d->ssc_sli_Vu8wy9IGEVWgiDu5nL3zwQ)->
mc_VYGWBho6N1K_eyHOMGjDiW((d->ssc_sli_Vu8wy9IGEVWgiDu5nL3zwQ));
pm_destroy_int_vector(d->ssc_sli_VEaVFomK_ZSqbm85CCLWGg,a);
pm_destroy_real_vector(d->ssc_sli_kTHuEsERBu4jY9vcwRBlcu,a);{void*
ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(d);if(ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->
mFreeFcn(a,ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};{void*
ssc_sli_kk06poLCQlh5i5Yv6GSh7e=(ssc_sli_FK4g_EWd4wd0XHtmab_hbg);if(
ssc_sli_kk06poLCQlh5i5Yv6GSh7e!=0){(a)->mFreeFcn(a,
ssc_sli_kk06poLCQlh5i5Yv6GSh7e);}};}ssc_sli_k2y7ETR_vItXW5cOCi5JkX*
ssc_sli_VmMwNfwxdhWhd5Zq7okF3g(size_t ssc_sli_VEAd_yTYI2CecPuelr4g1q,size_t
ssc_sli_FmSLM8NZxEGvcuj32Mvuj9,ssc_sli_kvTzD5SR_xGkhaM2fDuLNe*
ssc_sli_VHx3JOvtgIK3VPttL15wzm,const McLinearAlgebraFactory*
ssc_sli__RaoL3gcnqtvbqvTOI8tAN){PmAllocator*a=pm_default_allocator();
ssc_sli_k2y7ETR_vItXW5cOCi5JkX*ssc_sli_FK4g_EWd4wd0XHtmab_hbg=(
ssc_sli_k2y7ETR_vItXW5cOCi5JkX*)((a)->mCallocFcn((a),(sizeof(
ssc_sli_k2y7ETR_vItXW5cOCi5JkX)),(1)));ssc_sli_VORRu18UeHhu_9WSlLv_u_*d=(
ssc_sli_VORRu18UeHhu_9WSlLv_u_*)((a)->mCallocFcn((a),(sizeof(
ssc_sli_VORRu18UeHhu_9WSlLv_u_)),(1)));size_t ssc_sli_kNgcOktCtQxdYedrGvFn5i=(
(size_t)(ssc_sli_VHx3JOvtgIK3VPttL15wzm->mc_VbQ99XU_TKpEgX06wWPmmb)->mJc[(
ssc_sli_VHx3JOvtgIK3VPttL15wzm->mc_VbQ99XU_TKpEgX06wWPmmb)->mNumCol]);d->
ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h=ssc_sli_VOXvLJcAVzdJjXMSM21cTM(
ssc_sli_VEAd_yTYI2CecPuelr4g1q,ssc_sli_FmSLM8NZxEGvcuj32Mvuj9,
ssc_sli_FMG1_NHm_5doeX4HDFCFw0,ssc_sli_VabdVI6TN3Cliir5HeTjYZ,
ssc_sli_Fwe_iv6T_I8NXL4P2ogPek,ssc_sli_kJRZxpSa9FKrWHA4pzcC5t);d->
ssc_sli_Vu8wy9IGEVWgiDu5nL3zwQ=ssc_sli_VHx3JOvtgIK3VPttL15wzm;d->
ssc_sli_k9OLqCUxLdd8V5jf99gpI0=ssc_sli__RaoL3gcnqtvbqvTOI8tAN;d->
ssc_sli_kTHuEsERBu4jY9vcwRBlcu=pm_create_real_vector(
ssc_sli_kNgcOktCtQxdYedrGvFn5i,a);d->ssc_sli_VEaVFomK_ZSqbm85CCLWGg=
pm_create_int_vector(ssc_sli_VHx3JOvtgIK3VPttL15wzm->
ssc_sli_F4UivWZhUu0I_HBRPupIr0,a);ssc_sli_FK4g_EWd4wd0XHtmab_hbg->
mc_VFNhKLCqbHpDYXjdjCOMmT=d;ssc_sli_FK4g_EWd4wd0XHtmab_hbg->mSolve=
ssc_sli__aG8sSGfBB45aqgh8Jv3On;ssc_sli_FK4g_EWd4wd0XHtmab_hbg->
ssc_sli__Drs_fQgLpOnjyd8ESSgoC=ssc_sli__BMXse71tkxlba1wrMzfB6;
ssc_sli_FK4g_EWd4wd0XHtmab_hbg->mc_VYGWBho6N1K_eyHOMGjDiW=
ssc_sli_Vv_ydid43Xxxj5wzzC42yi;return ssc_sli_FK4g_EWd4wd0XHtmab_hbg;}
boolean_T ssc_sli_V0cIDKvg5K_veeXyyQriPj(ssc_sli_k2y7ETR_vItXW5cOCi5JkX**
mc__1Zf2IciMRCub1vvbEr1C4,ssc_sli_kvTzD5SR_xGkhaM2fDuLNe*
ssc_sli_kqL3cKYSOoOsamezxPCk_r,const McLinearAlgebraFactory*
ssc_sli__RaoL3gcnqtvbqvTOI8tAN,const NeDynamicSystemInput*
mc__XfQXtB6cfd9fyc_v3eEup,ssc_sli_V8Vq7Q__mO4Zb9Nz9VivSL
ssc_sli_FBb9Ia9kQahhZuofBWVXdZ,boolean_T ssc_sli_kqvLV4Tt3CdSbTfDDsWiAY,size_t
*ssc_sli_kl8yCNeh9mlQXmcd9S8cIJ){ssc_sli_k2y7ETR_vItXW5cOCi5JkX*
ssc_sli_FK4g_EWd4wd0XHtmab_hbg;size_t ssc_sli_V_3jgb9hDH4SfXlbwqYYq5=
ssc_sli_kqL3cKYSOoOsamezxPCk_r->ssc_sli_F4UivWZhUu0I_HBRPupIr0;size_t
ssc_sli_Vp9TZCZIW_0oYHVC2sP9N4=0;size_t ssc_sli__8Fjwka7BdSOZ91CXGBkwV=0;const
McLinearAlgebraFactory*mc_Fiqi8a6cvxOLX1oR_MTbxh;(void)0;;*
mc__1Zf2IciMRCub1vvbEr1C4=NULL;(void)0;;if(ssc_sli_FBb9Ia9kQahhZuofBWVXdZ==
ssc_sli_FisftJ3gDQ0K_iBfRhL7F8){if(ssc_sli_V_3jgb9hDH4SfXlbwqYYq5>sizeof(
size_t)*CHAR_BIT){(ssc_sli_kqL3cKYSOoOsamezxPCk_r)->mc_VYGWBho6N1K_eyHOMGjDiW(
(ssc_sli_kqL3cKYSOoOsamezxPCk_r));return true;}ssc_sli_Vp9TZCZIW_0oYHVC2sP9N4=
((size_t)1<<ssc_sli_V_3jgb9hDH4SfXlbwqYYq5);ssc_sli__8Fjwka7BdSOZ91CXGBkwV=
ssc_sli_Vp9TZCZIW_0oYHVC2sP9N4;}if(ssc_sli_FBb9Ia9kQahhZuofBWVXdZ==
ssc_sli__Lj5AlWpTDd3XDxlk_5qV0){ssc_sli_Vp9TZCZIW_0oYHVC2sP9N4=40009;
ssc_sli__8Fjwka7BdSOZ91CXGBkwV=200;}if(ssc_sli_FBb9Ia9kQahhZuofBWVXdZ==
ssc_sli_FisftJ3gDQ0K_iBfRhL7F8){mc_Fiqi8a6cvxOLX1oR_MTbxh=
ssc_sli_Vo6yP2kZL8_UYHq0yxrj9D(ssc_sli_kqL3cKYSOoOsamezxPCk_r->
mc_VbQ99XU_TKpEgX06wWPmmb->mNumCol);}else{mc_Fiqi8a6cvxOLX1oR_MTbxh=
ssc_sli__RaoL3gcnqtvbqvTOI8tAN;}ssc_sli_FK4g_EWd4wd0XHtmab_hbg=
ssc_sli_VmMwNfwxdhWhd5Zq7okF3g(ssc_sli_Vp9TZCZIW_0oYHVC2sP9N4,
ssc_sli__8Fjwka7BdSOZ91CXGBkwV,ssc_sli_kqL3cKYSOoOsamezxPCk_r,
mc_Fiqi8a6cvxOLX1oR_MTbxh);if(ssc_sli_FBb9Ia9kQahhZuofBWVXdZ==
ssc_sli_FisftJ3gDQ0K_iBfRhL7F8){PmAllocator*a=pm_default_allocator();
NeDynamicSystemInput*ssc_sli__OzP6GQ7QKhuWTGGHKSszk;PmIntVector*
ssc_core_FBNduJ2xtv0UjTuX5_iN4m;size_t mc_kwrB3ZoKf7OufTHWaHJV7a;size_t
ssc_sli_V_vSNcVk2WO7di04XVC3sL;boolean_T ssc_sli_k4M7bSEmThKJbirXUDQgS6=false;
ssc_sli__OzP6GQ7QKhuWTGGHKSszk=neu_copy_dsi(mc__XfQXtB6cfd9fyc_v3eEup,a);
ssc_core_FBNduJ2xtv0UjTuX5_iN4m=pm_create_int_vector(
ssc_sli_V_3jgb9hDH4SfXlbwqYYq5,a);for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<ssc_sli_Vp9TZCZIW_0oYHVC2sP9N4;
mc_kwrB3ZoKf7OufTHWaHJV7a++){size_t mc_kyp6uAyJE40UVuAQNEYzS1,
ssc_sli_kaB7LzWZNHGtYL2QAGFYXh;mc_VTlukZ0iimdzge7aTGg7rl(
ssc_core_FBNduJ2xtv0UjTuX5_iN4m,0);ssc_sli_kaB7LzWZNHGtYL2QAGFYXh=
mc_kwrB3ZoKf7OufTHWaHJV7a;mc_kyp6uAyJE40UVuAQNEYzS1=0;while(
ssc_sli_kaB7LzWZNHGtYL2QAGFYXh!=0){ssc_core_FBNduJ2xtv0UjTuX5_iN4m->mX[
mc_kyp6uAyJE40UVuAQNEYzS1]=ssc_sli_kaB7LzWZNHGtYL2QAGFYXh&1;
ssc_sli_kaB7LzWZNHGtYL2QAGFYXh>>=1;mc_kyp6uAyJE40UVuAQNEYzS1++;}(
ssc_sli_kqL3cKYSOoOsamezxPCk_r)->ssc_sli__knCEQ5GPkG_aaGxwsRkSp((
ssc_sli_kqL3cKYSOoOsamezxPCk_r),(ssc_sli__OzP6GQ7QKhuWTGGHKSszk),(
ssc_core_FBNduJ2xtv0UjTuX5_iN4m));ssc_sli_V_vSNcVk2WO7di04XVC3sL=0;(
ssc_sli_FK4g_EWd4wd0XHtmab_hbg)->ssc_sli__Drs_fQgLpOnjyd8ESSgoC((
ssc_sli_FK4g_EWd4wd0XHtmab_hbg),(ssc_sli__OzP6GQ7QKhuWTGGHKSszk),(&
ssc_sli_V_vSNcVk2WO7di04XVC3sL));if(ssc_sli_kqvLV4Tt3CdSbTfDDsWiAY){(void)0;;
if(ssc_sli_V_vSNcVk2WO7di04XVC3sL>*ssc_sli_kl8yCNeh9mlQXmcd9S8cIJ){
ssc_sli_k4M7bSEmThKJbirXUDQgS6=true;break;}*ssc_sli_kl8yCNeh9mlQXmcd9S8cIJ-=
ssc_sli_V_vSNcVk2WO7di04XVC3sL;}}pm_destroy_int_vector(
ssc_core_FBNduJ2xtv0UjTuX5_iN4m,a);neu_destroy_dynamic_system_input(
ssc_sli__OzP6GQ7QKhuWTGGHKSszk,a);if(ssc_sli_k4M7bSEmThKJbirXUDQgS6){(
ssc_sli_FK4g_EWd4wd0XHtmab_hbg)->mc_VYGWBho6N1K_eyHOMGjDiW((
ssc_sli_FK4g_EWd4wd0XHtmab_hbg));return true;}(ssc_sli_FK4g_EWd4wd0XHtmab_hbg
->mc_VFNhKLCqbHpDYXjdjCOMmT->ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h)->
ssc_core_VpMG2_8Z4c4aa9vd7AfjAl((ssc_sli_FK4g_EWd4wd0XHtmab_hbg->
mc_VFNhKLCqbHpDYXjdjCOMmT->ssc_sli_FLrEqGuKJIC7_1Rct1Bc_h));}*
mc__1Zf2IciMRCub1vvbEr1C4=ssc_sli_FK4g_EWd4wd0XHtmab_hbg;return false;}
