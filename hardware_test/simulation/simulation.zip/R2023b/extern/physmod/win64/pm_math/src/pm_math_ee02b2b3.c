#include "stddef.h"
#include "stdlib.h"
#include "pm_std.h"
extern double pm_math_k7lTE2xLhk_xdP85qIVEoj(const int
pm_math_FdNKyaRLqeWhg5tGqF_VYT,const int pm_math__jwySfHyx1SXgXJeVWoIzb,const
creal_T*x);
#include "pm_std.h"
extern void pm_math_V4wY5inRPrGJ_q94UMd56c(const int
pm_math_FdNKyaRLqeWhg5tGqF_VYT,const int pm_math__jwySfHyx1SXgXJeVWoIzb,const
real_T*pm_math_F2l4p_g4sn02huHNflQjMH,const real_T*
pm_math_Vqiy96WqvuhCaXm5e_vvT0,creal_T*pm_math_kJeUz19e49pVaDwcttsZep,creal_T*
pm_math_kyfq6L_eQbdYcPuOovpRDW,creal_T*pm_math_kXii4Miq3Y_ShPn9EHS3D5,creal_T*
pm_math_FYAUa2zJy8Cah1YsdPJok5,creal_T*pm_math__Vu43oWQSkpLiuph6ye1KN,creal_T*
pm_math_VHUYV1kdST0efLHvpiBBXm,creal_T*pm_math_VRZCD_UL_ESThy75dC9J8D,creal_T*
pm_math_Fo1tUR18sIdue1E1QXuOnL,creal_T*pm_math___7SXc4Q_w8saDIIf2ecjp,real_T*
pm_math_ktFLct2wbuxD_5iTvRiZEZ,real_T*pm_math_kHM1aMQ_rJdeheUxTze_oV,int32_T*
pm_math__qLHk6daYiGnXenMNt2kR_,int8_T*pm_math_VS3xMd4pLil0i5cxPD0ErK);
#include "pm_std.h"
extern double pm_math_kwMWlgVR1IlmY1byW81iKg(double
pm_math_kX_3wpayBuGfayGjLiZlmB,double pm_math_FkicuWr3zNG_VHwcasJgXR);
#include "pm_std.h"
extern real_T pm_math_V6hUjCc3PiCAauyMwJP5nb;extern real_T
pm_math_Vco4W7EuZu4k_1cAN9SDVG;extern real_T pm_math_k9HpTo0HuFt0gDRVyg17Wc;
extern real32_T pm_math__JOzYwXJOmSsiaZ6WMnnZZ;extern real32_T
pm_math_VaGr_igKLHx0bDW9g54I6v;extern real32_T pm_math_kZu0y5Pv4G8tg1EE_V6tGP;
extern void pm_math_F3OoZ1Weno85bujDCIyv_c(void);extern boolean_T
pm_math__LIYjt5pi54rVTuNKI6I5_(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern
boolean_T pm_math_VK2BuaMRCmOxjLjqE4tZMh(real32_T
pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T pm_math__J9snrOx2Cp4dD_e3lGtRm
(real_T pm_math_kg4CyRgbu6OdeewZOel7Qx);extern boolean_T
pm_math_kwH13YYrpKtAbDLZ9Q_8I9(real32_T pm_math_kg4CyRgbu6OdeewZOel7Qx);
#include "pm_std.h"
extern void pm_math__rpEXF0kArpajmJg_Jv0eW(const creal_T
pm_math_Fe6copTTRcKEayCm87ABO_,const creal_T pm_math_VoTkdAz8Qxd2iDKiMSyIbK,
double*pm_math_F5Olyc6xUoG7ZyDq78exBD,creal_T*pm_math_kgWQ_oIWTKdXZyfD4IYR1F);
extern void pm_math__wt7gD7RMvKZaeZRgAma6O(const creal_T
pm_math_Fe6copTTRcKEayCm87ABO_,const creal_T pm_math_VoTkdAz8Qxd2iDKiMSyIbK,
double*pm_math_F5Olyc6xUoG7ZyDq78exBD,creal_T*pm_math_kgWQ_oIWTKdXZyfD4IYR1F,
creal_T*pm_math_kUQBO1dSP8_IVqRAUx4R8G);double pm_math_k7lTE2xLhk_xdP85qIVEoj(
const int pm_math_FdNKyaRLqeWhg5tGqF_VYT,const int
pm_math__jwySfHyx1SXgXJeVWoIzb,const creal_T*x){double
pm_math_FzyLWRgau0pMYq2XSI3ETL;boolean_T b;boolean_T
pm_math_V2c37aSjx3WPf5cqm2_XQR;int pm_math_V2__YrimeI4E_yWnhKofpy;boolean_T
pm_math_kUqcTyWfRPlcVLXNTN8eJu;double pm_math_FD25RVUimp03gPWb9hwXT_;
pm_math_FzyLWRgau0pMYq2XSI3ETL=0.0;b=(pm_math_FdNKyaRLqeWhg5tGqF_VYT==0);
pm_math_V2c37aSjx3WPf5cqm2_XQR=(pm_math__jwySfHyx1SXgXJeVWoIzb==0);if((!b)&&(!
pm_math_V2c37aSjx3WPf5cqm2_XQR)){pm_math_V2__YrimeI4E_yWnhKofpy=0;
pm_math_kUqcTyWfRPlcVLXNTN8eJu=false;while((!pm_math_kUqcTyWfRPlcVLXNTN8eJu)&&
(pm_math_V2__YrimeI4E_yWnhKofpy<=pm_math_FdNKyaRLqeWhg5tGqF_VYT*
pm_math__jwySfHyx1SXgXJeVWoIzb-1)){pm_math_FD25RVUimp03gPWb9hwXT_=
pm_math_kwMWlgVR1IlmY1byW81iKg(x[pm_math_V2__YrimeI4E_yWnhKofpy].re,x[
pm_math_V2__YrimeI4E_yWnhKofpy].im);if(pm_math__J9snrOx2Cp4dD_e3lGtRm(
pm_math_FD25RVUimp03gPWb9hwXT_)){pm_math_FzyLWRgau0pMYq2XSI3ETL=
pm_math_k9HpTo0HuFt0gDRVyg17Wc;pm_math_kUqcTyWfRPlcVLXNTN8eJu=true;}else{if(
pm_math_FD25RVUimp03gPWb9hwXT_>pm_math_FzyLWRgau0pMYq2XSI3ETL){
pm_math_FzyLWRgau0pMYq2XSI3ETL=pm_math_FD25RVUimp03gPWb9hwXT_;}
pm_math_V2__YrimeI4E_yWnhKofpy++;}}}return pm_math_FzyLWRgau0pMYq2XSI3ETL;}
