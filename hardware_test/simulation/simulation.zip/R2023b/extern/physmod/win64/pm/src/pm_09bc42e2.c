#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
int_T pm_kkW9oQAVI7Wt_9Rzuat5bx(PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t pm_keOJjiAyBTtFhyWf033kni,size_t pm_kJxontPsxndNYXwDXdE1iy,size_t
pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
PmSparsityPattern*pm_create_sparsity_pattern(size_t pm_keOJjiAyBTtFhyWf033kni,
size_t pm_kJxontPsxndNYXwDXdE1iy,size_t pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kTFq3qlgTulWiT6pafkmmT(PmSparsityPattern*
pm__56dBn4vKXWjZ1nclFRYZB,const PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);
boolean_T pm__ZRI70SuGwhmamUtcsoyxS(const PmSparsityPattern*
pm__56dBn4vKXWjZ1nclFRYZB,const PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv);
PmSparsityPattern*pm_FQMLyYzCQ5CtgHjze1nNJP(const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FvcKvutPfxG9Xe1kjs7gg0(PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);void pm_VYooJBURCwKrVu6RXzQZ_5(
PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm__YwdRBXissh3bPWPl30Fpe(size_t
pm_FW8nEXbTFjdJhTIKepsgFT,size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm_FFniD_kRQg_JWTYc5cmjGs(size_t
pm_FW8nEXbTFjdJhTIKepsgFT,size_t pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmSparsityPattern*pm_FhqtSrxlPotrcypQHJ9Dcq(size_t
pm__lqjegyKuwStj56WZLiC_e,size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmSparsityPattern*pm__TNI3M36rThlaTetY4tWiB(size_t n,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);
#include "string.h"
#include "pm_std.h"
void pm_rv_equals_rv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void pm_VeeoZXnlJQ4u_112lGs8YD(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void pm_kpDvbw1GUlp4c5YdnW7V_w(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
pm_V2SLaBJy5WtXim9Lma9hfD(const PmCharVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmCharVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_FltUsml2sTlHZuCkbw_pdM(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_V8yYQkcd0vp_YaLM_nd75E(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm__P4MWKrtjzGPcercL4W7Fn(const
PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*
pm__YmIqNX3g5Sub1vKK1hZQF);int_T pm_create_real_vector_fields(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmRealVector*pm_create_real_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmRealVector*pm_V_q_QnwoVVl6fHS_0pLvYo(
const PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VeffaD_A8DxagH31Usec1H(PmRealVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_destroy_real_vector(PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);int_T pm_create_int_vector_fields(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
PmIntVector*pm_create_int_vector(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmIntVector*pm__fSS_VMqhWlobeqe6mQF_x(const
PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);
void pm_V_eFnKjg5I4Uc1DwG4yU27(PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);void pm_destroy_int_vector(PmIntVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_create_bool_vector_fields(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size
,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*pm__jbisDMumXdocXANx5LhhY
(size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_kia_QXK77_xDg9M1NzHr3r(PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_VuaGyqV_9K0Ia9Qgn65rsj(PmBoolVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmBoolVector*
pm_kpRdzyG9L_8MV5lRovACCg(const PmBoolVector*pm_FiALy5LWvv87e9O_pJGWPC,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T pm_create_char_vector_fields(
PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);PmCharVector*pm_VUwRqkQ4oj4FjX20jJYKVB(size_t
pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_VH4is_vKxDpFiupATTqV_4(PmCharVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_Vb1pkQZ6CdGmbmIAJ3mnfZ(PmCharVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);int_T
pm_FaBQ30lWObWMi1zpzQ_EZG(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,size_t size,
PmAllocator*pm__8zlSpb2Hixod149p2zadR);PmSizeVector*pm_FZch3YyGWrOM_PQNdo7b2c(
size_t pm__c6Ltywqrrtqii4hsDTKgz,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FlA06lYLRAWkWmGBVmxE1a(PmSizeVector*pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*
pm__8zlSpb2Hixod149p2zadR);void pm_kWBi8ZqmeopPhmEU9I2aNH(PmSizeVector*
pm_FiALy5LWvv87e9O_pJGWPC,PmAllocator*pm__8zlSpb2Hixod149p2zadR);void
pm_FJsPJplguVOI_1EYyUUvfK(const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmSizeVector*pm__YmIqNX3g5Sub1vKK1hZQF);boolean_T pm_kJR6lA3GKXdrdqFEbgLIwb(
const PmSizeVector*pm__hARyx1bZBxVj1boVQqdtV,const PmSizeVector*
pm__YmIqNX3g5Sub1vKK1hZQF);
#include "pm_std.h"
int_T pm_kkW9oQAVI7Wt_9Rzuat5bx(PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
size_t pm_keOJjiAyBTtFhyWf033kni,size_t pm_kJxontPsxndNYXwDXdE1iy,size_t
pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY){int_T
pm_k4M7bSEmThKJbirXUDQgS6=0;pm__6H5I5OnY3KoY5YVL6mLgG->mNumRow=
pm_kJxontPsxndNYXwDXdE1iy;pm__6H5I5OnY3KoY5YVL6mLgG->mNumCol=
pm_kPvICtSd_wWNieTWLEBFD1;if(!(pm__6H5I5OnY3KoY5YVL6mLgG->mJc=(int32_T*)((
pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(
int32_T)),(pm__6H5I5OnY3KoY5YVL6mLgG->mNumCol+1))))){pm_k4M7bSEmThKJbirXUDQgS6
+=1;}else if(pm_keOJjiAyBTtFhyWf033kni==0){pm__6H5I5OnY3KoY5YVL6mLgG->mIr=NULL
;}else if(!(pm__6H5I5OnY3KoY5YVL6mLgG->mIr=(int32_T*)((
pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(
int32_T)),(pm_keOJjiAyBTtFhyWf033kni))))){pm_k4M7bSEmThKJbirXUDQgS6+=1;}((
pm__6H5I5OnY3KoY5YVL6mLgG)->mJc[(pm__6H5I5OnY3KoY5YVL6mLgG)->mNumCol]=(int32_T
)(pm_keOJjiAyBTtFhyWf033kni));return pm_k4M7bSEmThKJbirXUDQgS6;}
PmSparsityPattern*pm_create_sparsity_pattern(size_t pm_keOJjiAyBTtFhyWf033kni,
size_t pm_kJxontPsxndNYXwDXdE1iy,size_t pm_kPvICtSd_wWNieTWLEBFD1,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG=(
PmSparsityPattern*)((pm__8zlSpb2Hixod149p2zadR)->mCallocFcn((
pm__8zlSpb2Hixod149p2zadR),(sizeof(PmSparsityPattern)),(1)));if(
pm__6H5I5OnY3KoY5YVL6mLgG){if(pm_kkW9oQAVI7Wt_9Rzuat5bx(
pm__6H5I5OnY3KoY5YVL6mLgG,pm_keOJjiAyBTtFhyWf033kni,pm_kJxontPsxndNYXwDXdE1iy,
pm_kPvICtSd_wWNieTWLEBFD1,pm__8zlSpb2Hixod149p2zadR)){{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm__6H5I5OnY3KoY5YVL6mLgG);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};
pm__6H5I5OnY3KoY5YVL6mLgG=NULL;}}return pm__6H5I5OnY3KoY5YVL6mLgG;}void
pm_kTFq3qlgTulWiT6pafkmmT(PmSparsityPattern*pm__56dBn4vKXWjZ1nclFRYZB,const
PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv){(void)0;;(void)0;;(void)0;;memcpy
(pm__56dBn4vKXWjZ1nclFRYZB->mJc,pm_kAWy4EaHbpxVbT_qyApDbv->mJc,sizeof(int32_T)
*(pm__56dBn4vKXWjZ1nclFRYZB->mNumCol+1));memcpy(pm__56dBn4vKXWjZ1nclFRYZB->mIr
,pm_kAWy4EaHbpxVbT_qyApDbv->mIr,sizeof(int32_T)*((size_t)(
pm__56dBn4vKXWjZ1nclFRYZB)->mJc[(pm__56dBn4vKXWjZ1nclFRYZB)->mNumCol]));}
boolean_T pm__ZRI70SuGwhmamUtcsoyxS(const PmSparsityPattern*
pm__56dBn4vKXWjZ1nclFRYZB,const PmSparsityPattern*pm_kAWy4EaHbpxVbT_qyApDbv){(
void)0;;(void)0;;(void)0;;return(memcmp(pm__56dBn4vKXWjZ1nclFRYZB->mJc,
pm_kAWy4EaHbpxVbT_qyApDbv->mJc,sizeof(int32_T)*(pm__56dBn4vKXWjZ1nclFRYZB->
mNumCol+1))==0)&&(memcmp(pm__56dBn4vKXWjZ1nclFRYZB->mIr,
pm_kAWy4EaHbpxVbT_qyApDbv->mIr,sizeof(int32_T)*((size_t)(
pm__56dBn4vKXWjZ1nclFRYZB)->mJc[(pm__56dBn4vKXWjZ1nclFRYZB)->mNumCol]))==0);}
PmSparsityPattern*pm_FQMLyYzCQ5CtgHjze1nNJP(const PmSparsityPattern*
pm__HVqeFmd5gKdguw04VZTsk,PmAllocator*pm__8zlSpb2Hixod149p2zadR){
PmSparsityPattern*pm__nP_wNlJUxWHWLytmZ4pL0=pm_create_sparsity_pattern(((
size_t)(pm__HVqeFmd5gKdguw04VZTsk)->mJc[(pm__HVqeFmd5gKdguw04VZTsk)->mNumCol])
,pm__HVqeFmd5gKdguw04VZTsk->mNumRow,pm__HVqeFmd5gKdguw04VZTsk->mNumCol,
pm__8zlSpb2Hixod149p2zadR);pm_kTFq3qlgTulWiT6pafkmmT(pm__nP_wNlJUxWHWLytmZ4pL0
,pm__HVqeFmd5gKdguw04VZTsk);return pm__nP_wNlJUxWHWLytmZ4pL0;}void
pm_FvcKvutPfxG9Xe1kjs7gg0(PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,
PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY){(void)0;;{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm__6H5I5OnY3KoY5YVL6mLgG->mJc);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(
pm_FbYb_iLqY2hwZTVlVaiqJY,pm_kk06poLCQlh5i5Yv6GSh7e);}};if(
pm__6H5I5OnY3KoY5YVL6mLgG->mIr!=NULL){{void*pm_kk06poLCQlh5i5Yv6GSh7e=(
pm__6H5I5OnY3KoY5YVL6mLgG->mIr);if(pm_kk06poLCQlh5i5Yv6GSh7e!=0){(
pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(pm_FbYb_iLqY2hwZTVlVaiqJY,
pm_kk06poLCQlh5i5Yv6GSh7e);}};}}void pm_VYooJBURCwKrVu6RXzQZ_5(
PmSparsityPattern*pm__6H5I5OnY3KoY5YVL6mLgG,PmAllocator*
pm__8zlSpb2Hixod149p2zadR){(void)0;;pm_FvcKvutPfxG9Xe1kjs7gg0(
pm__6H5I5OnY3KoY5YVL6mLgG,pm__8zlSpb2Hixod149p2zadR);{void*
pm_kk06poLCQlh5i5Yv6GSh7e=(pm__6H5I5OnY3KoY5YVL6mLgG);if(
pm_kk06poLCQlh5i5Yv6GSh7e!=0){(pm__8zlSpb2Hixod149p2zadR)->mFreeFcn(
pm__8zlSpb2Hixod149p2zadR,pm_kk06poLCQlh5i5Yv6GSh7e);}};}PmSparsityPattern*
pm__YwdRBXissh3bPWPl30Fpe(size_t pm_FW8nEXbTFjdJhTIKepsgFT,size_t
pm_FsQ9LRKHRTKdgeP2xWDL07,PmAllocator*pm__8zlSpb2Hixod149p2zadR){
PmSparsityPattern*pm_kKo5ZT7hO5CIhDFBar7kG3=pm_create_sparsity_pattern(
pm_FsQ9LRKHRTKdgeP2xWDL07*pm_FW8nEXbTFjdJhTIKepsgFT,pm_FW8nEXbTFjdJhTIKepsgFT,
pm_FsQ9LRKHRTKdgeP2xWDL07,pm__8zlSpb2Hixod149p2zadR);size_t
pm_kwrB3ZoKf7OufTHWaHJV7a,pm_kyp6uAyJE40UVuAQNEYzS1;int32_T*
pm_VEXzFHKjFN87iiOtLrddNz=pm_kKo5ZT7hO5CIhDFBar7kG3->mIr;int32_T*
pm_kXeDcvuOSpSqamcA4a5jc_=pm_kKo5ZT7hO5CIhDFBar7kG3->mJc;for(
pm_kwrB3ZoKf7OufTHWaHJV7a=0;pm_kwrB3ZoKf7OufTHWaHJV7a<=
pm_FsQ9LRKHRTKdgeP2xWDL07;pm_kwrB3ZoKf7OufTHWaHJV7a++){
pm_kXeDcvuOSpSqamcA4a5jc_[pm_kwrB3ZoKf7OufTHWaHJV7a]=((int32_T)(
pm_kwrB3ZoKf7OufTHWaHJV7a*pm_FW8nEXbTFjdJhTIKepsgFT));}if(
pm_FW8nEXbTFjdJhTIKepsgFT*pm_FsQ9LRKHRTKdgeP2xWDL07>0){for(
pm_kyp6uAyJE40UVuAQNEYzS1=0;pm_kyp6uAyJE40UVuAQNEYzS1<
pm_FW8nEXbTFjdJhTIKepsgFT;pm_kyp6uAyJE40UVuAQNEYzS1++){
pm_VEXzFHKjFN87iiOtLrddNz[pm_kyp6uAyJE40UVuAQNEYzS1]=((int32_T)(
pm_kyp6uAyJE40UVuAQNEYzS1));}for(pm_kwrB3ZoKf7OufTHWaHJV7a=1;
pm_kwrB3ZoKf7OufTHWaHJV7a<pm_FsQ9LRKHRTKdgeP2xWDL07;pm_kwrB3ZoKf7OufTHWaHJV7a
++){memcpy(&pm_VEXzFHKjFN87iiOtLrddNz[pm_kwrB3ZoKf7OufTHWaHJV7a*
pm_FW8nEXbTFjdJhTIKepsgFT],pm_VEXzFHKjFN87iiOtLrddNz,pm_FW8nEXbTFjdJhTIKepsgFT
*sizeof(int32_T));}}(void)0;;return pm_kKo5ZT7hO5CIhDFBar7kG3;}
PmSparsityPattern*pm_FFniD_kRQg_JWTYc5cmjGs(size_t pm__GeNF2llSxSVWmZa9ocEGK,
size_t pm__yjwm3JEVFhagux1_YE9b5,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY){
PmSparsityPattern*pm__srK5LmyWw42ZyPnbOWDWJ=pm_create_sparsity_pattern(0,
pm__GeNF2llSxSVWmZa9ocEGK,pm__yjwm3JEVFhagux1_YE9b5,pm_FbYb_iLqY2hwZTVlVaiqJY)
;memset(pm__srK5LmyWw42ZyPnbOWDWJ->mJc,0,(pm__yjwm3JEVFhagux1_YE9b5+1)*sizeof(
int32_T));(void)0;;(void)0;;return pm__srK5LmyWw42ZyPnbOWDWJ;}
PmSparsityPattern*pm_FhqtSrxlPotrcypQHJ9Dcq(size_t pm__lqjegyKuwStj56WZLiC_e,
size_t n,PmAllocator*pm__8zlSpb2Hixod149p2zadR){PmSparsityPattern*
pm__nP_wNlJUxWHWLytmZ4pL0=pm_create_sparsity_pattern(pm__lqjegyKuwStj56WZLiC_e
,n,n,pm__8zlSpb2Hixod149p2zadR);int32_T*pm_VBsR9a3YZx8wfi1lnhKnw7=
pm__nP_wNlJUxWHWLytmZ4pL0->mJc;int32_T*pm__vhvHU0y0tSUVy1VSFOPLJ=
pm__nP_wNlJUxWHWLytmZ4pL0->mIr;size_t pm_kwrB3ZoKf7OufTHWaHJV7a=0;(void)0;;for
(pm_kwrB3ZoKf7OufTHWaHJV7a=0;pm_kwrB3ZoKf7OufTHWaHJV7a<
pm__lqjegyKuwStj56WZLiC_e;pm_kwrB3ZoKf7OufTHWaHJV7a++){
pm__vhvHU0y0tSUVy1VSFOPLJ[pm_kwrB3ZoKf7OufTHWaHJV7a]=pm_VBsR9a3YZx8wfi1lnhKnw7
[pm_kwrB3ZoKf7OufTHWaHJV7a]=((int32_T)(pm_kwrB3ZoKf7OufTHWaHJV7a));}for(
pm_kwrB3ZoKf7OufTHWaHJV7a=pm__lqjegyKuwStj56WZLiC_e;pm_kwrB3ZoKf7OufTHWaHJV7a
<=n;pm_kwrB3ZoKf7OufTHWaHJV7a++){pm_VBsR9a3YZx8wfi1lnhKnw7[
pm_kwrB3ZoKf7OufTHWaHJV7a]=((int32_T)(pm__lqjegyKuwStj56WZLiC_e));}return
pm__nP_wNlJUxWHWLytmZ4pL0;}PmSparsityPattern*pm__TNI3M36rThlaTetY4tWiB(size_t n
,PmAllocator*pm__8zlSpb2Hixod149p2zadR){return pm_FhqtSrxlPotrcypQHJ9Dcq(n,n,
pm__8zlSpb2Hixod149p2zadR);}
