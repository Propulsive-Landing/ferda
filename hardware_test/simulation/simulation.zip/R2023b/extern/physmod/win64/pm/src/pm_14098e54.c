#include "pm_std.h"
#include "pm_std.h"
#include "pm_std.h"
typedef struct pm_V1heuUPdFYSBhXSTZrzev1{size_t mNumRow;size_t mNumCol;real_T*
mX;}pm_FMSUHHOOKD8acuFWLEq4lL;pm_FMSUHHOOKD8acuFWLEq4lL*
pm__IzxUodah3x2_u_ENKAuGk(size_t pm__6bYkkT4Shd0e1DZPlpqqb,size_t
pm__g5DiU2QzFtUiL4XoU6SMs,PmAllocator*pm_FbYb_iLqY2hwZTVlVaiqJY);
pm_FMSUHHOOKD8acuFWLEq4lL*pm__vffvPR7IsS2XyyCPqmNPs(const
pm_FMSUHHOOKD8acuFWLEq4lL*pm__sjTRWOMR4WzZisVeB2fYm,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);void pm__uc9LGWqLf03gLt6Sr9mtw(
pm_FMSUHHOOKD8acuFWLEq4lL*pm_k5aqR5haGY_ZXuGDU2ua60,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY);void pm_VuZ05R76dw4R_5mH59xUl3(const
pm_FMSUHHOOKD8acuFWLEq4lL*pm_k5aqR5haGY_ZXuGDU2ua60);size_t
pm_kXhhlZLW3c8yiTFYZWcurB(const pm_FMSUHHOOKD8acuFWLEq4lL*
pm_k5aqR5haGY_ZXuGDU2ua60);PMF_DEPLOY_STATIC real_T pm_VWoHHtf6OqO6YXA_khGhQm(
const pm_FMSUHHOOKD8acuFWLEq4lL*pm_k5aqR5haGY_ZXuGDU2ua60,size_t
pm_kplAJmOlA30feiNcOzi7oj,size_t pm_Fr_bHKkQKFWbfi50VWd5Pw){return
pm_k5aqR5haGY_ZXuGDU2ua60->mX[pm_kplAJmOlA30feiNcOzi7oj+
pm_Fr_bHKkQKFWbfi50VWd5Pw*pm_k5aqR5haGY_ZXuGDU2ua60->mNumRow];}
PMF_DEPLOY_STATIC void pm_kzEZvMeJLvOmgX1qMXsT0P(const
pm_FMSUHHOOKD8acuFWLEq4lL*pm_k5aqR5haGY_ZXuGDU2ua60,size_t
pm_kplAJmOlA30feiNcOzi7oj,size_t pm_Fr_bHKkQKFWbfi50VWd5Pw,real_T
pm_kpzAtHMD4_WnheH0UiioSE){pm_k5aqR5haGY_ZXuGDU2ua60->mX[
pm_kplAJmOlA30feiNcOzi7oj+pm_Fr_bHKkQKFWbfi50VWd5Pw*pm_k5aqR5haGY_ZXuGDU2ua60
->mNumRow]=pm_kpzAtHMD4_WnheH0UiioSE;}void pm_kqNP_VNVXgWGcLsAqt8n_A(const
pm_FMSUHHOOKD8acuFWLEq4lL*pm_kUO9H2UqXf8k_y6THPribZ,const PmRealVector*
pm_V9BoL4F3KMGcYqNc2RhxW_,const PmSparsityPattern*pm_FbpiqbN30g8sY9B6YI6RUP);
void pm_kRraI4tqfotp_aUXOIifb6(const pm_FMSUHHOOKD8acuFWLEq4lL*dst,const
pm_FMSUHHOOKD8acuFWLEq4lL*src);boolean_T pm__DD6QRkN3jGod5UZotcfi8(const
pm_FMSUHHOOKD8acuFWLEq4lL*dst,const pm_FMSUHHOOKD8acuFWLEq4lL*src);boolean_T
pm__Wj7kGLfa8_wfmNCNFVchb(const pm_FMSUHHOOKD8acuFWLEq4lL*dst,size_t
pm_kFiZgJyKzlhBjiAGyCdzxA,const pm_FMSUHHOOKD8acuFWLEq4lL*src,size_t
pm_VLyT3I17Hm8phLoGoAFHeg,size_t pm__dZ3R3yisKSMd19Osaf1CO);void
pm_VL4rp2NEaF8Tcu2gE6TeeU(const pm_FMSUHHOOKD8acuFWLEq4lL*dst,size_t
pm_kFiZgJyKzlhBjiAGyCdzxA,const pm_FMSUHHOOKD8acuFWLEq4lL*src,size_t
pm_VLyT3I17Hm8phLoGoAFHeg,size_t pm__dZ3R3yisKSMd19Osaf1CO);
#include "string.h"
#include "pm_std.h"
pm_FMSUHHOOKD8acuFWLEq4lL*pm__IzxUodah3x2_u_ENKAuGk(size_t
pm__6bYkkT4Shd0e1DZPlpqqb,size_t pm__g5DiU2QzFtUiL4XoU6SMs,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY){pm_FMSUHHOOKD8acuFWLEq4lL*pm_k5aqR5haGY_ZXuGDU2ua60
=(pm_FMSUHHOOKD8acuFWLEq4lL*)((pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((
pm_FbYb_iLqY2hwZTVlVaiqJY),(sizeof(pm_FMSUHHOOKD8acuFWLEq4lL)),(1)));
pm_k5aqR5haGY_ZXuGDU2ua60->mNumRow=pm__6bYkkT4Shd0e1DZPlpqqb;
pm_k5aqR5haGY_ZXuGDU2ua60->mNumCol=pm__g5DiU2QzFtUiL4XoU6SMs;
pm_k5aqR5haGY_ZXuGDU2ua60->mX=((pm_FbYb_iLqY2hwZTVlVaiqJY)->mCallocFcn((
pm_FbYb_iLqY2hwZTVlVaiqJY),(pm__6bYkkT4Shd0e1DZPlpqqb*
pm__g5DiU2QzFtUiL4XoU6SMs),(sizeof(real_T))));return pm_k5aqR5haGY_ZXuGDU2ua60
;}pm_FMSUHHOOKD8acuFWLEq4lL*pm__vffvPR7IsS2XyyCPqmNPs(const
pm_FMSUHHOOKD8acuFWLEq4lL*pm__sjTRWOMR4WzZisVeB2fYm,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY){pm_FMSUHHOOKD8acuFWLEq4lL*pm_V2mBNcV1EqCifyH9UdCbkF
=pm__IzxUodah3x2_u_ENKAuGk(pm__sjTRWOMR4WzZisVeB2fYm->mNumRow,
pm__sjTRWOMR4WzZisVeB2fYm->mNumCol,pm_FbYb_iLqY2hwZTVlVaiqJY);
pm_kRraI4tqfotp_aUXOIifb6(pm_V2mBNcV1EqCifyH9UdCbkF,pm__sjTRWOMR4WzZisVeB2fYm)
;return pm_V2mBNcV1EqCifyH9UdCbkF;}void pm__uc9LGWqLf03gLt6Sr9mtw(
pm_FMSUHHOOKD8acuFWLEq4lL*pm_k5aqR5haGY_ZXuGDU2ua60,PmAllocator*
pm_FbYb_iLqY2hwZTVlVaiqJY){{void*pm_kk06poLCQlh5i5Yv6GSh7e=(
pm_k5aqR5haGY_ZXuGDU2ua60->mX);if(pm_kk06poLCQlh5i5Yv6GSh7e!=0){(
pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(pm_FbYb_iLqY2hwZTVlVaiqJY,
pm_kk06poLCQlh5i5Yv6GSh7e);}};{void*pm_kk06poLCQlh5i5Yv6GSh7e=(
pm_k5aqR5haGY_ZXuGDU2ua60);if(pm_kk06poLCQlh5i5Yv6GSh7e!=0){(
pm_FbYb_iLqY2hwZTVlVaiqJY)->mFreeFcn(pm_FbYb_iLqY2hwZTVlVaiqJY,
pm_kk06poLCQlh5i5Yv6GSh7e);}};}void pm_VuZ05R76dw4R_5mH59xUl3(const
pm_FMSUHHOOKD8acuFWLEq4lL*pm_k5aqR5haGY_ZXuGDU2ua60){memset(
pm_k5aqR5haGY_ZXuGDU2ua60->mX,0,pm_k5aqR5haGY_ZXuGDU2ua60->mNumRow*
pm_k5aqR5haGY_ZXuGDU2ua60->mNumCol*sizeof(real_T));}size_t
pm_kXhhlZLW3c8yiTFYZWcurB(const pm_FMSUHHOOKD8acuFWLEq4lL*
pm_k5aqR5haGY_ZXuGDU2ua60){size_t pm_kNgcOktCtQxdYedrGvFn5i=0;size_t
pm_kh3C5f6ZAPlGWXfJykpWPn=0;for(pm_kh3C5f6ZAPlGWXfJykpWPn=0;
pm_kh3C5f6ZAPlGWXfJykpWPn<pm_k5aqR5haGY_ZXuGDU2ua60->mNumRow*
pm_k5aqR5haGY_ZXuGDU2ua60->mNumCol;pm_kh3C5f6ZAPlGWXfJykpWPn++){
pm_kNgcOktCtQxdYedrGvFn5i+=pm_k5aqR5haGY_ZXuGDU2ua60->mX[
pm_kh3C5f6ZAPlGWXfJykpWPn]?1:0;}return pm_kNgcOktCtQxdYedrGvFn5i;}void
pm_kqNP_VNVXgWGcLsAqt8n_A(const pm_FMSUHHOOKD8acuFWLEq4lL*
pm_kUO9H2UqXf8k_y6THPribZ,const PmRealVector*pm_V9BoL4F3KMGcYqNc2RhxW_,const
PmSparsityPattern*pm_FbpiqbN30g8sY9B6YI6RUP){size_t pm_VLHhnPUiNQpve5VIL9P3O9=
pm_FbpiqbN30g8sY9B6YI6RUP->mNumRow;size_t n=pm_FbpiqbN30g8sY9B6YI6RUP->mNumCol
;size_t pm_kyp6uAyJE40UVuAQNEYzS1=0;int32_T pm_V2Ap3MG6qy_ijioo_xKfYu=0;
int32_T*pm_kXeDcvuOSpSqamcA4a5jc_=pm_FbpiqbN30g8sY9B6YI6RUP->mJc;int32_T*
pm_VEXzFHKjFN87iiOtLrddNz=pm_FbpiqbN30g8sY9B6YI6RUP->mIr;(void)0;;(void)0;;
pm_VuZ05R76dw4R_5mH59xUl3(pm_kUO9H2UqXf8k_y6THPribZ);for(
pm_kyp6uAyJE40UVuAQNEYzS1=0;pm_kyp6uAyJE40UVuAQNEYzS1<n;
pm_kyp6uAyJE40UVuAQNEYzS1++){for(pm_V2Ap3MG6qy_ijioo_xKfYu=
pm_kXeDcvuOSpSqamcA4a5jc_[pm_kyp6uAyJE40UVuAQNEYzS1];pm_V2Ap3MG6qy_ijioo_xKfYu
<pm_kXeDcvuOSpSqamcA4a5jc_[pm_kyp6uAyJE40UVuAQNEYzS1+1];
pm_V2Ap3MG6qy_ijioo_xKfYu++){pm_kzEZvMeJLvOmgX1qMXsT0P(
pm_kUO9H2UqXf8k_y6THPribZ,pm_VEXzFHKjFN87iiOtLrddNz[pm_V2Ap3MG6qy_ijioo_xKfYu]
,pm_kyp6uAyJE40UVuAQNEYzS1,pm_V9BoL4F3KMGcYqNc2RhxW_->mX[
pm_V2Ap3MG6qy_ijioo_xKfYu]);}}}void pm_kRraI4tqfotp_aUXOIifb6(const
pm_FMSUHHOOKD8acuFWLEq4lL*dst,const pm_FMSUHHOOKD8acuFWLEq4lL*src){size_t n=
dst->mNumRow*dst->mNumCol;(void)0;;(void)0;;if(n>0&&dst->mX!=src->mX){memcpy(
dst->mX,src->mX,n*sizeof(real_T));}}boolean_T pm__DD6QRkN3jGod5UZotcfi8(const
pm_FMSUHHOOKD8acuFWLEq4lL*dst,const pm_FMSUHHOOKD8acuFWLEq4lL*src){size_t n=
dst->mNumRow*dst->mNumCol;(void)0;;(void)0;;if(n>0&&dst->mX!=src->mX){return
memcmp(dst->mX,src->mX,src->mNumRow*src->mNumCol*sizeof(real_T))==0;}else{
return true;}}boolean_T pm__Wj7kGLfa8_wfmNCNFVchb(const
pm_FMSUHHOOKD8acuFWLEq4lL*dst,size_t pm_kFiZgJyKzlhBjiAGyCdzxA,const
pm_FMSUHHOOKD8acuFWLEq4lL*src,size_t pm_VLyT3I17Hm8phLoGoAFHeg,size_t
pm__dZ3R3yisKSMd19Osaf1CO){size_t pm_VLHhnPUiNQpve5VIL9P3O9=dst->mNumRow;
size_t n=dst->mNumCol;(void)0;;(void)0;;(void)0;;return memcmp(dst->mX+
pm_kFiZgJyKzlhBjiAGyCdzxA*pm_VLHhnPUiNQpve5VIL9P3O9,src->mX+
pm_VLyT3I17Hm8phLoGoAFHeg*pm_VLHhnPUiNQpve5VIL9P3O9,pm__dZ3R3yisKSMd19Osaf1CO*
pm_VLHhnPUiNQpve5VIL9P3O9*sizeof(real_T))==0;}void pm_VL4rp2NEaF8Tcu2gE6TeeU(
const pm_FMSUHHOOKD8acuFWLEq4lL*dst,size_t pm_kFiZgJyKzlhBjiAGyCdzxA,const
pm_FMSUHHOOKD8acuFWLEq4lL*src,size_t pm_VLyT3I17Hm8phLoGoAFHeg,size_t
pm__dZ3R3yisKSMd19Osaf1CO){size_t pm_VLHhnPUiNQpve5VIL9P3O9=dst->mNumRow;
size_t n=dst->mNumCol;(void)0;;(void)0;;(void)0;;memcpy(dst->mX+
pm_kFiZgJyKzlhBjiAGyCdzxA*pm_VLHhnPUiNQpve5VIL9P3O9,src->mX+
pm_VLyT3I17Hm8phLoGoAFHeg*pm_VLHhnPUiNQpve5VIL9P3O9,pm__dZ3R3yisKSMd19Osaf1CO*
pm_VLHhnPUiNQpve5VIL9P3O9*sizeof(real_T));}
