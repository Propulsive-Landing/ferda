#ifndef __ne_profiler_fwd_h__
#define __ne_profiler_fwd_h__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
typedef struct NeProfilerTag NeProfiler;
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __ne_profiler_fwd_h__ */
