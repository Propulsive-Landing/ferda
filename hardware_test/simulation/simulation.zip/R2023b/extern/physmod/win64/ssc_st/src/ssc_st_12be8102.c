#include "ne_std.h"
#include "pm_std.h"
#include "ne_std.h"
typedef struct ssc_st_kemRd3LD2_pPVaAsNA5YDG ssc_st_VVipzh2oIBtKZ5hNqD2z_1;
typedef struct ssc_st_VAZekvvzo5CUcm0GE7lD8S ssc_st_FdhjQ_x6uEtWf5NrhiXPkC;
struct ssc_st_kemRd3LD2_pPVaAsNA5YDG{ssc_st_FdhjQ_x6uEtWf5NrhiXPkC*
mPrivateData;void(*mc_kt9hW2swhpxchivzz5BlCP)(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
ssc_st__pLwoU6jmvWSV9dXhEIoIv,NeuDiagnosticTree*ssc_st_kBj0wT0jErl0hDNP9N5QnJ)
;NeuDiagnosticTree*(*ssc_st__ncbpuIDzMOrgqwrOKx4qs)(
ssc_st_VVipzh2oIBtKZ5hNqD2z_1*ssc_st__pLwoU6jmvWSV9dXhEIoIv);NeuDiagnosticTree
*(*ssc_st_kQPAw1xwSVSbhTWPocMRHj)(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
ssc_st__pLwoU6jmvWSV9dXhEIoIv);NeuDiagnosticTree*(*
ssc_st_FWUr7cMI27_XXuAo82pt8h)(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
ssc_st__pLwoU6jmvWSV9dXhEIoIv,size_t n);size_t(*ssc_st_FRrT3ZKfnZCQ_TCtuEK5hH)
(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*ssc_st__pLwoU6jmvWSV9dXhEIoIv);void(*
mc_VYGWBho6N1K_eyHOMGjDiW)(ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
ssc_st__pLwoU6jmvWSV9dXhEIoIv);};ssc_st_VVipzh2oIBtKZ5hNqD2z_1*
ssc_st_F__qZQpW_J4sVP_0nua696(PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z);typedef
struct ssc_st_k6o6k1o1WGOpW1HJRvtMhF ssc_st_V4o7rdTSXidje1ttVgvQFh;struct
NeuDiagnosticTreeTag{ssc_st_V4o7rdTSXidje1ttVgvQFh*mPrivateData;char*
mc_Vbr5eqH3ENhKgPrE0rHGwZ;char*ssc_st_VxRF0QCkLKh5auXYJTdv_i;
NeuDiagnosticLevel ssc_st_kDBpxZEtSdlEii_qqd1dc7;ssc_st_VVipzh2oIBtKZ5hNqD2z_1
*ssc_st__VHqlgYzFJWCfL7_k_NRZF;void(*mc_VYGWBho6N1K_eyHOMGjDiW)(
NeuDiagnosticTree*ssc_st_kBj0wT0jErl0hDNP9N5QnJ);};NeuDiagnosticTree*
ssc_st_FTcUm46bdDhggms5nJSPNZ(PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z);
#include "pm_std.h"
struct ssc_st_k6o6k1o1WGOpW1HJRvtMhF{PmAllocator*ssc_st_FyUeLiATLG4zWes0mMKZnu
;};static void ssc_st_k_rFi__Swpxpci6_A31HmZ(NeuDiagnosticTree*
ssc_st_kBj0wT0jErl0hDNP9N5QnJ){ssc_st_V4o7rdTSXidje1ttVgvQFh*
mc__d1alWYexptL_X5HTFhbNK=ssc_st_kBj0wT0jErl0hDNP9N5QnJ->mPrivateData;
PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z=mc__d1alWYexptL_X5HTFhbNK->
ssc_st_FyUeLiATLG4zWes0mMKZnu;{void*ssc_st_kk06poLCQlh5i5Yv6GSh7e=(
mc__d1alWYexptL_X5HTFhbNK);if(ssc_st_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
ssc_st_kk06poLCQlh5i5Yv6GSh7e);}};{void*ssc_st_kk06poLCQlh5i5Yv6GSh7e=(
ssc_st_kBj0wT0jErl0hDNP9N5QnJ->mc_Vbr5eqH3ENhKgPrE0rHGwZ);if(
ssc_st_kk06poLCQlh5i5Yv6GSh7e!=0){(mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(
mc_FOGg0ZWot2WdYenO8zaD4Z,ssc_st_kk06poLCQlh5i5Yv6GSh7e);}};{void*
ssc_st_kk06poLCQlh5i5Yv6GSh7e=(ssc_st_kBj0wT0jErl0hDNP9N5QnJ->
ssc_st_VxRF0QCkLKh5auXYJTdv_i);if(ssc_st_kk06poLCQlh5i5Yv6GSh7e!=0){(
mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(mc_FOGg0ZWot2WdYenO8zaD4Z,
ssc_st_kk06poLCQlh5i5Yv6GSh7e);}};if(ssc_st_kBj0wT0jErl0hDNP9N5QnJ->
ssc_st__VHqlgYzFJWCfL7_k_NRZF!=NULL){size_t mc_kwrB3ZoKf7OufTHWaHJV7a=0;size_t
n=(ssc_st_kBj0wT0jErl0hDNP9N5QnJ->ssc_st__VHqlgYzFJWCfL7_k_NRZF)->
ssc_st_FRrT3ZKfnZCQ_TCtuEK5hH((ssc_st_kBj0wT0jErl0hDNP9N5QnJ->
ssc_st__VHqlgYzFJWCfL7_k_NRZF));for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){((
ssc_st_kBj0wT0jErl0hDNP9N5QnJ->ssc_st__VHqlgYzFJWCfL7_k_NRZF)->
ssc_st_FWUr7cMI27_XXuAo82pt8h((ssc_st_kBj0wT0jErl0hDNP9N5QnJ->
ssc_st__VHqlgYzFJWCfL7_k_NRZF),(mc_kwrB3ZoKf7OufTHWaHJV7a)))->
mc_VYGWBho6N1K_eyHOMGjDiW(((ssc_st_kBj0wT0jErl0hDNP9N5QnJ->
ssc_st__VHqlgYzFJWCfL7_k_NRZF)->ssc_st_FWUr7cMI27_XXuAo82pt8h((
ssc_st_kBj0wT0jErl0hDNP9N5QnJ->ssc_st__VHqlgYzFJWCfL7_k_NRZF),(
mc_kwrB3ZoKf7OufTHWaHJV7a))));}(ssc_st_kBj0wT0jErl0hDNP9N5QnJ->
ssc_st__VHqlgYzFJWCfL7_k_NRZF)->mc_VYGWBho6N1K_eyHOMGjDiW((
ssc_st_kBj0wT0jErl0hDNP9N5QnJ->ssc_st__VHqlgYzFJWCfL7_k_NRZF));}{void*
ssc_st_kk06poLCQlh5i5Yv6GSh7e=(ssc_st_kBj0wT0jErl0hDNP9N5QnJ);if(
ssc_st_kk06poLCQlh5i5Yv6GSh7e!=0){(mc_FOGg0ZWot2WdYenO8zaD4Z)->mFreeFcn(
mc_FOGg0ZWot2WdYenO8zaD4Z,ssc_st_kk06poLCQlh5i5Yv6GSh7e);}};}NeuDiagnosticTree
*ssc_st_FTcUm46bdDhggms5nJSPNZ(PmAllocator*mc_FOGg0ZWot2WdYenO8zaD4Z){
NeuDiagnosticTree*ssc_st_kBj0wT0jErl0hDNP9N5QnJ=(NeuDiagnosticTree*)((
mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(
NeuDiagnosticTree)),(1)));ssc_st_V4o7rdTSXidje1ttVgvQFh*
mc__d1alWYexptL_X5HTFhbNK=(ssc_st_V4o7rdTSXidje1ttVgvQFh*)((
mc_FOGg0ZWot2WdYenO8zaD4Z)->mCallocFcn((mc_FOGg0ZWot2WdYenO8zaD4Z),(sizeof(
ssc_st_V4o7rdTSXidje1ttVgvQFh)),(1)));mc__d1alWYexptL_X5HTFhbNK->
ssc_st_FyUeLiATLG4zWes0mMKZnu=mc_FOGg0ZWot2WdYenO8zaD4Z;
ssc_st_kBj0wT0jErl0hDNP9N5QnJ->ssc_st_kDBpxZEtSdlEii_qqd1dc7=
NEU_DIAGNOSTIC_LEVEL_TERSE;ssc_st_kBj0wT0jErl0hDNP9N5QnJ->
mc_Vbr5eqH3ENhKgPrE0rHGwZ=NULL;ssc_st_kBj0wT0jErl0hDNP9N5QnJ->
ssc_st_VxRF0QCkLKh5auXYJTdv_i=NULL;ssc_st_kBj0wT0jErl0hDNP9N5QnJ->
ssc_st__VHqlgYzFJWCfL7_k_NRZF=ssc_st_F__qZQpW_J4sVP_0nua696(
mc_FOGg0ZWot2WdYenO8zaD4Z);ssc_st_kBj0wT0jErl0hDNP9N5QnJ->mPrivateData=
mc__d1alWYexptL_X5HTFhbNK;ssc_st_kBj0wT0jErl0hDNP9N5QnJ->
mc_VYGWBho6N1K_eyHOMGjDiW= &ssc_st_k_rFi__Swpxpci6_A31HmZ;return
ssc_st_kBj0wT0jErl0hDNP9N5QnJ;}
